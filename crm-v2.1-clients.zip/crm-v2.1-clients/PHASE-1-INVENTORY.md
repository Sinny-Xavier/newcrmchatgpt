# Phase 1 Inventory

## Application profile

- Private single-owner CRM
- One authorised user
- Multi-device access
- GitHub Pages-compatible browser application
- Supabase REST backend
- LocalStorage fallback/cache
- Chart.js dependency

## Main views detected

- Dashboard
- Client detail
- Clients
- Client form
- Reps / ASM
- Sales
- Samples
- Birthdays
- Complaints
- Diary
- Quotes
- Websites
- Tools
- Documents
- Enquiries
- Sourcing
- Tasks / To-Do
- Footfall
- Notes search

## Supabase tables referenced

- archived_clients
- birthdays
- clients
- complaints
- diary_events
- docs
- enquiries
- footfall_entries
- reps
- samples
- settings
- tasks
- websites

## Existing architecture observed

Each main table uses a simple record envelope:

- `id` — text identifier
- `data` — JSONB application record
- `updated_at` — timestamp with time zone

The CRM reads the `data` values into in-memory arrays, mirrors data to LocalStorage, and writes records back to Supabase through REST calls.

## Initial technical priorities

1. Preserve feature parity before redesign.
2. Isolate Supabase configuration and network operations.
3. Replace broad whole-array saves with targeted record operations where safe.
4. Introduce conflict/version protection for multi-device use.
5. Keep the current database structure during the first rebuild stages.
6. Improve error reporting and recovery without changing the familiar interface.
7. Keep authentication appropriate for a private single-user system.

## Phase 1 result

The first structural extraction is deliberately behaviour-preserving. It creates a maintainable starting point without modifying the live database schema or changing workflows.
