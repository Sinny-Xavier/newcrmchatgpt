// ── SUPABASE ──────────────────────────────────────────────────────
var SB_URL = "https://ogkyemjiosgedwgqfvyy.supabase.co";
var SB_KEY = "sb_publishable_D1c8k6kHAsJbrovvWM5pIg_hkfonge9";

async function sbGet(table) {
  try {
    var r = await fetch(SB_URL+"/rest/v1/"+table+"?select=*&limit=1000", {
      headers: {
        "apikey": SB_KEY,
        "Authorization": "Bearer "+SB_KEY,
        "Content-Type": "application/json",
        "Accept": "application/json"
      }
    });
    if (!r.ok) { console.warn("sbGet error:", r.status, await r.text()); return null; }
    var rows = await r.json();
    if (!Array.isArray(rows)) return null;
    return rows.map(function(row){ return row.data; });
  } catch(e) { console.warn("Supabase get error:", e); return null; }
}

async function sbUpsert(table, id, data) {
  try {
    var r = await fetch(SB_URL+"/rest/v1/"+table, {
      method: "POST",
      headers: {"apikey":SB_KEY,"Authorization":"Bearer "+SB_KEY,"Content-Type":"application/json","Prefer":"resolution=merge-duplicates"},
      body: JSON.stringify({id:id, data:data, updated_at: new Date().toISOString()})
    });
    if (!r.ok) {
      console.warn("sbUpsert error:", table, r.status, await r.text());
      toast("\u26a0\ufe0f Cloud save failed \u2014 saved on this device only. Check your connection and try again.", true);
      return false;
    }
    return true;
  } catch(e) { console.warn("Supabase upsert error:", e); toast("\u26a0\ufe0f Cloud save failed \u2014 saved on this device only. Check your connection and try again.", true); return false; }
}

async function sbDelete(table, id) {
  try {
    var r = await fetch(SB_URL+"/rest/v1/"+table+"?id=eq."+id, {
      method: "DELETE",
      headers: {"apikey":SB_KEY,"Authorization":"Bearer "+SB_KEY}
    });
    if (!r.ok) {
      console.warn("sbDelete error:", table, r.status, await r.text());
      toast("\u26a0\ufe0f Cloud delete failed \u2014 this may reappear until it syncs. Check your connection.", true);
      return false;
    }
    return true;
  } catch(e) { console.warn("Supabase delete error:", e); toast("\u26a0\ufe0f Cloud delete failed \u2014 this may reappear until it syncs. Check your connection.", true); return false; }
}

// ── COLOUR THEMES ────────────────────────────────────────────────
var THEME_STORE = "spcrm_theme_v1";
var THEMES = {
  default:      {name:"Theme 1",  sub:"Default (Navy & Amber)",       emoji:"\uD83D\uDD37", navy:"#0033A0", accent:"#FFB900", alt:"#f7f9fc"},
  leeds:        {name:"Theme 2",  sub:"Leeds Rhinos",                  emoji:"\uD83E\uDD8F", navy:"#0C64A3", accent:"#F1BE17", alt:"#E6F0FA"},
  wigan:        {name:"Theme 3",  sub:"Wigan Warriors",                emoji:"\uD83C\uDF52", navy:"#D31718", accent:"#212121", alt:"#FAFAFA"},
  sthelens:     {name:"Theme 4",  sub:"St Helens",                     emoji:"\uD83D\uDD34", navy:"#F0082E", accent:"#1E1E1E", alt:"#F9F9F9"},
  warrington:   {name:"Theme 5",  sub:"Warrington Wolves",              emoji:"\uD83D\uDC3A", navy:"#00529C", accent:"#FFF300", alt:"#EAF2F8"},
  castleford:   {name:"Theme 6",  sub:"Castleford Tigers",              emoji:"\uD83D\uDC05", navy:"#FF6820", accent:"#000000", alt:"#FFF2EC"},
  hullkr:       {name:"Theme 7",  sub:"Hull Kingston Rovers",           emoji:"\uD83E\uDD85", navy:"#D01F26", accent:"#A0A0A0", alt:"#FCF8F8"},
  hullfc:       {name:"Theme 8",  sub:"Hull FC",                        emoji:"\uD83C\uDF11", navy:"#000000", accent:"#7F8C8D", alt:"#F5F5F5"},
  leigh:        {name:"Theme 9",  sub:"Leigh Leopards",                 emoji:"\uD83D\uDC06", navy:"#C2185B", accent:"#E0A96D", alt:"#FAF4EF"},
  york:         {name:"Theme 10", sub:"York Knights",                   emoji:"\uD83D\uDEE1\uFE0F", navy:"#111111", accent:"#D4AF37", alt:"#F5F5F7"},
  bradford:     {name:"Theme 11", sub:"Bradford Bulls",                 emoji:"\uD83D\uDC02", navy:"#D2232A", accent:"#FFC20E", alt:"#FAFAFA"},
  toulouse:     {name:"Theme 12", sub:"Toulouse Olympique",             emoji:"\u2694\uFE0F", navy:"#0F4C81", accent:"#A3C1AD", alt:"#F0F4F8"},
  catalans:     {name:"Theme 13", sub:"Catalans Dragons",                emoji:"\uD83D\uDC09", navy:"#E30613", accent:"#FFED00", alt:"#FFFBEA"},
  wakefield:    {name:"Theme 14", sub:"Wakefield Trinity",               emoji:"\u2694\uFE0F", navy:"#0F2C59", accent:"#E21E26", alt:"#F4F6F9"},
  huddersfield: {name:"Theme 15", sub:"Huddersfield Giants",             emoji:"\uD83E\uDDF1", navy:"#7A263A", accent:"#F1C40F", alt:"#FDF3F5"},
  cb1:          {name:"Theme 16", sub:"Colourblind-safe \u2014 Blue & Orange",       emoji:"\uD83D\uDD35", navy:"#0072B2", accent:"#E69F00", alt:"#EAF4FB"},
  cb2:          {name:"Theme 17", sub:"Colourblind-safe \u2014 Teal & Vermillion",   emoji:"\uD83D\uDFE2", navy:"#009E73", accent:"#D55E00", alt:"#EAFAF4"},
  cb3:          {name:"Theme 18", sub:"Colourblind-safe \u2014 Black & Yellow (max contrast)", emoji:"\u26AB", navy:"#1A1A1A", accent:"#F0E442", alt:"#F7F7F7"}
};
function hex2hsl(hex){
  hex = hex.replace("#","");
  if(hex.length===3) hex = hex.split("").map(function(c){return c+c;}).join("");
  var r=parseInt(hex.substr(0,2),16)/255, g=parseInt(hex.substr(2,2),16)/255, b=parseInt(hex.substr(4,2),16)/255;
  var max=Math.max(r,g,b), min=Math.min(r,g,b), h,s,l=(max+min)/2;
  if(max===min){ h=0; s=0; }
  else{
    var d=max-min;
    s = l>0.5 ? d/(2-max-min) : d/(max+min);
    if(max===r) h=(g-b)/d+(g<b?6:0);
    else if(max===g) h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h/=6;
  }
  return {h:h*360, s:s*100, l:l*100};
}
function hsl2hex(h,s,l){
  h/=360; s/=100; l/=100;
  var r,g,b;
  if(s===0){ r=g=b=l; }
  else{
    var hue2rgb=function(p,q,t){ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; };
    var q = l<0.5 ? l*(1+s) : l+s-l*s;
    var p = 2*l-q;
    r=hue2rgb(p,q,h+1/3); g=hue2rgb(p,q,h); b=hue2rgb(p,q,h-1/3);
  }
  var toHex=function(x){ var v=Math.round(x*255).toString(16); return v.length===1?"0"+v:v; };
  return "#"+toHex(r)+toHex(g)+toHex(b);
}
function themeShade(hex, targetL){ var c=hex2hsl(hex); return hsl2hex(c.h, c.s, targetL); }
function themeRgbShift(hex, delta){
  hex = hex.replace("#","");
  var num = parseInt(hex,16);
  var r=Math.min(255,Math.max(0,((num>>16)&255)+delta));
  var g=Math.min(255,Math.max(0,((num>>8)&255)+delta));
  var b=Math.min(255,Math.max(0,(num&255)+delta));
  return "#"+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1);
}
function applyThemeVars(key){
  var t = THEMES[key] || THEMES.default;
  var root = document.documentElement.style;
  // Header/brand colour — lightness is normalised so white text (used throughout on --navy)
  // always stays readable, whatever brand colour is picked.
  root.setProperty("--navy",  themeShade(t.navy, 33));
  root.setProperty("--navy2", themeShade(t.navy, 26));
  root.setProperty("--navy3", themeShade(t.navy, 20));
  // Accent colour — same normalisation trick for the avatar/border fills that use it.
  root.setProperty("--red",  themeShade(t.accent, 50));
  root.setProperty("--red2", themeShade(t.accent, 62));
  root.setProperty("--red3", themeShade(t.accent, 32));
  // Backgrounds — used only behind normal text, so no contrast risk here.
  root.setProperty("--alt", t.alt);
  root.setProperty("--bg", themeRgbShift(t.alt, -8));
  // Note: --border/--muted/--surface/--text and the green/amber/red/blue status-badge
  // colours (--gbg/--gtxt/--abg/--atxt/--rbg/--rtxt/--lbg/--ltxt/--grbg/--grtxt) are left
  // untouched by every theme, so the colourblind-safe indicators stay consistent.
}
function loadThemeKey(){
  try{ var s=localStorage.getItem(THEME_STORE); if(s && THEMES[s]) return s; }catch(e){}
  return "default";
}
function saveThemeKey(key){
  try{ localStorage.setItem(THEME_STORE, key); }catch(e){}
  sbUpsert("settings","theme",{key:"theme",value:key});
}
async function syncThemeFromCloud(){
  try{
    var rows = await sbGet("settings");
    if(rows){
      var row = rows.find(function(r){ return r && r.key==="theme"; });
      if(row && row.value && THEMES[row.value]){
        applyThemeVars(row.value);
        try{ localStorage.setItem(THEME_STORE, row.value); }catch(e){}
      }
    }
  }catch(e){ console.warn("theme cloud sync failed", e); }
}
applyThemeVars(loadThemeKey());
syncThemeFromCloud();

async function sbSaveAll(table, items, idField) {
  if (!items || !items.length) return;
  try {
    var chunkSize = 50;
    for (var i = 0; i < items.length; i += chunkSize) {
      var chunk = items.slice(i, i + chunkSize);
      var body = chunk.map(function(item){
        return {
          id: String(item[idField||"id"]),
          data: item,
          updated_at: new Date().toISOString()
        };
      });
      var r = await fetch(SB_URL+"/rest/v1/"+table, {
        method: "POST",
        headers: {
          "apikey": SB_KEY,
          "Authorization": "Bearer "+SB_KEY,
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Prefer": "resolution=merge-duplicates"
        },
        body: JSON.stringify(body)
      });
      if (!r.ok) {
        var errText = await r.text();
        console.warn("sbSaveAll error:", table, r.status, errText);
        try{document.getElementById("sbStatus").textContent="\u26a0\ufe0f";document.getElementById("sbStatus").title="Save error: "+errText.substring(0,60);}catch(e){}
        toast("\u26a0\ufe0f Cloud save failed \u2014 saved on this device only. Check your connection and try again.", true);
        return false;
      }
    }
    try{document.getElementById("sbStatus").textContent="\u2601\ufe0f";document.getElementById("sbStatus").title="Cloud synced";}catch(e){}
    return true;
  } catch(e) {
    console.warn("Supabase saveAll error:", e);
    try{document.getElementById("sbStatus").textContent="\u26a0\ufe0f";document.getElementById("sbStatus").title="Offline: "+e.message;}catch(e2){}
    toast("\u26a0\ufe0f Cloud save failed \u2014 saved on this device only. Check your connection and try again.", true);
    return false;
  }
}

var sbReady = false;

async function ensureBirthdayReminders() {
  // For every birthday, make sure there's a diary entry for its NEXT upcoming occurrence.
  // If the only existing entry is for a date that's already passed, create a fresh one.
  var today = new Date();
  var createdAny = false;

  birthdays.forEach(function(b){
    if (!b.date) return;
    var dp = b.date.split("-");
    if (dp.length !== 3) return;
    var bdMonth = parseInt(dp[1]) - 1;
    var bdDay = parseInt(dp[2]);

    var nextYear = today.getFullYear();
    var nextOccurrence = new Date(nextYear, bdMonth, bdDay);
    // Use start-of-day comparison so "today" still counts as upcoming, not passed
    var todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    if (nextOccurrence < todayStart) { nextYear++; nextOccurrence = new Date(nextYear, bdMonth, bdDay); }

    // Does a diary entry already exist for this exact upcoming occurrence?
    var hasUpcoming = diaryEvents.some(function(e){
      return e.bdId === b.id && e.year === nextYear && e.month === bdMonth && e.day === bdDay;
    });

    if (!hasUpcoming) {
      var isAnniv = b.eventKind === "anniversary";
      var titleText2 = isAnniv ? "\uD83D\uDC8D " + (b.annivLabel||"Anniversary") + ": " + (b.name||"") : "\uD83C\uDF82 Birthday: " + (b.name||"");
      diaryEvents.push({
        id: "EV-BD-" + Date.now() + "-" + Math.floor(Math.random()*10000),
        bdId: b.id,
        year: nextYear,
        month: bdMonth,
        day: bdDay,
        hour: null,
        minute: null,
        allDay: true,
        type: isAnniv ? "Anniversary" : "Birthday",
        title: titleText2,
        notes: b.company || "",
        withName: b.linkedType !== "other" ? (b.name||"") : "",
        withType: b.linkedType !== "other" ? (b.linkedType||"none") : "none",
        completed: false,
        isBirthday: true,
        category: b.category || "personal"
      });
      createdAny = true;
    }
  });

  if (createdAny) {
    saveDiary();
    console.log("Birthday reminders refreshed \u2713");
  }
}

async function loadFromSupabase() {
  try {
    var [c, r, s, b, comp, d, w, docs2, enq, tsk, arch, ff] = await Promise.all([
      sbGet("clients"), sbGet("reps"), sbGet("samples"),
      sbGet("birthdays"), sbGet("complaints"), sbGet("diary_events"),
      sbGet("websites"), sbGet("docs"), sbGet("enquiries"), sbGet("tasks"),
      sbGet("archived_clients"), sbGet("footfall_entries")
    ]);

    // CLIENTS: Supabase is master. If empty, push local up.
    if (c && c.length > 0) {
      clients = c;
      console.log("Loaded from Supabase:", clients.length, "clients");
    } else {
      console.log("Cloud empty - pushing", clients.length, "clients up");
      await sbSaveAll("clients", clients, "id");
    }

    // REPS: same logic
    if (r && r.length > 0) {
      reps = r;
    } else if (reps && reps.length > 0) {
      await sbSaveAll("reps", reps, "id");
    }

    // Other tables - use cloud if available
    if (s && s.length > 0) samples = s;
    if (b && b.length > 0) birthdays = b;
    if (comp && comp.length > 0) complaints = comp;
    if (d && d.length > 0) diaryEvents = d;
    if (enq && enq.length > 0) enquiries = enq;
    if (tsk && tsk.length > 0) tasks = tsk;
    if (ff && ff.length > 0) footfallEntries = ff;
    if (w && w.length > 0) websites = w;
    if (arch && arch.length > 0) {
      archivedClients = arch;
    } else if (archivedClients && archivedClients.length > 0) {
      await sbSaveAll("archived_clients", archivedClients, "id");
    }
    // One-time fix: collapse duplicate/id-less website records (same legacy bug as docs - created a fresh duplicate on every load)
    var seenWebKeys = {};
    var cleanWebsites = [];
    var foundWebDuplicatesOrMissingIds = false;
    websites.forEach(function(site){
      var key = (site.name||"") + "|" + (site.url||"");
      if (!site.id) foundWebDuplicatesOrMissingIds = true;
      if (seenWebKeys[key]) { foundWebDuplicatesOrMissingIds = true; return; } // skip duplicate
      seenWebKeys[key] = true;
      cleanWebsites.push(site);
    });
    cleanWebsites.forEach(function(site, idx){
      if (!site.id) site.id = "WEB-" + Date.now() + "-" + idx;
    });
    if (foundWebDuplicatesOrMissingIds) {
      websites = cleanWebsites;
      var oldWebRows = await fetch(SB_URL+"/rest/v1/websites?or=(id.not.is.null,id.is.null)", {
        method: "DELETE",
        headers: {"apikey":SB_KEY,"Authorization":"Bearer "+SB_KEY}
      }).catch(function(){});
      await sbSaveAll("websites", websites, "id");
      try { localStorage.setItem(WEB_STORE, JSON.stringify(websites)); } catch(e) {}
    }
    if (docs2 && docs2.length > 0) docs = docs2;
    // One-time fix: collapse duplicate/id-less doc records (legacy bug created a fresh duplicate on every load)
    var seenDocKeys = {};
    var cleanDocs = [];
    var foundDuplicatesOrMissingIds = false;
    docs.forEach(function(doc){
      var key = (doc.name||"") + "|" + (doc.url||"");
      if (!doc.id) foundDuplicatesOrMissingIds = true;
      if (seenDocKeys[key]) { foundDuplicatesOrMissingIds = true; return; } // skip duplicate
      seenDocKeys[key] = true;
      cleanDocs.push(doc);
    });
    cleanDocs.forEach(function(doc, idx){
      if (!doc.id) doc.id = "DOC-" + Date.now() + "-" + idx;
    });
    if (foundDuplicatesOrMissingIds) {
      docs = cleanDocs;
      // Clear the table fully first since old id-less rows can't be targeted individually, then push the clean set
      var oldDocRows = await fetch(SB_URL+"/rest/v1/docs?or=(id.not.is.null,id.is.null)", {
        method: "DELETE",
        headers: {"apikey":SB_KEY,"Authorization":"Bearer "+SB_KEY}
      }).catch(function(){});
      await sbSaveAll("docs", docs, "id");
      try { localStorage.setItem(DOCS_STORE, JSON.stringify(docs)); } catch(e) {}
    }

    sbReady = true;
    console.log("Supabase ready! Clients:", clients.length);
    try{document.getElementById("sbStatus").textContent="☁️";document.getElementById("sbStatus").title="Cloud synced";}catch(e){}
    await ensureBirthdayReminders();
    updateStats(); renderList(); renderDash();
  } catch(e) {
    console.warn("Supabase load failed, using localStorage:", e);
    try{document.getElementById("sbStatus").textContent="⚠️";document.getElementById("sbStatus").title="Cloud offline";}catch(e2){}
    sbReady = false;
  }
}

// Override save functions to also save to Supabase
var _origSaveC = null;
function saveC() {
  try { localStorage.setItem(STORE, JSON.stringify(clients)); } catch(e) {}
  updateStats();
  sbSaveAll("clients", clients, "id");
}
function saveReps() {
  try { localStorage.setItem(RSTORE, JSON.stringify(reps)); } catch(e) {}
  sbSaveAll("reps", reps, "id");
}
function saveSamples() {
  try { localStorage.setItem(SSTORE, JSON.stringify(samples)); } catch(e) {}
  sbSaveAll("samples", samples, "id");
}
function saveBirthdays() {
  try { localStorage.setItem(BSTORE, JSON.stringify(birthdays)); } catch(e) {}
  sbSaveAll("birthdays", birthdays, "id");
}
function saveComplaints() {
  try { localStorage.setItem(CSTORE, JSON.stringify(complaints)); } catch(e) {}
  sbSaveAll("complaints", complaints, "id");
}
function saveDiary() {
  console.log("saveDiary called, events:", diaryEvents.length);
  try { localStorage.setItem(DIARY_STORE, JSON.stringify(diaryEvents)); } catch(e) {}
  sbSaveAll("diary_events", diaryEvents, "id");
}

function getPersonalDiaryEvents() {
  return diaryEvents.filter(function(e){ return e.category === "personal"; });
}
function getWorkDiaryEvents() {
  return diaryEvents.filter(function(e){ return e.category !== "personal"; });
}
function getPersonalBirthdays() {
  return birthdays.filter(function(b){ return b.category === "personal"; });
}
function getWorkBirthdays() {
  return birthdays.filter(function(b){ return b.category !== "personal"; });
}

function csvEscape(val) {
  if (val === null || val === undefined) return "";
  var s = String(val);
  if (s.indexOf(",") !== -1 || s.indexOf("\"") !== -1 || s.indexOf("\n") !== -1) {
    s = "\"" + s.replace(/"/g, "\"\"") + "\"";
  }
  return s;
}

function csvDownload(rows, filenamePrefix) {
  var csv = rows.map(function(r){ return r.map(csvEscape).join(","); }).join("\n");
  var blob = new Blob([csv], {type:"text/csv;charset=utf-8;"});
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  var today = new Date();
  var fname = filenamePrefix + "-" + today.getFullYear() + "-" + String(today.getMonth()+1).padStart(2,"0") + "-" + String(today.getDate()).padStart(2,"0") + ".csv";
  a.href = url; a.download = fname;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function exportWebsitesCSV() {
  if (!websites.length) { toast("No websites to export"); return; }
  var rows = [["Name","URL","Category","Description"]];
  websites.forEach(function(w){
    rows.push([w.name||"", w.url||"", w.category||"", w.description||""]);
  });
  csvDownload(rows, "websites-export");
  toast("Exported " + websites.length + " websites \u2713");
}

function exportClientsCSV() {
  if (!clients.length) { toast("No clients to export"); return; }
  var rows = [["Name","Primary Contact","Primary Phone","Secondary Contact","Secondary Phone"]];
  clients.forEach(function(c){
    rows.push([c.name||"", c.contact||"", c.mobile||"", c.contact2||"", c.mobile2||""]);
  });
  csvDownload(rows, "clients-export");
  toast("Exported " + clients.length + " clients \u2713");
}

function exportRepsCSV() {
  if (!reps.length) { toast("No reps to export"); return; }
  var rows = [["Name","Phone","Email"]];
  reps.forEach(function(r){
    var phone = r.mobile || r.tel || "";
    rows.push([r.name||"", phone, r.email||""]);
  });
  csvDownload(rows, "reps-export");
  toast("Exported " + reps.length + " reps \u2713");
}

function exportPersonalData() {
  var personalEvts = getPersonalDiaryEvents();
  var personalBdays = getPersonalBirthdays();

  if (!personalEvts.length && !personalBdays.length) {
    toast("No personal entries to export");
    return;
  }

  // RecordType distinguishes Event vs Birthday vs Anniversary so re-import is unambiguous.
  // DateRaw is the actual stored format the app uses internally (YYYY-MM-DD for birthdays/
  // anniversaries, Y-M-D numeric fields for diary events) so nothing gets lost on the way out.
  var rows = [["RecordType","Title","Name","AnnivLabel","DateRaw","Year","Month","Day","AllDay","Hour","Minute","EventType","Notes","WithName","WithType"]];
  personalEvts.forEach(function(e){
    rows.push(["Event", e.title||"", "", "", "", e.year, e.month, e.day, e.allDay?"Yes":"No", e.allDay?"":e.hour, e.allDay?"":e.minute, e.type||"", e.notes||"", e.withName||"", e.withType||""]);
  });
  personalBdays.forEach(function(b){
    var kind = b.eventKind==="anniversary" ? "Anniversary" : "Birthday";
    rows.push([kind, "", b.name||"", b.annivLabel||"", b.date||"", "", "", "", "", "", "", "", b.company||"", "", b.linkedType||""]);
  });

  csvDownload(rows, "personal-data-export");
  toast("Exported " + personalEvts.length + " events + " + personalBdays.length + " birthdays/anniversaries \u2713");
}

function importPersonalDataFile(file) {
  var reader = new FileReader();
  reader.onload = function(e) {
    try {
      var text = e.target.result;
      var lines = text.split(/\r?\n/).filter(function(l){ return l.trim().length > 0; });
      if (lines.length < 2) { toast("File looks empty"); return; }

      function parseCsvLine(line) {
        var result = []; var cur = ""; var inQuotes = false;
        for (var i = 0; i < line.length; i++) {
          var ch = line[i];
          if (inQuotes) {
            if (ch === '"') {
              if (line[i+1] === '"') { cur += '"'; i++; } else { inQuotes = false; }
            } else { cur += ch; }
          } else {
            if (ch === '"') inQuotes = true;
            else if (ch === ',') { result.push(cur); cur = ""; }
            else cur += ch;
          }
        }
        result.push(cur);
        return result;
      }

      var header = parseCsvLine(lines[0]);
      var expectedHeader = "RecordType";
      if (header[0] !== expectedHeader) {
        toast("This doesn't look like a SPCRM personal data export file");
        return;
      }

      var eventsAdded = 0, bdaysAdded = 0;
      for (var i = 1; i < lines.length; i++) {
        var f = parseCsvLine(lines[i]);
        var recordType = f[0];
        if (recordType === "Event") {
          diaryEvents.push({
            id: "EV-IMPORT-" + Date.now() + "-" + i,
            title: f[1] || "",
            year: parseInt(f[5]) || new Date().getFullYear(),
            month: parseInt(f[6]) || 0,
            day: parseInt(f[7]) || 1,
            allDay: f[8] === "Yes",
            hour: f[8] === "Yes" ? null : (parseInt(f[9]) || 0),
            minute: f[8] === "Yes" ? null : (parseInt(f[10]) || 0),
            type: f[11] || "Other",
            notes: f[12] || "",
            withName: f[13] || "",
            withType: f[14] || "none",
            completed: false,
            category: "personal"
          });
          eventsAdded++;
        } else if (recordType === "Birthday" || recordType === "Anniversary") {
          var bdId = "BD-IMPORT-" + Date.now() + "-" + i;
          birthdays.push({
            id: bdId,
            name: f[2] || "",
            company: f[12] || "",
            type: "Other",
            date: f[4] || "",
            linkedType: f[14] || "other",
            category: "personal",
            eventKind: recordType === "Anniversary" ? "anniversary" : "birthday",
            annivLabel: f[3] || ""
          });
          bdaysAdded++;
        }
      }

      saveDiary();
      saveBirthdays();
      renderDiaryView && renderDiaryView();
      renderDash();
      toast("Imported \u2713 " + eventsAdded + " events, " + bdaysAdded + " birthdays/anniversaries");
    } catch(err) {
      toast("Couldn't read that file \u2014 make sure it's a SPCRM personal export CSV");
    }
  };
  reader.readAsText(file);
}

function openWipeConfirm(scope) {
  // scope: "personal" | "work" | "all"
  var evtsToWipe = scope==="personal" ? getPersonalDiaryEvents() : scope==="work" ? getWorkDiaryEvents() : diaryEvents.slice();
  var bdaysToWipe = scope==="personal" ? getPersonalBirthdays() : scope==="work" ? getWorkBirthdays() : birthdays.slice();

  var labels = {personal:"personal", work:"work", all:"all"};
  var scopeLbl = labels[scope];

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:250;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;border-top:3px solid var(--rtxt)";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--rbg);padding:13px 16px";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:var(--rtxt)"; bht.textContent = "⚠ Wipe " + scopeLbl + " diary & birthdays";
  bh.appendChild(bht); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  var dCount = evtsToWipe.length;
  var bCount = bdaysToWipe.length;
  var warn = document.createElement("div"); warn.style.cssText = "font-size:12px;line-height:1.5;color:var(--text)";
  warn.textContent = "This will permanently delete " + dCount + " " + scopeLbl + " diary entries and " + bCount + " " + scopeLbl + " birthday records. This cannot be undone. Bank holidays and observances are calculated automatically and are not affected.";
  bd.appendChild(warn);

  if (scope === "personal") {
    var hint = document.createElement("div"); hint.style.cssText = "font-size:11px;color:#9333ea;background:#f4ecfd;padding:8px 10px;border-radius:var(--rs)";
    hint.textContent = "Tip: use Export Personal first if you want to keep a copy before deleting.";
    bd.appendChild(hint);
  }

  var lbl = document.createElement("label"); lbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-top:4px"; lbl.textContent = "Type DELETE to confirm";
  bd.appendChild(lbl);
  var confirmInp = document.createElement("input"); confirmInp.id = "wipe_confirm_inp"; confirmInp.placeholder = "DELETE"; confirmInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(confirmInp);

  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var wipeB = document.createElement("button"); wipeB.style.cssText = "padding:7px 16px;background:var(--rtxt);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer;opacity:.5"; wipeB.textContent = "Wipe " + scopeLbl;
  wipeB.disabled = true;
  confirmInp.addEventListener("input", function(){
    var ok = confirmInp.value.trim().toUpperCase() === "DELETE";
    wipeB.disabled = !ok;
    wipeB.style.opacity = ok ? "1" : ".5";
  });
  wipeB.addEventListener("click", async function(){
    if (confirmInp.value.trim().toUpperCase() !== "DELETE") return;
    wipeB.disabled = true; wipeB.textContent = "Wiping...";
    await wipeDiaryEvents(evtsToWipe);
    await wipeBirthdays(bdaysToWipe);
    document.body.removeChild(overlay);
    renderDiaryView();
    renderDash();
    toast("Wiped \u2713 " + dCount + " " + scopeLbl + " diary entries, " + bCount + " " + scopeLbl + " birthdays deleted");
  });
  foot.appendChild(cancelB); foot.appendChild(wipeB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ confirmInp.focus(); }, 100);
}

async function wipeDiaryEvents(eventsToDelete) {
  var idsToDelete = eventsToDelete.map(function(e){ return e.id; });
  var idSet = {}; idsToDelete.forEach(function(id){ idSet[id] = true; });
  // Delete every targeted row individually from Supabase so it doesn't resurface on next sync
  for (var i = 0; i < idsToDelete.length; i++) {
    await sbDelete("diary_events", idsToDelete[i]);
  }
  diaryEvents = diaryEvents.filter(function(e){ return !idSet[e.id]; });
  try { localStorage.setItem(DIARY_STORE, JSON.stringify(diaryEvents)); } catch(e) {}
}

async function wipeBirthdays(birthdaysToDelete) {
  var idsToDelete = birthdaysToDelete.map(function(b){ return b.id; });
  var idSet = {}; idsToDelete.forEach(function(id){ idSet[id] = true; });
  for (var i = 0; i < idsToDelete.length; i++) {
    await sbDelete("birthdays", idsToDelete[i]);
  }
  birthdays = birthdays.filter(function(b){ return !idSet[b.id]; });
  try { localStorage.setItem(BSTORE, JSON.stringify(birthdays)); } catch(e) {}
  try { renderBirthdaysView && renderBirthdaysView(); } catch(e) {}
}

function openWipeQuotesConfirm() {
  var totalQuotes = 0;
  clients.forEach(function(c){ (c.log||[]).forEach(function(l){ if (l.quote) totalQuotes++; }); });

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:250;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;border-top:3px solid #c0392b";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--rbg);padding:13px 16px";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:var(--rtxt)"; bht.textContent = "\u26A0 Wipe all quotes";
  bh.appendChild(bht); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";
  var warn = document.createElement("div"); warn.style.cssText = "font-size:12px;line-height:1.5;color:var(--text)";
  warn.textContent = "This will permanently delete " + totalQuotes + " quotes across every client in your black book \u2014 every status (Quote, Confirmed, Paid, Collected, Lost, Expired). Plain interactions (calls, visits, notes with no quote attached) will NOT be touched. This cannot be undone.";
  bd.appendChild(warn);

  var lbl = document.createElement("label"); lbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-top:4px"; lbl.textContent = "Type DELETE ALL QUOTES to confirm";
  bd.appendChild(lbl);
  var confirmInp = document.createElement("input"); confirmInp.placeholder = "DELETE ALL QUOTES"; confirmInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(confirmInp);
  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var wipeB = document.createElement("button"); wipeB.style.cssText = "padding:7px 16px;background:#c0392b;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer;opacity:.5"; wipeB.textContent = "Wipe all quotes";
  wipeB.disabled = true;
  confirmInp.addEventListener("input", function(){
    var ok = confirmInp.value.trim().toUpperCase() === "DELETE ALL QUOTES";
    wipeB.disabled = !ok; wipeB.style.opacity = ok ? "1" : ".5";
  });
  wipeB.addEventListener("click", async function(){
    if (confirmInp.value.trim().toUpperCase() !== "DELETE ALL QUOTES") return;
    wipeB.disabled = true; wipeB.textContent = "Wiping...";
    clients.forEach(function(c){
      c.log = (c.log||[]).filter(function(l){ return !l.quote; });
    });
    saveC();
    document.body.removeChild(overlay);
    renderDash();
    toast("Wiped \u2713 " + totalQuotes + " quotes deleted from " + clients.length + " clients");
  });
  foot.appendChild(cancelB); foot.appendChild(wipeB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ confirmInp.focus(); }, 100);
}

function saveWebsites() {
  try { localStorage.setItem(WEB_STORE, JSON.stringify(websites)); } catch(e) {}
  sbSaveAll("websites", websites, "id");
}
function saveDocs() {
  try { localStorage.setItem(DOCS_STORE, JSON.stringify(docs)); } catch(e) {}
  sbSaveAll("docs", docs, "id");
}

// ── PASSWORD ──────────────────────────────────────────────────────
document.getElementById("gateInput").addEventListener("keydown",function(e){if(e.key==="Enter")checkPassword();});
function logOut() {
  if(confirm("Log out of CRM?")) {
    try { sessionStorage.removeItem("sftc_auth"); } catch(e) {}
    document.getElementById("gateOverlay").style.display = "flex";
    document.getElementById("gateInput").value = "";
    toast("Logged out \u2713");
  }
}


function checkPassword(){
  if(document.getElementById("gateInput").value===getCurrentPassword()){
    document.getElementById("gateOverlay").style.display="none";
    try{sessionStorage.setItem("sftc_auth","1");}catch(e){}
    // Test Supabase connection
    setTimeout(async function(){
      try {
        var testUrl = "https://ogkyemjiosgedwgqfvyy.supabase.co/rest/v1/clients?select=id&limit=1";
        var testKey = SB_KEY;
        var r = await fetch(testUrl, {
          headers:{"apikey":testKey,"Authorization":"Bearer "+testKey,"Accept":"application/json"}
        });
        var txt = await r.text();
        if(r.ok){ 
          toast("\u2601\uFE0F Cloud connected! \u2713");
          try{document.getElementById("sbStatus").textContent="\u2601\uFE0F";}catch(e){}
          try{document.getElementById("sbStatus").title="Cloud connected";}catch(e){}
        } else { 
          console.warn("Supabase test failed:", r.status, txt);
          toast("\u26A0\uFE0F Cloud error "+r.status+" - "+txt.substring(0,40));
          try{document.getElementById("sbStatus").textContent="\u26A0\uFE0F";}catch(e){}
          document.getElementById("sbStatus").title="Error "+r.status;
        }
      } catch(e){ 
        console.warn("Connection test error:", e);
        toast("\u26A0\uFE0F Cloud offline - saving locally only");
      }
    }, 1500);
  }else{
    document.getElementById("gateError").style.display="block";
    document.getElementById("gateInput").value="";
    document.getElementById("gateInput").focus();
  }
}
try{if(sessionStorage.getItem("sftc_auth")==="1"){var g=document.getElementById("gateOverlay");if(g)g.style.display="none";}}catch(e){}

// ── DATA ──────────────────────────────────────────────────────────
var STORE="sftc_v2",RSTORE="sftc_reps_v1",SSTORE="sftc_samples_v1",BSTORE="sftc_bdays_v1",CSTORE="sftc_complaints_v1";
var ARCHIVE_STORE="spcrm_archive_v1";
var archivedClients=[];
var CLIENTS_DATA=[];
var DEFAULT_REPS=[{"id": "REP-26428", "name": "aldo berettoni", "manufacturer": "Other", "company": "stairrods", "tel": "07971 173560", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-35356", "name": "Andy Thomas", "manufacturer": "Other", "company": "Rewmar", "tel": "07710 740189", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-66958", "name": "andy cormack", "manufacturer": "Altro", "company": "altro", "tel": "07776 493950", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-10499", "name": "Andy Wetherill", "manufacturer": "Moduleo", "company": "Likewise", "tel": "07939 201329", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-19990", "name": "Antony Tittersly", "manufacturer": "Other", "company": "", "tel": "07854 681056", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-6591", "name": "Brad Scoley", "manufacturer": "Other", "company": "Donny", "tel": "07828 673045", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-53803", "name": "Cameron Bradshaw", "manufacturer": "Mapei", "company": "Mapei", "tel": "07817 039051", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-53901", "name": "Curley Broom", "manufacturer": "Other", "company": "Uzin", "tel": "07825 056143", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-43598", "name": "Dane Hadfield", "manufacturer": "Other", "company": "", "tel": "07736 649975", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-96688", "name": "Dave Turner", "manufacturer": "Polyflor", "company": "Polyflor", "tel": "07971 611017", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-13922", "name": "Dawn Formose", "manufacturer": "Other", "company": "Trade Choice", "tel": "07979 980336", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-53219", "name": "Dean Peaker", "manufacturer": "Other", "company": "", "tel": "07971611018", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-20232", "name": "Graeme Orion Tools", "manufacturer": "Other", "company": "", "tel": "07772 022266", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-7524", "name": "Harry Honour", "manufacturer": "Other", "company": "Ultr Floor", "tel": "07825 064071", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-16860", "name": "James Keracoll", "manufacturer": "Other", "company": "", "tel": "07875 339887", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-62396", "name": "jamie kerslake", "manufacturer": "Other", "company": "quantum", "tel": "07976 702953", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-75604", "name": "John Barraclogh", "manufacturer": "Other", "company": "Heckmondwike", "tel": "07831 808955", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-35738", "name": "John Rowling\\'s", "manufacturer": "Other", "company": "F Ball Adhesive", "tel": "07710 182932", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-23577", "name": "Kyle Tilemaster", "manufacturer": "Other", "company": "", "tel": "07947 974577", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-85051", "name": "Mitchel Zanetti", "manufacturer": "Other", "company": "", "tel": "07789 225233", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-18947", "name": "Nick Bentley", "manufacturer": "Other", "company": "C P Assessments", "tel": "07958 155864", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-50749", "name": "Pat Pearson Tarket", "manufacturer": "Tarkett", "company": "", "tel": "07920 701911", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-6135", "name": "Patrick Manni", "manufacturer": "Other", "company": "Genesis", "tel": "07825 416784", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-67270", "name": "Paul Hutchinson", "manufacturer": "Mapei", "company": "Mapei", "tel": "07779 038213", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-16810", "name": "Peter Lee", "manufacturer": "Other", "company": "Toolbank", "tel": "07970 473020", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-67451", "name": "Peter Zanittie", "manufacturer": "Other", "company": "", "tel": "07836282845", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-53751", "name": "Phil Moorhouse", "manufacturer": "Other", "company": "gradus", "tel": "07831 322139", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-79486", "name": "Rich Haseltine", "manufacturer": "Other", "company": "", "tel": "07538 836276", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-48848", "name": "Richard Cook", "manufacturer": "Other", "company": "Spotnails", "tel": "07917 623150", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-74902", "name": "Richie Roberts Qep", "manufacturer": "Other", "company": "", "tel": "07834 739011", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-20750", "name": "Steve Toolbank", "manufacturer": "Other", "company": "", "tel": "07815 121607", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-19867", "name": "Stu Genesis", "manufacturer": "Other", "company": "", "tel": "07818 255049", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}, {"id": "REP-8705", "name": "Stuart Jackson", "manufacturer": "Other", "company": "Spotnails", "tel": "07917 623147", "mobile": "", "email": "", "website": "", "notes": "Imported from phone contacts", "lastContact": "", "nextVisit": ""}];
var DEFAULT_PRODUCTS=["Carpet", "Carpet Adhesive", "Carpet Tiles", "Carpet Trims", "Carpet Underlay", "Contract Adhesive", "Contract Trims", "Contract Vinyl", "Engineered Wood", "Gripper", "Laminate", "Laminate Scotia", "Laminate Trims", "Laminate Underlay", "LVT", "LVT Adhesive", "Nosings", "Plywood", "Samples", "Screed", "SPC", "Spray Glue", "Tools", "Vinyl", "Wood Accessories", "Wood Adhesive", "Other"];
var TOOL_CATEGORIES=[
  {name:"Big boy toys", note:"Electric Staple Gun, Jamb Saw, Grinder"},
  {name:"Blades", note:""},
  {name:"Carpet fitting tools", note:"Kickers, Staple Hammer, Stair Tool, Heat Seam Iron"},
  {name:"Fixings", note:"Nails, Gripper Glue, Screws, Staples"},
  {name:"Kneepads", note:""},
  {name:"Knives", note:""},
  {name:"Laminate tools", note:"Tapping Block, Jigsaw Blades, Spacers, Saw"},
  {name:"LVT tools", note:"Glue Spreader, Screed Trowel, Mixing Bucket"},
  {name:"Misc tools", note:"Screwdrivers, Scrapers, Tack Lifters, Hammers"},
  {name:"PPE", note:""}
];
var LVT_MANUFACTURERS=["Amtico", "AW Invictus", "Karndean", "Moduleo", "Nordikka", "Polyflor", "Quickstep"];
var LAMINATE_MANUFACTURERS=["Classen", "Egger", "Kronotex", "Life", "Quick Step", "Sanders & Fink"];
var CONTRACT_VINYL_MANUFACTURERS=["Altro", "Forbo", "Gerflor", "Polyflor", "Tarkett"];
var NOSINGS_MANUFACTURERS=["Genesis", "Gradus", "Quantum"];
var LVT_ADHESIVE_MANUFACTURERS=["Amtico", "F.Ball", "Karndean", "Uzin"];
var CONTRACT_ADHESIVE_MANUFACTURERS=["Amtico", "F.Ball", "Karndean", "Uzin"];
var CARPET_ADHESIVE_MANUFACTURERS=["Amtico", "F.Ball", "Karndean", "Uzin"];
var PLYWOOD_MANUFACTURERS=["Hanson Sp101", "Q Ply", "Sanders & Fink PFP1"];
var CONTRACT_TRIMS_MANUFACTURERS=["Genesis", "Gradus", "Quantum"];
var ENGINEERED_WOOD_MANUFACTURERS=["Life Flooring", "Pure Woods", "Sanders & Fink", "V4 Wood"];
// Shared lookup: which products have a sub-category dropdown, and what options it offers.
// To add a new product split later, add ONE entry here - every form (sale log, create quote, edit quote) reads from this.
var DEFAULT_PRODUCT_SUBCATS={
  "Tools": TOOL_CATEGORIES,
  "LVT": LVT_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Laminate": LAMINATE_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Contract Vinyl": CONTRACT_VINYL_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Nosings": NOSINGS_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "LVT Adhesive": LVT_ADHESIVE_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Contract Adhesive": CONTRACT_ADHESIVE_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Carpet Adhesive": CARPET_ADHESIVE_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Plywood": PLYWOOD_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Contract Trims": CONTRACT_TRIMS_MANUFACTURERS.map(function(m){return {name:m, note:""};}),
  "Engineered Wood": ENGINEERED_WOOD_MANUFACTURERS.map(function(m){return {name:m, note:""};})
};
var PRODUCTS_STORE="spcrm_products_v1";
var PRODUCT_SUBCATS_STORE="spcrm_product_subcats_v1";
// Sorts product names A-Z (case-insensitive), always pinning "Other" as the last entry.
function sortProductsList(arr){
  arr.sort(function(a,b){
    if(a==="Other") return 1;
    if(b==="Other") return -1;
    return a.localeCompare(b, undefined, {sensitivity:"base"});
  });
  return arr;
}
function loadProducts(){
  try { var r=localStorage.getItem(PRODUCTS_STORE); if(r) return sortProductsList(JSON.parse(r)); } catch(e){}
  return sortProductsList(DEFAULT_PRODUCTS.slice());
}
function saveProducts(){
  sortProductsList(PRODUCTS);
  try { localStorage.setItem(PRODUCTS_STORE, JSON.stringify(PRODUCTS)); } catch(e){}
  sbUpsert("settings","products",{key:"products",value:PRODUCTS});
}
async function syncProductsFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="products";});
      if(row&&Array.isArray(row.value)&&row.value.length){
        PRODUCTS.length=0; row.value.forEach(function(v){PRODUCTS.push(v);});
        sortProductsList(PRODUCTS);
        try{localStorage.setItem(PRODUCTS_STORE,JSON.stringify(PRODUCTS));}catch(e){}
      }
    }
  }catch(e){ console.warn("products cloud sync failed", e); }
}
function loadProductSubcats(){
  try { var r=localStorage.getItem(PRODUCT_SUBCATS_STORE); if(r) return JSON.parse(r); } catch(e){}
  return JSON.parse(JSON.stringify(DEFAULT_PRODUCT_SUBCATS));
}
function saveProductSubcats(){
  try { localStorage.setItem(PRODUCT_SUBCATS_STORE, JSON.stringify(PRODUCT_SUBCATS)); } catch(e){}
  sbUpsert("settings","product_subcats",{key:"product_subcats",value:PRODUCT_SUBCATS});
}
async function syncProductSubcatsFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="product_subcats";});
      if(row&&row.value&&Object.keys(row.value).length){
        for(var k in PRODUCT_SUBCATS){ delete PRODUCT_SUBCATS[k]; }
        for(var k2 in row.value){ PRODUCT_SUBCATS[k2]=row.value[k2]; }
        try{localStorage.setItem(PRODUCT_SUBCATS_STORE,JSON.stringify(PRODUCT_SUBCATS));}catch(e){}
      }
    }
  }catch(e){ console.warn("product subcats cloud sync failed", e); }
}
var PRODUCTS=loadProducts();
var PRODUCT_SUBCATS=loadProductSubcats();
syncProductsFromCloud();
syncProductSubcatsFromCloud();
var DOC_CATS_DEFAULT=["Fitting Instructions","Product Spec","Parts List","Price List","Safety Data","Brochure","Warranty","Other"];
var DOC_CATS_STORE="spcrm_doc_cats";
function loadDocCats(){try{var s=localStorage.getItem(DOC_CATS_STORE);if(s){var c=JSON.parse(s);if(Array.isArray(c)&&c.length)return c;}}catch(e){}return DOC_CATS_DEFAULT.slice();}
function saveDocCats(){
  try{localStorage.setItem(DOC_CATS_STORE,JSON.stringify(DOC_CATS));}catch(e){}
  sbUpsert("settings","doc_cats",{key:"doc_cats",value:DOC_CATS});
}
async function syncDocCatsFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="doc_cats";});
      if(row&&Array.isArray(row.value)&&row.value.length){
        DOC_CATS.length=0; row.value.forEach(function(v){DOC_CATS.push(v);});
        try{localStorage.setItem(DOC_CATS_STORE,JSON.stringify(DOC_CATS));}catch(e){}
      }
    }
  }catch(e){ console.warn("doc cats cloud sync failed", e); }
}
var DOC_CATS=loadDocCats();
syncDocCatsFromCloud();
var MANUFACTURERS_DEFAULT=["Aegean Sea", "Altro", "Amtico", "A.W - Invictus", "Axminster", "Brintons", "Camaro", "Carpenters", "Cormar", "F Ball", "Forbo", "Furlong", "Genesis", "Gerflor", "Gradus", "Heckmondwike", "Interface", "Kahrs", "Karndean", "Kelmore", "Kerakoll UK", "Likewise", "Luvanto", "Mapei", "Mercado", "Moduleo", "Orion", "Polyflor", "QEP", "Quantum", "Quick-Step", "Roberts - QEP", "R.S.Batemans", "Shaw", "Spotnails", "Stairrods", "Tarkett", "Ted Todd", "Toolbank", "Trade Choice", "Uzin", "Victoria", "Woodpecker", "Other"];
var MANUFACTURERS_STORE="spcrm_manufacturers";
var CLIENT_CATS_DEFAULT=["Existing Customer","Existing Customer (Dormant 12m+)","New - Walk In","New - Referral","Fitter"];
var CLIENT_CATS_STORE="spcrm_client_cats";
function loadManufacturers(){try{var s=localStorage.getItem(MANUFACTURERS_STORE);if(s){var c=JSON.parse(s);if(Array.isArray(c)&&c.length)return c;}}catch(e){}return MANUFACTURERS_DEFAULT.slice();}
function saveManufacturers(){
  try{localStorage.setItem(MANUFACTURERS_STORE,JSON.stringify(MANUFACTURERS));}catch(e){}
  sbUpsert("settings","manufacturers",{key:"manufacturers",value:MANUFACTURERS});
}
async function syncManufacturersFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="manufacturers";});
      if(row&&Array.isArray(row.value)&&row.value.length){
        MANUFACTURERS.length=0; row.value.forEach(function(v){MANUFACTURERS.push(v);});
        try{localStorage.setItem(MANUFACTURERS_STORE,JSON.stringify(MANUFACTURERS));}catch(e){}
      }
    }
  }catch(e){ console.warn("manufacturers cloud sync failed", e); }
}
function loadClientCats(){try{var s=localStorage.getItem(CLIENT_CATS_STORE);if(s){var c=JSON.parse(s);if(Array.isArray(c)&&c.length)return c;}}catch(e){}return CLIENT_CATS_DEFAULT.slice();}
function saveClientCats(){
  try{localStorage.setItem(CLIENT_CATS_STORE,JSON.stringify(CLIENT_CATS));}catch(e){}
  sbUpsert("settings","client_cats",{key:"client_cats",value:CLIENT_CATS});
}
async function syncClientCatsFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="client_cats";});
      if(row&&Array.isArray(row.value)&&row.value.length){
        CLIENT_CATS.length=0;
        row.value.forEach(function(v){CLIENT_CATS.push(v);});
        try{localStorage.setItem(CLIENT_CATS_STORE,JSON.stringify(CLIENT_CATS));}catch(e){}
      }
    }
  }catch(e){ console.warn("client cats cloud sync failed", e); }
}
var MANUFACTURERS=loadManufacturers();
syncManufacturersFromCloud();
var CLIENT_CATS=loadClientCats();
syncClientCatsFromCloud();
var SOURCING_STORE="spcrm_sourcing_v1";
var sourcing=[];
function loadSourcing(){try{var s=localStorage.getItem(SOURCING_STORE);if(s){var c=JSON.parse(s);if(Array.isArray(c))return c;}}catch(e){}return [];}
function saveSourcing(){
  try{localStorage.setItem(SOURCING_STORE,JSON.stringify(sourcing));}catch(e){}
  sbUpsert("settings","sourcing",{key:"sourcing",value:sourcing});
}
async function syncSourcingFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="sourcing";});
      if(row&&Array.isArray(row.value)){
        sourcing.length=0; row.value.forEach(function(v){sourcing.push(v);});
        try{localStorage.setItem(SOURCING_STORE,JSON.stringify(sourcing));}catch(e){}
        if(document.getElementById("sourcingView")&&document.getElementById("sourcingView").style.display==="block")renderSourcingView();
      }
    }
  }catch(e){ console.warn("sourcing cloud sync failed", e); }
}
syncSourcingFromCloud();
var clients,reps,samples,birthdays,complaints;
var activeFilter="All",activeId=null,editId=null,showLF=false,pendingDel=null;
var detLogTab="Interactions";
var currentSalesYear=new Date().getFullYear();
var currentSalesMonth=new Date().getMonth();

function loadClients(){
  try{
    var raw=localStorage.getItem(STORE);
    if(raw){
      var stored=JSON.parse(raw);
      if(stored&&stored.length>0) return stored;
    }
  }catch(e){}
  return [];
}
function copyC(d){return{id:d.id,binder:d.binder,name:d.name,contact:d.contact||"",manager:d.manager||"Sinbad",mobile:d.mobile||"",contact2:d.contact2||"",mobile2:d.mobile2||"",address:d.address||"",product:d.product||"",spend:d.spend||"",priority:d.priority||"",status:d.status||"Prospect",interactionType:d.interactionType||"",lastContact:d.lastContact||"",followup:d.followup||"",notes:d.notes||"",competitorNotes:d.competitorNotes||"",wontBuy:d.wontBuy||"",keyDates:d.keyDates||"",log:[]}}
function loadReps(){
  try{var r=localStorage.getItem(RSTORE);if(r){var s=JSON.parse(r);if(s&&s.length>0)return s;}}catch(e){}
  var d=JSON.parse(JSON.stringify(DEFAULT_REPS));try{localStorage.setItem(RSTORE,JSON.stringify(d));}catch(e){}return d;
}
function loadSamples(){try{var r=localStorage.getItem(SSTORE);if(r)return JSON.parse(r);}catch(e){}return[];}
function loadBirthdays(){try{var r=localStorage.getItem(BSTORE);if(r)return JSON.parse(r);}catch(e){}return[];}
function loadComplaints(){try{var r=localStorage.getItem(CSTORE);if(r)return JSON.parse(r);}catch(e){}return[];}

// ── UTILS ─────────────────────────────────────────────────────────
function ini(n){return(n||"").trim().split(/\s+/).slice(0,2).map(function(w){return w.charAt(0)||"";}). join("").toUpperCase();}
function scls(s){return{Active:"pa",Prospect:"pp","On Hold":"ph",Lost:"pl2",Closed:"pc"}[s]||"pp";}
function du(d){
  if(!d||d==="")return 999;
  var s=d;if(s.indexOf("/")>-1){var p=s.split("/");s=p[2]+"-"+p[1]+"-"+p[0];}
  var dt=new Date(s);if(isNaN(dt.getTime()))return 999;
  return Math.ceil((dt.getTime()-new Date().getTime())/86400000);
}
function fd(d){
  if(!d)return"";if(d.indexOf("/")>-1)return d;
  var p=d.split("-");return p.length===3?p[2]+"/"+p[1]+"/"+p[0]:d;
}
function ti(d){
  if(!d||d==="")return"";if(d.indexOf("/")>-1){var p=d.split("/");return p[2]+"-"+p[1]+"-"+p[0];}return d;
}
function toast(msg,isWarn){var t=document.getElementById("notify");t.textContent=msg;t.classList.add("show");if(isWarn){t.classList.add("warn");}else{t.classList.remove("warn");}clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(function(){t.classList.remove("show");t.classList.remove("warn");},isWarn?6000:2200);}
function nextId(){return"SFTC-"+Date.now()+"-"+Math.floor(Math.random()*1000);}
function money(v){var n=parseFloat(String(v||"0").replace(/[^0-9.]/g,""))||0;return"\u00a3"+n.toLocaleString("en-GB");}

// ── STATS ─────────────────────────────────────────────────────────
function updateStats(){
  document.getElementById("sTot").textContent=clients.length;
  document.getElementById("sAct").textContent=clients.filter(function(c){return c.status==="Active";}).length;
  var due=clients.filter(function(c){var d=du(c.followup);return d>=-2&&d<=2;}).length;
  document.getElementById("sDue").textContent=due;
  document.getElementById("sDueWrap").className="hs"+(due>0?" alert":"");
  var qt=0;clients.forEach(function(c){(c.log||[]).forEach(function(l){if(l.quote&&(l.quote.status==="Quote"||l.quote.status==="Confirmed"))qt+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);});});
  document.getElementById("sQ").textContent="\u00a3"+qt.toLocaleString("en-GB");
}

// ── VIEW MANAGER ──────────────────────────────────────────────────
function showView(v){
  ["dashView","detView","clientsView","formView","repsView","salesView","samplesView","birthdaysView","complaintsView","diaryView","quotesView","websitesView","docsView","notesSearchView","enquiriesView","sourcingView","tasksView","toolsView","footfallView"].forEach(function(id){
    var el=document.getElementById(id);
    el.style.display=(id===v+"View"||(v==="det"&&id==="detView")||(v==="form"&&id==="formView"))?"block":"none";
  });
  var ma=document.getElementById("mainArea");
  if(ma){
    ma.scrollTop=0;
    try{ma.focus({preventScroll:true});}catch(e){ma.focus();}
  }
}
function showDash(){activeId=null;renderList();showView("dash");renderDash();}
function showReps(){activeId=null;renderList();showView("reps");renderRepsView();}
function showSales(){activeId=null;renderList();showView("sales");renderSalesView();}
function showSamples(){activeId=null;renderList();showView("samples");renderSamplesView();}
function showBirthdays(){activeId=null;renderList();showView("birthdays");renderBirthdaysView();}
function showComplaints(){activeId=null;renderList();showView("complaints");renderComplaintsView();}
function showTools(){activeId=null;renderList();showView("tools");renderToolsView();}

// ── SIDEBAR ───────────────────────────────────────────────────────

// ── CLIENTS FULL PAGE ────────────────────────────────────────────


// ── ON THIS DAY (world history, via Wikipedia's public feed API) ────
var OTD_CACHE_STORE = "spcrm_otd_cache_v1";
function otdRenderInto(el, text, year) {
  el.innerHTML = "";
  var txt = document.createElement("div");
  txt.style.cssText = "font-size:12px;color:var(--text);line-height:1.5";
  txt.textContent = year + " \u2014 " + text;
  var src = document.createElement("div");
  src.style.cssText = "font-size:9px;color:var(--muted);margin-top:6px";
  src.textContent = "Source: Wikipedia";
  el.appendChild(txt);
  el.appendChild(src);
}
function loadOnThisDay(containerId) {
  var el = document.getElementById(containerId);
  if (!el) return;
  var today = new Date();
  var mm = String(today.getMonth() + 1).padStart(2, "0");
  var dd = String(today.getDate()).padStart(2, "0");
  var cacheKey = today.getFullYear() + "-" + mm + "-" + dd;
  try {
    var cached = JSON.parse(localStorage.getItem(OTD_CACHE_STORE) || "null");
    if (cached && cached.key === cacheKey && cached.text) {
      otdRenderInto(el, cached.text, cached.year);
      return;
    }
  } catch (e) {}
  fetch("https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/" + mm + "/" + dd)
    .then(function (r) { if (!r.ok) throw new Error("bad response"); return r.json(); })
    .then(function (data) {
      var events = (data && data.events) ? data.events.filter(function (e) { return e.text && e.year; }) : [];
      if (!events.length) throw new Error("no events");
      // Seeded on today's date so it stays the same across re-renders/tabs today, but changes daily.
      var seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
      var ev = events[seed % events.length];
      try { localStorage.setItem(OTD_CACHE_STORE, JSON.stringify({ key: cacheKey, text: ev.text, year: ev.year })); } catch (e) {}
      otdRenderInto(el, ev.text, ev.year);
    })
    .catch(function () {
      el.innerHTML = "";
      var fail = document.createElement("div");
      fail.style.cssText = "font-size:11px;color:var(--muted)";
      fail.textContent = "Couldn't load today's history (check your connection).";
      el.appendChild(fail);
    });
}

// ── FLOORING FACT OF THE DAY (hand-curated & fact-checked, not AI filler) ─
var FLOORING_FACTS = [
  "Linoleum was invented by Englishman Frederick Walton, who patented it in 1863 after finding a use for the skin that forms on oxidised linseed oil.",
  "The herringbone pattern gets its name from its resemblance to a herring fish's skeleton, and the Romans used it to pave roads because the interlocking bricks resisted shifting.",
  "Herringbone parquet became fashionable after it was laid at the Palace of Versailles in the late 1600s, replacing heavy marble floors.",
  "Laminate flooring wasn't originally designed as a floor at all \u2014 it came out of a 1977 brainstorming session at Swedish company Perstorp, who were looking for new uses for their laminate worktop material.",
  "\"Parquet\" comes from the French for \"small compartment\", describing how individual wood pieces are cut and fitted together.",
  "Bamboo flooring isn't technically wood \u2014 bamboo is a grass, which is part of why it grows and regenerates far faster than hardwood trees.",
  "Cork flooring is harvested from the bark of the cork oak without felling the tree, and the bark regrows, making it one of the more renewable flooring materials.",
  "Terrazzo flooring originated with Venetian construction workers, who mixed leftover marble chips with cement to make a hard-wearing, low-cost floor.",
  "Underfloor heating isn't a modern invention \u2014 the Romans used a hypocaust system, circulating hot air beneath raised floors to heat villas and bathhouses.",
  "Engineered wood flooring is built from cross-layered wood veneers, which makes it more dimensionally stable than solid wood \u2014 particularly useful over underfloor heating.",
  "Herringbone-style patterns show up in Ancient Egyptian jewellery, long before the design was ever used for flooring.",
  "\"Opus spicatum\", Latin for \"spiked work\", is the technical name for the herringbone brick paving used across the Roman Empire.",
  "Vinyl flooring is typically built in layers \u2014 a backing layer, a printed design layer, and a clear wear layer on top that determines how long it holds up.",
  "The click-lock joint that makes modern laminate and LVT quick to fit was developed independently in the 1990s by Sweden's V\u00e4linge and Belgium's Unilin (Quick-Step).",
  "Hardwood floor hardness is measured on the Janka scale, which rates how much force it takes to embed a steel ball halfway into the wood.",
  "The Mohs hardness scale, originally created for minerals, is often used to compare how scratch-resistant different tile and stone finishes are.",
  "Solid wood flooring naturally expands and contracts with humidity, which is why fitters leave an expansion gap around the edge of every room.",
  "The UK's Building Regulations Part E sets minimum sound insulation standards between separate dwellings, which is why acoustic underlay matters in flats and conversions.",
  "Chevron flooring looks similar to herringbone, but the plank ends are cut at an angle so the pattern forms a continuous \"V\" rather than a staggered zig-zag.",
  "Grout comes in sanded and unsanded types \u2014 sanded is generally used for wider joints for extra strength, while unsanded suits narrower joints and won't scratch delicate tile surfaces."
];
function loadFlooringFact(containerId) {
  var el = document.getElementById(containerId);
  if (!el) return;
  var today = new Date();
  var start = new Date(today.getFullYear(), 0, 0);
  var doy = Math.floor((today - start) / 86400000);
  el.textContent = FLOORING_FACTS[doy % FLOORING_FACTS.length];
}

function renderDash(){
  var overdue=clients.filter(function(c){return du(c.followup)<0;});
  var today2=clients.filter(function(c){var d=du(c.followup);return d>=0&&d<=1;});
  var fuList=overdue.concat(today2).slice(0,8);
  var cold=clients.filter(function(c){
    if(!c.lastContact||c.lastContact==="")return false;
    var s=c.lastContact;if(s.indexOf("/")>-1){var p=s.split("/");s=p[2]+"-"+p[1]+"-"+p[0];}
    var dt=new Date(s);if(isNaN(dt.getTime()))return false;
    var daysSince=(new Date().getTime()-dt.getTime())/86400000;
    // Flag based on priority - higher priority clients should be contacted more often
    var threshold=c.priority==="\u2605\u2605\u2605\u2605\u2605"?7:c.priority==="\u2605\u2605\u2605\u2605"?10:c.priority==="\u2605\u2605\u2605"?14:c.priority==="\u2605\u2605"?21:c.priority==="\u2605"?30:14;
    return daysSince>threshold&&c.status==="Active";
  });
  var top=clients.filter(function(c){return c.priority&&c.priority!==""}).sort(function(a,b){return(b.priority||"").length-(a.priority||"").length;}).slice(0,5);
  var openQ=[],qTotal=0,allQuotes=[];
  clients.forEach(function(c){(c.log||[]).forEach(function(l){
    if(l.quote){
      var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
      allQuotes.push({client:c,log:l,val:v});
      if(l.quote.status==="Quote"||l.quote.status==="Confirmed"){qTotal+=v;openQ.push({client:c,log:l,val:v});}
    }
  });});
  openQ.sort(function(a,b){return b.val-a.val;});
  var dv=document.getElementById("dashView");dv.innerHTML="";
  var t=document.createElement("div");t.style.cssText="font-size:16px;font-weight:700;margin-bottom:16px";
  t.textContent="Here\u2019s your daily briefing";dv.appendChild(t);
  var kg=document.createElement("div");kg.className="kpi-grid";
  var selfGen=clients.filter(function(c){return c.source==="New - Sinbad's Old Customer"||c.source==="New - Walk In"||c.source==="New - Referral"||c.source==="Existing Customer (Dormant 12m+)";}).length;
  [{l:"Total clients",v:clients.length,c:"kv-blue",s:"in your black book"},{l:"Active",v:clients.filter(function(c){return c.status==="Active";}).length,c:"kv-green",s:"clients"},{l:"Overdue follow-ups",v:overdue.length,c:overdue.length>0?"kv-red":"kv-green",s:"need chasing"},{l:"Open quote value",v:"\u00a3"+qTotal.toLocaleString("en-GB"),c:"kv-amber",s:"quote + confirmed"}].forEach(function(k){
    var card=document.createElement("div");card.className="kpi";
    var lbl=document.createElement("div");lbl.className="kpi-lbl";lbl.textContent=k.l;
    var val=document.createElement("div");val.className="kpi-val "+k.c;val.textContent=k.v;
    var sub=document.createElement("div");sub.className="kpi-sub";sub.textContent=k.s;
    card.appendChild(lbl);card.appendChild(val);card.appendChild(sub);kg.appendChild(card);
  });dv.appendChild(kg);
  var dg=document.createElement("div");dg.className="dash-grid";
  function mkCard(title2,items2,empty2,renderFn){
    var card=document.createElement("div");card.className="dash-card";
    var ct=document.createElement("div");ct.className="dash-card-title";ct.textContent=title2+(items2.length?" ("+items2.length+")":"");card.appendChild(ct);
    if(!items2.length){var em=document.createElement("div");em.className="empty-dash";em.textContent=empty2;card.appendChild(em);}
    else items2.forEach(function(item){card.appendChild(renderFn(item));});
    return card;
  }
  function clickEl(cls,cid,avT,nmT,subT,badgeT,badgeC){
    var el=document.createElement("div");el.className=cls;
    var av=document.createElement("div");av.className="fu-av";av.textContent=avT;
    var info=document.createElement("div");info.style.flex="1";
    var nm=document.createElement("div");nm.className="fu-name";nm.textContent=nmT;
    var st=document.createElement("div");st.className="fu-date";st.textContent=subT;
    info.appendChild(nm);info.appendChild(st);
    var badge=document.createElement("span");badge.className="fu-badge ftag "+badgeC;badge.textContent=badgeT;
    el.appendChild(av);el.appendChild(info);el.appendChild(badge);
    el.addEventListener("click",(function(id){return function(){openC(id);};})(cid));
    return el;
  }
  dg.appendChild(mkCard("Follow-ups due",fuList,"All clear \u2713",function(c){
    var d=du(c.followup);var lbl=d<0?Math.abs(d)+"d overdue":"Today";
    var el=clickEl("fu-item",c.id,ini(c.name),c.name,c.contact||"",lbl,d<0?"fdue":"famb");
    var clearBtn=document.createElement("button");
    clearBtn.textContent="\u2713 Clear";
    clearBtn.style.cssText="margin-left:8px;padding:3px 9px;background:#d0f0d0;border:2px solid #1a5c1a;border-radius:20px;color:#1a5c1a;font-size:10px;font-weight:700;cursor:pointer;flex-shrink:0";
    clearBtn.addEventListener("click",(function(cid){return function(ev){
      ev.stopPropagation();
      var cl=clients.find(function(x){return x.id===cid;});
      if(cl){ cl.followup=""; saveC(); renderDash(); toast("Follow-up cleared \u2713"); }
    };})(c.id));
    el.appendChild(clearBtn);
    return el;
  }));
  var oqCard = mkCard("Open quotes",openQ.slice(0,4),"No open quotes yet",function(q){
    var el=clickEl("fu-item",q.client.id,ini(q.client.name),q.client.name,(q.log.quote.products||""),money(q.val),"q-"+(q.log.quote.status||"quote").toLowerCase().replace(" ","-"));
    el.style.cursor="pointer";
    return el;
  });
  if(openQ.length>0){
    var oqLnk=document.createElement("div");oqLnk.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;margin-top:8px;text-align:right;padding-top:7px;border-top:1px solid var(--border)";
    oqLnk.textContent="View all quotes ("+openQ.length+") →";
    oqLnk.addEventListener("click",showQuotes);oqCard.appendChild(oqLnk);
  }
  dg.appendChild(oqCard);

  var activeTasks = tasks.filter(function(t){ return !t.done; }).sort(function(a,b){ return (b.created||0)-(a.created||0); });
  var todoCard = mkCard("To-Do",activeTasks.slice(0,4),"All clear \u2713",function(t){
    var el=document.createElement("div");el.className="fu-item";el.style.cursor="pointer";
    var av=document.createElement("div");av.className="fu-av";
    av.style.background=t.clientId?"var(--navy)":(t.repId?"#9b59b6":"#3498db");
    av.textContent=t.clientId?ini(t.clientName):(t.repId?"\uD83E\uDD1D":"\uD83C\uDFEA");
    var info=document.createElement("div");info.style.flex="1";
    var nm=document.createElement("div");nm.className="fu-name";nm.textContent=t.text;
    var sub=document.createElement("div");sub.className="fu-date";sub.textContent=t.clientId?t.clientName:(t.repId?t.repName:"Shop task");
    info.appendChild(nm);info.appendChild(sub);
    var doneBtn2=document.createElement("button");doneBtn2.textContent="\u2713";doneBtn2.style.cssText="margin-left:8px;width:24px;height:24px;border-radius:50%;background:#fff;border:2px solid #3498db;color:#3498db;font-size:12px;cursor:pointer;flex-shrink:0";
    doneBtn2.addEventListener("click",function(ev){
      ev.stopPropagation();
      t.done=true; t.completedDate=fd2date();
      saveTasks(); renderDash();
      toast("Marked done \u2713");
    });
    el.appendChild(av);el.appendChild(info);el.appendChild(doneBtn2);
    el.addEventListener("click",function(){ showTasks(); });
    return el;
  });
  if (tasks.length>0) {
    var tdLnk=document.createElement("div");tdLnk.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;margin-top:8px;text-align:right;padding-top:7px;border-top:1px solid var(--border)";
    tdLnk.textContent="View all tasks ("+activeTasks.length+") \u2192";
    tdLnk.addEventListener("click",showTasks);todoCard.appendChild(tdLnk);
  }
  dg.appendChild(todoCard);
  dg.appendChild(mkCard("Top priority clients",top,"Set priority ratings to see them here",function(c){
    var el=document.createElement("div");el.className="top-item";
    var rk=document.createElement("div");rk.className="top-rank";rk.textContent=top.indexOf(c)+1;
    var av=document.createElement("div");av.className="fu-av";av.textContent=ini(c.name);
    var info=document.createElement("div");info.style.flex="1";
    var nm=document.createElement("div");nm.className="fu-name";nm.textContent=c.name;
    var sub=document.createElement("div");sub.className="fu-date";sub.textContent=(c.address||"").split(",")[0];
    info.appendChild(nm);info.appendChild(sub);
    var st=document.createElement("span");st.className="stars";st.textContent=c.priority||"";
    el.appendChild(rk);el.appendChild(av);el.appendChild(info);el.appendChild(st);
    el.addEventListener("click",(function(id){return function(){openC(id);};})(c.id));return el;
  }));
  var QUOTES=[
    {q:"The secret of getting ahead is getting started.",a:"Mark Twain"},
    {q:"It's not about ideas. It's about making ideas happen.",a:"Scott Belsky"},
    {q:"Take care of your customers and they will take care of your business.",a:"unknown"},
    {q:"Sales are contingent upon the attitude of the salesman, not the attitude of the prospect.",a:"W. Clement Stone"},
    {q:"The way to get started is to quit talking and begin doing.",a:"Walt Disney"},
    {q:"Quality is remembered long after the price is forgotten.",a:"Gucci family slogan"},
    {q:"Don't watch the clock; do what it does. Keep going.",a:"Sam Levenson"},
    {q:"People don't buy what you do; they buy why you do it.",a:"Simon Sinek"},
    {q:"Success is the sum of small efforts, repeated day in and day out.",a:"Robert Collier"},
    {q:"A satisfied customer is the best business strategy of all.",a:"Michael LeBoeuf"},
    {q:"The best way to predict the future is to create it.",a:"Peter Drucker"},
    {q:"You don't close a sale, you open a relationship.",a:"Patricia Fripp"},
    {q:"Measure twice, cut once.",a:"Trade proverb"},
    {q:"Well done is better than well said.",a:"Benjamin Franklin"},
    {q:"The customer's perception is your reality.",a:"Kate Zabriskie"},
    {q:"Good things come to those who hustle.",a:"unknown"},
    {q:"Either you run the day, or the day runs you.",a:"Jim Rohn"},
    {q:"Excellence is not a skill, it's an attitude.",a:"Ralph Marston"},
    {q:"Opportunities don't happen, you create them.",a:"Chris Grosser"},
    {q:"Make it simple, but significant.",a:"Don Draper"},
    {q:"Quality means doing it right when no one is looking.",a:"Henry Ford"},
    {q:"Whether you think you can or you think you can't, you're right.",a:"Henry Ford"},
    {q:"The harder I work, the luckier I get.",a:"Samuel Goldwyn"},
    {q:"Customers don't expect you to be perfect. They expect you to fix things when they go wrong.",a:"Donald Porter"},
    {q:"Build it well, and they will tell their friends.",a:"Trade proverb"},
    {q:"There is no traffic jam on the extra mile.",a:"unknown"},
    {q:"Do what you do so well that they will want to see it again and bring their friends.",a:"Walt Disney"},
    {q:"The job is never finished until the paperwork is done.",a:"unknown"},
    {q:"A craftsman is recognised by his chips.",a:"German proverb"},
    {q:"Strive not to be a success, but rather to be of value.",a:"Albert Einstein"},
    {q:"Good enough never is.",a:"Debbi Fields"},
    {q:"A goal without a plan is just a wish.",a:"Antoine de Saint-Exupery"},
    {q:"Small daily improvements are the key to staggering long-term results.",a:"unknown"},
    {q:"What's measured improves.",a:"Peter Drucker"},
    {q:"Don't find customers for your products, find products for your customers.",a:"Seth Godin"},
    {q:"It is not the employer who pays wages, he only handles the money. It is the customer who pays the wages.",a:"Henry Ford"},
    {q:"Your most unhappy customers are your greatest source of learning.",a:"Bill Gates"},
    {q:"The aim of marketing is to know the customer so well the product sells itself.",a:"Peter Drucker"},
    {q:"Punctuality is the soul of business.",a:"Thomas Chandler Haliburton"},
    {q:"Honesty is the best policy.",a:"Benjamin Franklin"},
    {q:"Pleasure in the job puts perfection in the work.",a:"Aristotle"},
    {q:"Never stop learning, because life never stops teaching.",a:"unknown"},
    {q:"The expert in anything was once a beginner.",a:"Helen Hayes"},
    {q:"A smooth floor doesn't come from a smooth sea.",a:"unknown"},
    {q:"Plans are nothing; planning is everything.",a:"Dwight D. Eisenhower"},
    {q:"Patience and persistence are worth more than fast feet and a strong arm.",a:"unknown"},
    {q:"You miss 100% of the calls you don't make.",a:"adapted from Wayne Gretzky"},
    {q:"Treat every customer like they're your only customer.",a:"unknown"},
    {q:"It always seems impossible until it's done.",a:"Nelson Mandela"},
    {q:"Trust takes years to build, seconds to break, and forever to repair.",a:"unknown"},
    {q:"Hard work beats talent when talent doesn't work hard.",a:"Tim Notke"},
    {q:"The man who moves a mountain begins by carrying away small stones.",a:"Confucius"},
    {q:"You can't build a reputation on what you're going to do.",a:"Henry Ford"},
    {q:"A craftsman knows he has achieved perfection not when there is nothing left to add, but when there is nothing left to take away.",a:"adapted from Antoine de Saint-Exupery"},
    {q:"There are no shortcuts to any place worth going.",a:"Beverly Sills"},
    {q:"Diligence is the mother of good fortune.",a:"Miguel de Cervantes"},
    {q:"To handle yourself, use your head; to handle others, use your heart.",a:"Eleanor Roosevelt"},
    {q:"If you fail to plan, you are planning to fail.",a:"Benjamin Franklin"},
    {q:"Every job is a self-portrait of the person who did it.",a:"unknown"},
    {q:"A good plan violently executed now is better than a perfect plan next week.",a:"George S. Patton"},
    {q:"The bitterness of poor quality remains long after the sweetness of low price is forgotten.",a:"Benjamin Franklin"},
    {q:"What you do today can improve all your tomorrows.",a:"Ralph Marston"},
    {q:"Energy and persistence conquer all things.",a:"Benjamin Franklin"},
    {q:"Be so good they can't ignore you.",a:"Steve Martin"},
    {q:"Reputation is what people say about you when you're not in the room.",a:"unknown"},
    {q:"Service to others is the rent you pay for your room here on earth.",a:"Muhammad Ali"},
    {q:"The way to gain a good reputation is to endeavor to be what you desire to appear.",a:"Socrates"},
    {q:"It's not what you sell that matters as much as how you sell it.",a:"Brian Halligan"},
    {q:"Make a customer, not a sale.",a:"Katherine Barchetti"},
    {q:"Slow is smooth, smooth is fast.",a:"Trade proverb"},
    {q:"A house is made of walls and beams; a home is built with love and dreams.",a:"unknown"},
    {q:"What gets measured gets managed.",a:"Peter Drucker"},
    {q:"Don't wait for opportunity. Create it.",a:"unknown"},
    {q:"Quality is never an accident; it is always the result of intelligent effort.",a:"John Ruskin"},
    {q:"Coming together is a beginning, staying together is progress, working together is success.",a:"Henry Ford"},
    {q:"If you can't explain it simply, you don't understand it well enough.",a:"adapted from Albert Einstein"},
    {q:"There is no substitute for hard work.",a:"Thomas Edison"},
    {q:"A man who works with his hands is a labourer. A man who works with his hands and his brain is a craftsman.",a:"Louis Nizer"},
    {q:"Do the best you can until you know better. Then when you know better, do better.",a:"Maya Angelou"},
    {q:"In business, the competition will bite you if you keep running; if you stand still, they will swallow you.",a:"William S. Knudsen"},
    {q:"The way to develop self-confidence is to do the thing you fear.",a:"William Jennings Bryan"},
    {q:"Choose a job you love, and you will never have to work a day in your life.",a:"adapted, attributed to Confucius"},
    {q:"Don't be afraid to give up the good to go for the great.",a:"John D. Rockefeller"},
    {q:"It's not the customer's job to know what they want.",a:"Steve Jobs"},
    {q:"Always deliver more than expected.",a:"Larry Page"},
    {q:"Genius is one percent inspiration and ninety-nine percent perspiration.",a:"Thomas Edison"},
    {q:"To improve is to change; to be perfect is to change often.",a:"Winston Churchill"},
    {q:"A real decision is measured by the fact that you've taken a new action.",a:"Tony Robbins"},
    {q:"The only place success comes before work is in the dictionary.",a:"Vidal Sassoon"},
    {q:"Today's accomplishments were yesterday's impossibilities.",a:"unknown"},
    {q:"Persistence guarantees that results are inevitable.",a:"Paramahansa Yogananda"},
    {q:"Strive for progress, not perfection.",a:"unknown"},
    {q:"You can't pour from an empty cup. Take care of yourself too.",a:"unknown"},
    {q:"A goal properly set is halfway reached.",a:"Zig Ziglar"},
    {q:"Knowing is not enough; we must apply. Willing is not enough; we must do.",a:"Johann Wolfgang von Goethe"},
    {q:"Good craftsmanship lasts longer than the memory of its price.",a:"unknown"},
    {q:"What you lay down today, someone will walk on for twenty years.",a:"unknown"},
    {q:"Take pride in how far you've come; have faith in how far you can go.",a:"unknown"},
    {q:"It's not about having time, it's about making time.",a:"unknown"},
    {q:"Believe you can and you're halfway there.",a:"Theodore Roosevelt"},
    {q:"Done is better than perfect.",a:"Sheryl Sandberg"},
    {q:"Service is the rent we pay for being.",a:"Marian Wright Edelman"},
    {q:"You become what you give your attention to.",a:"Epictetus"},
    {q:"A foundation laid well never needs to be laid twice.",a:"unknown"},
    {q:"Customers remember the service long after they've forgotten the price.",a:"unknown"},
    {q:"Show up, do the work, repeat.",a:"unknown"},
    {q:"Discipline is choosing between what you want now and what you want most.",a:"Abraham Lincoln"},
    {q:"A river cuts through rock not because of its power, but its persistence.",a:"Jim Watkins"},
    {q:"You don't have to be great to start, but you have to start to be great.",a:"Zig Ziglar"},
    {q:"Action is the foundational key to all success.",a:"Pablo Picasso"},
    {q:"The man on top of the mountain didn't fall there.",a:"Vince Lombardi"},
    {q:"What seems impossible today will one day become your warm-up.",a:"unknown"},
    {q:"It does not matter how slowly you go as long as you do not stop.",a:"Confucius"},
    {q:"Great things are done by a series of small things brought together.",a:"Vincent Van Gogh"},
    {q:"Don't count the days, make the days count.",a:"Muhammad Ali"},
    {q:"Success belongs to those who prepare for it.",a:"adapted proverb"},
    {q:"Fall seven times, stand up eight.",a:"Japanese proverb"},
    {q:"The only way to do great work is to love what you do.",a:"Steve Jobs"},
    {q:"Quality is not an act, it is a habit.",a:"Aristotle"},
    {q:"Success usually comes to those who are too busy to be looking for it.",a:"Henry David Thoreau"},
    {q:"Your reputation is built one job at a time.",a:"unknown"},
    {q:"A craftsman who hurries is a craftsman who hasn't finished learning.",a:"unknown"},
    {q:"Customers will forget what you said but never how you made them feel.",a:"adapted from Maya Angelou"},
    {q:"Be where your feet are.",a:"unknown"},
    {q:"A job well done is its own reward.",a:"adapted proverb"},
    {q:"There's always a way if you're committed.",a:"Tony Robbins"},
    {q:"Don't judge each day by the harvest you reap but by the seeds you plant.",a:"Robert Louis Stevenson"},
    {q:"Strive for excellence, not perfection.",a:"H. Jackson Brown Jr."},
    {q:"A goal is a dream with a deadline.",a:"Napoleon Hill"},
    {q:"Stay hungry, stay foolish.",a:"Steve Jobs"},
    {q:"Adversity introduces a man to himself.",a:"Albert Einstein"},
    {q:"What lies behind us and what lies before us are tiny matters compared to what lies within us.",a:"Ralph Waldo Emerson"},
    {q:"Look after your tools and your tools will look after you.",a:"Trade proverb"},
    {q:"Sharp tools make light work.",a:"Old proverb"},
    {q:"You miss every shot you don't take.",a:"Wayne Gretzky"},
    {q:"Speak less, listen more, you'll close more.",a:"unknown"},
    {q:"Every expert was once a disaster.",a:"unknown"},
    {q:"The job's not finished until it's finished right.",a:"unknown"},
    {q:"Treat the small jobs like the big jobs and the big jobs will find you.",a:"unknown"},
    {q:"Don't lower your expectations to meet your performance; raise your performance to meet your expectations.",a:"Ralph Marston"},
    {q:"He who has a why to live can bear almost any how.",a:"Friedrich Nietzsche"},
    {q:"To know and not to do is not yet to know.",a:"Confucius"},
    {q:"Make the customer the hero of your story.",a:"unknown"},
    {q:"A little progress each day adds up to big results.",a:"unknown"},
    {q:"Anyone who has never made a mistake has never tried anything new.",a:"Albert Einstein"},
    {q:"The bricklayer's secret: one brick at a time.",a:"unknown"},
    {q:"Honest work always finds its reward.",a:"unknown"},
    {q:"There is no elevator to success. You have to take the stairs.",a:"unknown"},
    {q:"Begin with the end in mind.",a:"Stephen Covey"},
    {q:"What you allow is what will continue.",a:"unknown"},
    {q:"Service is what life is all about.",a:"Marian Wright Edelman"},
    {q:"Whatever you are, be a good one.",a:"Abraham Lincoln"},
    {q:"The biggest risk is not taking any risk.",a:"Mark Zuckerberg"},
    {q:"Today is the day to start the things you've been putting off.",a:"unknown"},
    {q:"Build your reputation like a wall, brick by brick.",a:"unknown"},
    {q:"The first step is you have to say that you can.",a:"Will Smith"},
    {q:"No one ever drowned in their own sweat.",a:"unknown"},
    {q:"Doubt kills more dreams than failure ever will.",a:"Suzy Kassem"},
    {q:"Skill is only developed by hours and hours and hours of beating on your craft.",a:"Will Smith"},
    {q:"Success is not final, failure is not fatal: it is the courage to continue that counts.",a:"Winston Churchill"},
    {q:"The way you do anything is the way you do everything.",a:"unknown"},
    {q:"A smooth sea never made a skilled sailor.",a:"Franklin D. Roosevelt"},
    {q:"You can't pour from an empty cup.",a:"unknown"},
    {q:"Trust is built in drops and lost in buckets.",a:"unknown"},
    {q:"Win the morning, win the day.",a:"unknown"},
    {q:"There's no traffic on the road less travelled.",a:"unknown"},
    {q:"Good things take time, great things take longer.",a:"unknown"},
    {q:"Be stubborn about your goals and flexible about your methods.",a:"unknown"},
    {q:"What you tolerate, you teach others to repeat.",a:"unknown"},
    {q:"A goal is not always meant to be reached, it serves to give us something to aim at.",a:"Bruce Lee"},
    {q:"Stay ready so you don't have to get ready.",a:"unknown"},
    {q:"It's the small repeated efforts that build a great business.",a:"unknown"},
    {q:"Energy flows where attention goes.",a:"unknown"},
    {q:"Discipline equals freedom.",a:"Jocko Willink"},
    {q:"You become what you repeatedly do.",a:"adapted from Aristotle"},
    {q:"Speak the truth, even if your voice shakes.",a:"unknown"},
    {q:"The man who removes a mountain begins by carrying away small stones.",a:"Chinese proverb"},
    {q:"Master the basics and the rest follows.",a:"unknown"},
    {q:"Comparison is the thief of joy.",a:"Theodore Roosevelt"},
    {q:"Be the reason someone believes in good people.",a:"unknown"},
    {q:"What you focus on expands.",a:"unknown"},
    {q:"Every accomplishment starts with the decision to try.",a:"John F. Kennedy"},
    {q:"Out of clutter, find simplicity.",a:"Albert Einstein"},
    {q:"Vision without execution is just hallucination.",a:"Thomas Edison"},
    {q:"Tough times never last, but tough people do.",a:"Robert H. Schuller"},
    {q:"Inch by inch, anything's a cinch.",a:"unknown"},
    {q:"A goal without a deadline is just a dream.",a:"unknown"},
    {q:"Half measures avail us nothing.",a:"unknown"},
    {q:"The cave you fear to enter holds the treasure you seek.",a:"Joseph Campbell"},
    {q:"Build something today your future self will thank you for.",a:"unknown"},
    {q:"Don't be busy, be productive.",a:"unknown"},
    {q:"Plans fail for lack of counsel, but with many advisers they succeed.",a:"Proverbs 15:22"},
    {q:"做 the work; the rest takes care of itself.",a:"unknown"},
    {q:"You can't build a great business on bad foundations.",a:"unknown"},
    {q:"Solid floors start with a solid plan.",a:"unknown"},
    {q:"Underneath every great finish is hours of unseen prep.",a:"unknown"},
    {q:"Detail is not a detail, it makes the design.",a:"Charles Eames"},
    {q:"Craft over haste, every time.",a:"unknown"},
    {q:"Good work speaks for itself, loudly.",a:"unknown"}
  ];
  var QUOTES2=[
    {q:"What you do speaks so loudly that I cannot hear what you say.",a:"Ralph Waldo Emerson"},
    {q:"Quality work creates its own demand.",a:"unknown"},
    {q:"A good name is better than riches.",a:"unknown"},
    {q:"You'll never plough a field by turning it over in your mind.",a:"unknown"},
    {q:"The man who does not read has no advantage over the man who cannot.",a:"Mark Twain"},
    {q:"Speak with confidence, deliver with care.",a:"unknown"},
    {q:"What's worth doing is worth doing well.",a:"unknown"},
    {q:"The best preparation for tomorrow is doing your best today.",a:"H. Jackson Brown Jr."},
    {q:"Strong walls don't make a home, the people inside do.",a:"unknown"},
    {q:"Skill comes from consistent reps, not luck.",a:"unknown"},
    {q:"A quiet conscience makes a sound sleep.",a:"unknown"},
    {q:"Do small things with great love.",a:"Mother Teresa"},
    {q:"Honour your word and your word will honour you.",a:"unknown"},
    {q:"The level never lies.",a:"Trade proverb"},
    {q:"Build trust before you build anything else.",a:"unknown"},
    {q:"A square corner starts every great job.",a:"Trade proverb"},
    {q:"There's no glory in cutting corners.",a:"unknown"},
    {q:"A well-laid floor outlasts a hasty promise.",a:"unknown"},
    {q:"The proof is always in the finish.",a:"unknown"},
    {q:"Plan your work, then work your plan.",a:"Napoleon Hill"},
    {q:"Patience is bitter, but its fruit is sweet.",a:"Aristotle"},
    {q:"Excellence is doing ordinary things extraordinarily well.",a:"John W. Gardner"},
    {q:"The man who can drive himself further once the effort gets painful is the man who will win.",a:"Roger Bannister"},
    {q:"Nail the basics, win the big jobs.",a:"unknown"},
    {q:"A craftsman's word is his bond.",a:"unknown"},
    {q:"Slow and steady wins more repeat customers.",a:"unknown"},
    {q:"Better a diamond with a flaw than a pebble without.",a:"Confucius"},
    {q:"There is no failure except in no longer trying.",a:"Elbert Hubbard"},
    {q:"Big doors swing on small hinges.",a:"unknown"},
    {q:"Trust your training and your tools.",a:"unknown"},
    {q:"You're only as good as your last job, so make it count.",a:"unknown"},
    {q:"It's not the load that breaks you down, it's the way you carry it.",a:"Lou Holtz"},
    {q:"Reliability is rarer than talent.",a:"unknown"},
    {q:"Good craftsmanship can't be rushed, only respected.",a:"unknown"},
    {q:"A satisfied customer tells one friend; an unhappy one tells everyone.",a:"unknown"},
    {q:"What you repeat, you become known for.",a:"unknown"},
    {q:"The smallest deed is better than the grandest intention.",a:"unknown"},
    {q:"Treat every quote like it's the only one that matters.",a:"unknown"},
    {q:"Confidence comes from preparation.",a:"unknown"},
    {q:"Every wall was once just a drawing.",a:"unknown"},
    {q:"The right tool, used right, saves the day.",a:"unknown"},
    {q:"Promises made should be promises kept.",a:"unknown"},
    {q:"A job well-measured is a job half-done.",a:"Trade proverb"},
    {q:"There's dignity in honest labour.",a:"unknown"},
    {q:"Build relationships, not just invoices.",a:"unknown"},
    {q:"The bigger the challenge, the bigger the opportunity to shine.",a:"unknown"},
    {q:"Listen twice, measure once, speak last.",a:"unknown"},
    {q:"You earn loyalty one good experience at a time.",a:"unknown"},
    {q:"A steady hand builds a steady business.",a:"unknown"},
    {q:"Less talk, more graft — get the real work done.",a:"unknown"},
    {q:"Don't chase perfection, chase consistency.",a:"unknown"},
    {q:"The work you're proud of is the work that lasts.",a:"unknown"},
    {q:"A fair price and an honest job never go out of fashion.",a:"unknown"},
    {q:"Small wins, repeated, become a career.",a:"unknown"},
    {q:"The customer remembers who showed up on time.",a:"unknown"},
    {q:"Effort compounds, just like interest.",a:"unknown"},
    {q:"A tidy van reflects a tidy mind.",a:"unknown"},
    {q:"You are the standard you walk past.",a:"unknown"},
    {q:"Make today's work yesterday's best.",a:"unknown"},
    {q:"Every great business started with someone answering the phone.",a:"unknown"},
    {q:"Care shows in the corners no one checks.",a:"unknown"},
    {q:"Earn the next job while finishing this one.",a:"unknown"},
    {q:"A good plan today beats a perfect plan next week.",a:"unknown"},
    {q:"Reputation travels faster than any advert.",a:"unknown"},
    {q:"The harder the job, the sweeter the finish.",a:"unknown"},
    {q:"Honesty saves more relationships than charm ever will.",a:"unknown"},
    {q:"You can't pour quality from an empty effort.",a:"unknown"},
    {q:"A steady pace beats a frantic sprint.",a:"unknown"},
    {q:"Skilled hands and a clear head finish the job right.",a:"unknown"},
    {q:"The smallest follow-up call can save the biggest account.",a:"unknown"},
    {q:"Don't just sell the product, solve the problem.",a:"unknown"},
    {q:"A well-kept workshop builds well-kept work.",a:"unknown"},
    {q:"Good habits are the quiet architects of success.",a:"unknown"},
    {q:"Care about the work and the profit follows.",a:"unknown"},
    {q:"The strongest pitch is a finished job that speaks for itself.",a:"unknown"},
    {q:"Every customer is a future referral, treat them like one.",a:"unknown"},
    {q:"Do it properly or do it twice.",a:"unknown"},
    {q:"A clear quote builds a clear relationship.",a:"unknown"},
    {q:"The job isn't done until the client is happy, not just the floor.",a:"unknown"},
    {q:"Take the extra five minutes; it's never wasted.",a:"unknown"},
    {q:"Consistency is the quiet engine behind every good reputation.",a:"unknown"},
    {q:"The work remembers the hands that rushed it.",a:"unknown"},
    {q:"Stand behind your work and it will stand for you.",a:"unknown"},
    {q:"A good morning starts with a clear plan for the day.",a:"unknown"},
    {q:"Small courtesies build big loyalty.",a:"unknown"},
    {q:"There's no substitute for showing up prepared.",a:"unknown"},
    {q:"The best advert is a job done right.",a:"unknown"},
    {q:"Take pride in the parts no one will ever see.",a:"unknown"},
    {q:"A calm head fits better than a fast hand.",a:"unknown"},
    {q:"What you finish today builds what you're offered tomorrow.",a:"unknown"},
    {q:"Service with patience outlasts service with speed.",a:"unknown"},
    {q:"The right measurement now saves the wrong argument later.",a:"unknown"},
    {q:"Make every customer feel like your only customer, even on a busy day.",a:"unknown"},
    {q:"A clean job site is a quiet form of respect.",a:"unknown"},
    {q:"Today's effort is tomorrow's reputation.",a:"unknown"},
    {q:"The work doesn't lie, even when the day was rushed.",a:"unknown"},
    {q:"Small jobs done well lead to bigger jobs done well.",a:"unknown"},
    {q:"There's always time to do it right the second time \u2014 better to find it the first.",a:"unknown"},
    {q:"The trade rewards patience more than speed.",a:"unknown"}
  ];
  QUOTES = QUOTES.concat(QUOTES2);
  function mulberry32(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;var t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
  function seededShuffle(len,seed){var arr=[];for(var i=0;i<len;i++)arr.push(i);var rnd=mulberry32(seed);for(var j=arr.length-1;j>0;j--){var k=Math.floor(rnd()*(j+1));var tmp=arr[j];arr[j]=arr[k];arr[k]=tmp;}return arr;}
  function dayOfYear(d){var start=new Date(d.getFullYear(),0,0);return Math.floor((d-start)/86400000);}
  var todayIdx=dayOfYear(new Date());var yr=new Date().getFullYear();
  var qLap=Math.floor(todayIdx/QUOTES.length);var qPos=todayIdx%QUOTES.length;
  var qOrder=seededShuffle(QUOTES.length,yr*1000+qLap);
  var qod=QUOTES[qOrder[qPos]];
  var coldCard=mkCard("Going cold",cold.slice(0,6),"No active clients going cold \u2713",function(c){
    var s=c.lastContact||"";if(s.indexOf("/")>-1){var p=s.split("/");s=p[2]+"-"+p[1]+"-"+p[0];}
    var dt=new Date(s);var days=!isNaN(dt.getTime())?Math.round((new Date().getTime()-dt.getTime())/86400000):0;
    var el=document.createElement("div");el.className="cold-item";
    var av=document.createElement("div");av.className="fu-av";av.textContent=ini(c.name);
    var info=document.createElement("div");info.style.flex="1";
    var nm=document.createElement("div");nm.className="fu-name";nm.textContent=c.name;
    var sub=document.createElement("div");sub.className="fu-date";sub.textContent="Last: "+(c.lastContact||"never");
    info.appendChild(nm);info.appendChild(sub);
    var badge=document.createElement("span");badge.className="cold-days";badge.textContent=days+"d ago";
    el.appendChild(av);el.appendChild(info);el.appendChild(badge);
    el.addEventListener("click",(function(id){return function(){openC(id);};})(c.id));return el;
  });
  dg.appendChild(coldCard);
  var quoteCard=document.createElement("div");quoteCard.className="dash-card";
  var qTitle=document.createElement("div");qTitle.className="dash-card-title";qTitle.textContent="\uD83D\uDCAC Quote of the Day";quoteCard.appendChild(qTitle);
  var qBody=document.createElement("div");qBody.style.cssText="padding:6px 2px 2px";
  var qText=document.createElement("div");qText.style.cssText="font-size:13px;font-style:italic;color:var(--text);line-height:1.5";qText.textContent="\u201C"+qod.q+"\u201D";
  var qAuth=document.createElement("div");qAuth.style.cssText="font-size:11px;color:var(--muted);margin-top:8px;font-weight:700";qAuth.textContent="\u2014 "+qod.a;
  qBody.appendChild(qText);qBody.appendChild(qAuth);quoteCard.appendChild(qBody);
  var jDiv=document.createElement("div");jDiv.style.cssText="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)";
  var jTitle=document.createElement("div");jTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:6px";jTitle.textContent="\uD83C\uDF0D On This Day";
  var jBody=document.createElement("div");jBody.id="otdBox";jBody.style.cssText="font-size:12px;color:var(--muted);line-height:1.5";jBody.textContent="Loading\u2026";
  jDiv.appendChild(jTitle);jDiv.appendChild(jBody);quoteCard.appendChild(jDiv);
  var fDiv=document.createElement("div");fDiv.style.cssText="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)";
  var fTitle=document.createElement("div");fTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:6px";fTitle.textContent="\uD83E\uDEB5 Flooring Fact";
  var fBody=document.createElement("div");fBody.id="floorFactBox";fBody.style.cssText="font-size:12px;color:var(--text);line-height:1.5";
  fDiv.appendChild(fTitle);fDiv.appendChild(fBody);quoteCard.appendChild(fDiv);
  dg.appendChild(quoteCard);
  dv.appendChild(dg);
  loadOnThisDay("otdBox");
  loadFlooringFact("floorFactBox");

  // Diary events - within 5 working days + overdue on dashboard
  function workingDaysFromNow(e) {
    var evDate = new Date(e.year, e.month, e.day);
    var today3 = new Date(); today3.setHours(0,0,0,0);
    if (evDate < today3) return -1; // overdue - always show
    var count = 0; var d = new Date(today3);
    while (d < evDate) {
      d.setDate(d.getDate()+1);
      var day = d.getDay();
      if (day !== 0 && day !== 6) count++;
    }
    return count;
  }
  var allDiaryEvts = diaryEvents.filter(function(e){
    if (e.completed) return false;
    var wdays = workingDaysFromNow(e);
    return wdays <= 5; // overdue (=-1) or within 5 working days
  }).sort(function(a,b){
    var da = new Date(a.year,a.month,a.day)*1000 + (a.allDay?0:a.hour*60+a.minute);
    var db = new Date(b.year,b.month,b.day)*1000 + (b.allDay?0:b.hour*60+b.minute);
    return da-db;
  });
  if(allDiaryEvts.length) {
    var todayEvts = allDiaryEvts; var overdueEvts = [];
    var diaryPanel = document.createElement("div");
    diaryPanel.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:16px;margin-top:16px;border-left:4px solid #e8a020";
    var dpHdr = document.createElement("div"); dpHdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid var(--border)";
    var dpTitle = document.createElement("div"); dpTitle.style.cssText = "font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)"; dpTitle.textContent = "Diary — Today";
    var dpBadge = document.createElement("span"); dpBadge.style.cssText = "background:#e8a020;color:#fff;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px"; dpBadge.textContent = allDiaryEvts.length+" event"+(allDiaryEvts.length!==1?"s":"");
    dpHdr.appendChild(dpTitle); dpHdr.appendChild(dpBadge); diaryPanel.appendChild(dpHdr);
    var typeColors2 = {"Meeting":"#305CDE","Site Visit":"#2ecc71","Call":"#f39c12","Rep Visit":"#9b59b6","Delivery":"#e67e22","Family Event":"#e91e8c","Birthday":"#e8a020","Anniversary":"#c0392b","Holiday":"#16a085","Other":"#7f8c8d"};
    allDiaryEvts.forEach(function(e){
      var er = document.createElement("div"); er.style.cssText = "display:flex;align-items:center;gap:8px;padding:6px 8px;background:var(--alt);border-radius:var(--rs);margin-bottom:5px;cursor:pointer";
      er.addEventListener("click", function(){ showDiary(); });
      var dot3 = document.createElement("div"); dot3.style.cssText = "width:8px;height:8px;border-radius:50%;background:"+(e.category==="personal"?"#9333ea":(typeColors2[e.type]||"#305CDE"))+";flex-shrink:0";
      var info2 = document.createElement("div"); info2.style.flex="1";
      var et2 = document.createElement("div"); et2.style.cssText="font-size:12px;font-weight:700"; et2.textContent = (e.allDay?"All day":String(e.hour).padStart(2,"0")+":"+String(e.minute).padStart(2,"0"))+" "+e.title;
      var em2 = document.createElement("div"); em2.style.cssText="font-size:10px;color:var(--muted)"; em2.textContent = e.type+(e.withName?" with "+e.withName:"");
      info2.appendChild(et2); info2.appendChild(em2);
      var evtDate2 = new Date(e.year,e.month,e.day); var t2=new Date(); t2.setHours(0,0,0,0);
      var dayDiff = Math.ceil((evtDate2-t2)/86400000);
      var badgeText = dayDiff===0?"Today":dayDiff===1?"Tomorrow":dayDiff>0?"+"+dayDiff+"d":dayDiff+"d";
      var badgeCss = dayDiff<0?"background:var(--rbg);color:var(--rtxt)":dayDiff===0?"background:var(--abg);color:var(--atxt)":"background:var(--lbg);color:var(--ltxt)";
      var badge2 = document.createElement("span"); badge2.style.cssText="font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;"+badgeCss; badge2.textContent = badgeText;
      var doneB2 = document.createElement("button"); doneB2.style.cssText="padding:3px 8px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:20px;font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700;flex-shrink:0"; doneB2.textContent="✓";
      doneB2.addEventListener("click",(function(eid){return function(e3){e3.stopPropagation();markDiaryDone(eid);};})(e.id));
      var editB2=document.createElement("button");editB2.style.cssText="padding:3px 8px;background:none;border:2px solid var(--border);border-radius:20px;font-size:10px;color:var(--muted);cursor:pointer;flex-shrink:0";editB2.textContent="✎ Reschedule";
      editB2.addEventListener("click",(function(eid){return function(e3){e3.stopPropagation();editDiaryEvent(eid);};})(e.id));
      er.appendChild(dot3); er.appendChild(info2); er.appendChild(badge2); er.appendChild(editB2); er.appendChild(doneB2);
      diaryPanel.appendChild(er);
    });
    var dpLink = document.createElement("div"); dpLink.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;margin-top:6px;text-align:right"; dpLink.textContent="Open diary →"; dpLink.addEventListener("click",showDiary); diaryPanel.appendChild(dpLink);
    dv.appendChild(diaryPanel);
  }

  // Upcoming birthdays on dashboard
  var upcomingBdays = birthdays.filter(function(b){
    var d = daysUntilBday(b.date);
    return d >= 0 && d <= 5;
  }).sort(function(a,b){ return daysUntilBday(a.date)-daysUntilBday(b.date); });
  if (upcomingBdays.length) {
    var bdPanel = document.createElement("div");
    bdPanel.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px 16px;margin-top:16px;border-left:4px solid #e8a020";
    var bdHdr = document.createElement("div"); bdHdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid var(--border)";
    var bdTitle = document.createElement("div"); bdTitle.style.cssText = "font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)"; bdTitle.textContent = "\uD83C\uDF82 Birthdays coming up";
    var bdBadge = document.createElement("span"); bdBadge.style.cssText = "background:#e8a020;color:#fff;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px"; bdBadge.textContent = upcomingBdays.length;
    bdHdr.appendChild(bdTitle); bdHdr.appendChild(bdBadge); bdPanel.appendChild(bdHdr);
    upcomingBdays.forEach(function(b){
      var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:center;gap:10px;padding:5px 0;border-bottom:1px solid var(--border);cursor:pointer";
      row.addEventListener("click", function(){ showDiary(); });
      var av = document.createElement("div"); av.style.cssText = "width:28px;height:28px;border-radius:50%;background:#e8a020;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;flex-shrink:0"; av.textContent = ini(b.name);
      var info = document.createElement("div"); info.style.flex = "1";
      var nm = document.createElement("div"); nm.style.cssText = "font-weight:700;font-size:12px"; nm.textContent = b.name;
      var meta = document.createElement("div"); meta.style.cssText = "font-size:10px;color:var(--muted)"; meta.textContent = (b.company||b.type||"") + " \u00b7 " + fmtBday(b.date);
      info.appendChild(nm); info.appendChild(meta);
      var d = daysUntilBday(b.date);
      var badge = document.createElement("span"); badge.style.cssText = "font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;flex-shrink:0;" + (d===0?"background:var(--red);color:#fff":"background:#fff3e0;color:#854f0b"); badge.textContent = d===0?"TODAY! \uD83C\uDF82":d+"d";
      row.appendChild(av); row.appendChild(info); row.appendChild(badge);
      bdPanel.appendChild(row);
    });
    dv.appendChild(bdPanel);
  }

  // Rep visits overdue on dashboard
  function repEffectiveContactDate(r) {
    var d1 = null, d2 = null;
    if (r.lastInteractionDate) { // DD/MM/YYYY
      var p = r.lastInteractionDate.split("/");
      if (p.length === 3) { var dd = new Date(p[2]+"-"+p[1]+"-"+p[0]); if(!isNaN(dd.getTime())) d1 = dd; }
    }
    if (r.lastContact) { // YYYY-MM-DD
      var dd2 = new Date(r.lastContact); if(!isNaN(dd2.getTime())) d2 = dd2;
    }
    if (d1 && d2) return d1 > d2 ? d1 : d2;
    return d1 || d2 || null;
  }
  var repVisitsDue = reps.filter(function(r){
    if (r.excludeFromTracking) return false;
    var dt = repEffectiveContactDate(r);
    if (!dt) return false;
    return (new Date()-dt)/86400000>60;
  }).sort(function(a,b){
    return repEffectiveContactDate(a)-repEffectiveContactDate(b);
  }).slice(0,4);

  if(repVisitsDue.length){
    var rvPanel=document.createElement("div");
    rvPanel.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px 16px;margin-top:16px;border-left:4px solid #9b59b6";
    var rvHdr=document.createElement("div");rvHdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid var(--border)";
    var rvTitle=document.createElement("div");rvTitle.style.cssText="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)";rvTitle.textContent="\uD83E\uDD1D Rep visits overdue";
    var rvBadge=document.createElement("span");rvBadge.style.cssText="background:#9b59b6;color:#fff;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px";rvBadge.textContent=repVisitsDue.length+" reps";
    rvHdr.appendChild(rvTitle);rvHdr.appendChild(rvBadge);rvPanel.appendChild(rvHdr);
    repVisitsDue.forEach(function(r){
      var row=document.createElement("div");row.style.cssText="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border);cursor:pointer";
      row.addEventListener("click",function(){showReps();});
      var av=document.createElement("div");av.style.cssText="width:28px;height:28px;border-radius:50%;background:#9b59b6;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;flex-shrink:0";av.textContent=ini(r.name);
      var info=document.createElement("div");info.style.flex="1";
      var nm=document.createElement("div");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent=r.name;
      var effDate = repEffectiveContactDate(r);
      var lastLabel = r.lastInteractionDate || r.lastContact || "";
      var sub=document.createElement("div");sub.style.cssText="font-size:10px;color:var(--muted)";sub.textContent=(r.manufacturer||"")+(lastLabel?" \u00b7 Last: "+lastLabel:"");
      info.appendChild(nm);info.appendChild(sub);
      var days=Math.round((new Date()-effDate)/86400000);
      var badge=document.createElement("span");badge.style.cssText="font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;background:var(--rbg);color:var(--rtxt);flex-shrink:0";badge.textContent=days+"d ago";
      row.appendChild(av);row.appendChild(info);row.appendChild(badge);rvPanel.appendChild(row);
    });
    var rvLnk=document.createElement("div");rvLnk.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;margin-top:6px;text-align:right";rvLnk.textContent="View all reps \u2192";rvLnk.addEventListener("click",showReps);rvPanel.appendChild(rvLnk);
    dv.appendChild(rvPanel);
  }

  // Samples awaiting from reps panel
  var pendingSamples=samples.filter(function(s){return s.repId&&s.status==="Sent - Awaiting Return";});
  if(pendingSamples.length){
    var smpPanel=document.createElement("div");
    smpPanel.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:16px;margin-top:16px;border-left:4px solid #305CDE";
    var smpHdr=document.createElement("div");smpHdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border)";
    var smpTitle=document.createElement("div");smpTitle.style.cssText="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)";smpTitle.textContent="Samples awaiting from reps";
    var smpBadge=document.createElement("span");smpBadge.style.cssText="background:var(--navy);color:#fff;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px";smpBadge.textContent=pendingSamples.length+" pending";
    smpHdr.appendChild(smpTitle);smpHdr.appendChild(smpBadge);smpPanel.appendChild(smpHdr);
    var byRep={};
    pendingSamples.forEach(function(s){var k=s.repName||"Unknown";if(!byRep[k])byRep[k]=[];byRep[k].push(s);});
    Object.keys(byRep).sort().forEach(function(repName){
      var rg=document.createElement("div");rg.style.marginBottom="10px";
      var rh=document.createElement("div");rh.style.cssText="font-size:11px;font-weight:700;color:var(--navy);margin-bottom:5px";
      rh.textContent=repName+(byRep[repName][0].repMfr?" ("+byRep[repName][0].repMfr+")":"");rg.appendChild(rh);
      byRep[repName].forEach(function(s){
        var row=document.createElement("div");row.style.cssText="display:flex;align-items:center;gap:10px;padding:6px 9px;background:var(--alt);border-radius:var(--rs);margin-bottom:4px";
        var info=document.createElement("div");info.style.flex="1";
        var pnm=document.createElement("div");pnm.style.cssText="font-size:11px;font-weight:700";pnm.textContent=s.product+(s.detail?" — "+s.detail:"");
        var pfor=document.createElement("div");pfor.style.cssText="font-size:10px;color:var(--muted)";pfor.textContent="For: "+(s.clientName||"Unassigned")+" · "+s.dateSent;
        info.appendChild(pnm);info.appendChild(pfor);
        var rcvB=document.createElement("button");rcvB.style.cssText="padding:3px 9px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:20px;font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700;white-space:nowrap;flex-shrink:0";rcvB.textContent="✓ Received";
        var gIdx=samples.indexOf(s);
        rcvB.addEventListener("click",(function(gi){return function(e){e.stopPropagation();markSampleReceived(gi);renderDash();};})(gIdx));
        row.appendChild(info);row.appendChild(rcvB);rg.appendChild(row);
      });
      smpPanel.appendChild(rg);
    });
    var smpLnk=document.createElement("div");smpLnk.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;margin-top:6px;text-align:right";smpLnk.textContent="View all samples →";smpLnk.addEventListener("click",showSamples);smpPanel.appendChild(smpLnk);
    dv.appendChild(smpPanel);
  }
}

// ── DETAIL VIEW ───────────────────────────────────────────────────




// ── FORM ──────────────────────────────────────────────────────────






// ── DELETE ────────────────────────────────────────────────────────

// ── REPS ──────────────────────────────────────────────────────────
function renderRepsView(searchTerm){

  var rv=document.getElementById("repsView");rv.innerHTML="";
  var hdr=document.createElement("div");hdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title=document.createElement("div");title.className="page-title";title.textContent="Rep / ASM Directory";
  var addBtn=document.createElement("button");addBtn.style.cssText="padding:7px 16px;background:var(--red);border:none;border-radius:20px;color:#1a1a1a;font-size:12px;font-weight:700;cursor:pointer";addBtn.textContent="+ Add Rep / ASM";addBtn.addEventListener("click",function(){showRepForm(null);});
  hdr.appendChild(title);hdr.appendChild(addBtn);rv.appendChild(hdr);
  var q=(searchTerm||"").toLowerCase();
  var filteredReps=q?reps.filter(function(r){return[r.name,r.company,r.manufacturer,r.tel].some(function(v){return(v||"").toLowerCase().indexOf(q)>-1;});}):reps;
  var sw=document.createElement("div");sw.style.cssText="display:flex;align-items:center;gap:8px;background:var(--surface);border:2px solid var(--navy);border-radius:var(--rs);padding:7px 10px;margin-bottom:16px;max-width:360px;box-shadow:0 1px 4px rgba(0,0,0,.06)";
  var sIcon=document.createElement("span");sIcon.textContent="\uD83D\uDD0D";sIcon.style.cssText="font-size:12px;opacity:.6";
  var si=document.createElement("input");si.type="text";si.id="repSearch";si.placeholder="Search name, company or manufacturer...";si.value=searchTerm||"";
  si.style.cssText="background:none;border:none;outline:none;font-size:12px;color:var(--text);flex:1;min-width:0";
  si.addEventListener("input",function(){renderRepsView(this.value);});
  sw.appendChild(sIcon);sw.appendChild(si);rv.appendChild(sw);
  if(searchTerm){setTimeout(function(){var el=document.getElementById("repSearch");if(el)el.focus();},10);}
  var byMfr={};filteredReps.forEach(function(r){var m=r.manufacturer||"Other";if(!byMfr[m])byMfr[m]=[];byMfr[m].push(r);});
  if(!filteredReps.length){var em=document.createElement("div");em.className="empty-state";em.innerHTML="<div>&#128101;</div><div class='es-title'>"+(q?"No results found":"No reps added yet")+"</div><div class='es-sub'>Add your ASMs and manufacturer reps to keep track of contacts and visits</div>";rv.appendChild(em);}
  else{
    Object.keys(byMfr).sort().forEach(function(mfr){
      var section=document.createElement("div");section.style.marginBottom="20px";
      var mhdr=document.createElement("div");mhdr.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:10px;padding-bottom:5px;border-bottom:2px solid var(--red3);display:flex;align-items:center;gap:7px";
      var dot=document.createElement("span");dot.style.cssText="width:7px;height:7px;border-radius:50%;background:var(--red);display:inline-block";
      var mn=document.createElement("span");mn.textContent=mfr;
      var cnt=document.createElement("span");cnt.style.cssText="margin-left:auto;background:var(--alt);border:2px solid var(--border);border-radius:20px;padding:1px 7px;font-size:9px";cnt.textContent=byMfr[mfr].length+" rep"+(byMfr[mfr].length>1?"s":"");
      mhdr.appendChild(dot);mhdr.appendChild(mn);mhdr.appendChild(cnt);section.appendChild(mhdr);
      var grid=document.createElement("div");grid.style.cssText="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px";
      byMfr[mfr].forEach(function(r){
        var card=document.createElement("div");card.className="rep-card";
        var top=document.createElement("div");top.className="rep-card-top";
        var av=document.createElement("div");av.className="rep-av";av.textContent=ini(r.name);
        var info=document.createElement("div");
        var nm=document.createElement("div");nm.className="rep-name";nm.textContent=r.name;
        var co=document.createElement("div");co.className="rep-co";co.textContent=r.company||r.manufacturer||"";
        info.appendChild(nm);info.appendChild(co);top.appendChild(av);top.appendChild(info);card.appendChild(top);
        var body=document.createElement("div");body.className="rep-card-body";
        if(r.tel){var tr=document.createElement("div");tr.style.cssText="font-size:11px;margin-bottom:4px";tr.innerHTML='<span style="color:var(--muted);font-size:9px;font-weight:700;text-transform:uppercase;margin-right:5px">Tel</span>'+r.tel;body.appendChild(tr);}
        if(r.email){var er=document.createElement("div");er.style.cssText="font-size:11px;color:var(--ltxt);margin-bottom:4px";er.innerHTML='<span style="color:var(--muted);font-size:9px;font-weight:700;text-transform:uppercase;margin-right:5px">Email</span>'+r.email;body.appendChild(er);}
        if(r.notes){var nr=document.createElement("div");nr.style.cssText="font-size:10px;color:var(--muted);margin-top:7px;padding-top:7px;border-top:1px solid var(--border);line-height:1.5";nr.textContent=r.notes.length>90?r.notes.substring(0,90)+"...":r.notes;body.appendChild(nr);}
        // Last interaction summary
        if(r.lastInteractionDate){
          var li=document.createElement("div");li.style.cssText="font-size:10px;color:var(--muted);margin-top:6px;padding-top:6px;border-top:1px solid var(--border)";
          li.textContent="Last contact: "+r.lastInteractionDate+" via "+(r.lastInteractionType||"");body.appendChild(li);
        }
        var ar=document.createElement("div");ar.style.cssText="display:flex;gap:5px;margin-top:8px;padding-top:7px;border-top:1px solid var(--border)";
        var vb=document.createElement("button");vb.style.cssText="flex:1;padding:5px;background:var(--navy);border:none;border-radius:var(--rs);font-size:10px;cursor:pointer;color:#fff;font-weight:700";vb.textContent="View / Log";vb.addEventListener("click",(function(rid){return function(){showRepDetail(rid);};})(r.id));
        var eb=document.createElement("button");eb.style.cssText="padding:5px 9px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;cursor:pointer;color:var(--muted)";eb.textContent="Edit";eb.addEventListener("click",(function(rid){return function(e){e.stopPropagation();showRepForm(rid);};})(r.id));
        var db=document.createElement("button");db.style.cssText="padding:5px 9px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;cursor:pointer;color:var(--rtxt)";db.textContent="Del";db.addEventListener("click",(function(rid,rname){return async function(e){e.stopPropagation();if(confirm("Delete "+rname+"?")){reps=reps.filter(function(x){return x.id!==rid;});await sbDelete("reps",rid);saveReps();renderRepsView();toast("Rep deleted \u2713");}};})(r.id,r.name));
        ar.appendChild(vb);ar.appendChild(eb);ar.appendChild(db);body.appendChild(ar);card.appendChild(body);grid.appendChild(card);
      });
      section.appendChild(grid);rv.appendChild(section);
    });
  }
  var bk=document.createElement("button");bk.className="bkl";bk.textContent="\u2190 Back to dashboard";bk.addEventListener("click",showDash);rv.appendChild(bk);
}

function showRepDetail(id) {
  var r = reps.find(function(x){return x.id===id;});
  if (!r) return;
  if (!r.log) r.log = [];

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:580px;max-height:90vh;overflow-y:auto;border-top:3px solid var(--red)";

  function rebuild() {
    box.innerHTML = "";
    // Header
    var bh = document.createElement("div");
    bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid var(--red3)";
    var binfo = document.createElement("div");binfo.style.display="flex";binfo.style.alignItems="center";binfo.style.gap="10px";
    var bav = document.createElement("div");bav.style.cssText="width:38px;height:38px;border-radius:50%;background:var(--red3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0";bav.textContent=ini(r.name);
    var btxt = document.createElement("div");
    var bname = document.createElement("div");bname.style.cssText="font-weight:700;font-size:13px;color:#fff";bname.textContent=r.name;
    var bco = document.createElement("div");bco.style.cssText="font-size:10px;color:rgba(255,255,255,.6);margin-top:2px";bco.textContent=(r.company||"")+(r.manufacturer?" · "+r.manufacturer:"");
    btxt.appendChild(bname);btxt.appendChild(bco);binfo.appendChild(bav);binfo.appendChild(btxt);
    var bbtns = document.createElement("div");bbtns.style.cssText="display:flex;gap:6px;align-items:center";
    var editB = document.createElement("button");editB.style.cssText="padding:4px 10px;border:1px solid rgba(255,255,255,.25);border-radius:var(--rs);color:#fff;background:rgba(255,255,255,.08);font-size:10px;cursor:pointer";editB.textContent="✎ Edit";
    editB.addEventListener("click",function(){document.body.removeChild(overlay);showRepForm(id);});
    var shareB = document.createElement("button");shareB.style.cssText="padding:4px 10px;border:1px solid rgba(255,255,255,.25);border-radius:var(--rs);color:#fff;background:rgba(255,255,255,.08);font-size:10px;cursor:pointer";shareB.textContent="\uD83D\uDCCB Copy details";
    shareB.addEventListener("click",function(){
      var lines = [];
      lines.push(r.name + (r.manufacturer ? " (" + r.manufacturer + ")" : ""));
      if (r.company) lines.push(r.company);
      if (r.tel) lines.push("Tel: " + r.tel);
      if (r.mobile) lines.push("Mobile: " + r.mobile);
      if (r.email) lines.push("Email: " + r.email);
      if (r.website) lines.push("Website: " + r.website);
      var body2 = lines.join("\n");
      navigator.clipboard.writeText(body2).then(function(){
        toast("Copied to clipboard \u2713 Paste it wherever you need");
      }).catch(function(){
        // Fallback for older browsers / permissions issues
        var ta = document.createElement("textarea");
        ta.value = body2; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        try { document.execCommand("copy"); toast("Copied to clipboard \u2713 Paste it wherever you need"); }
        catch(e) { toast("Couldn't copy automatically \u2014 select and copy manually"); }
        document.body.removeChild(ta);
      });
    });
    bbtns.appendChild(editB);bbtns.appendChild(shareB);
    var cx = document.createElement("button");cx.style.cssText="background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1";cx.textContent="×";cx.addEventListener("click",function(){document.body.removeChild(overlay);});
    bbtns.appendChild(cx);
    bh.appendChild(binfo);bh.appendChild(bbtns);box.appendChild(bh);

    var bd = document.createElement("div");bd.style.cssText="padding:16px;display:flex;flex-direction:column;gap:12px";

    // Contact details row
    var detRow = document.createElement("div");detRow.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:10px;background:var(--alt);border-radius:var(--rs);padding:12px";
    function detField(lbl,val,wide){
      var f=document.createElement("div");if(wide)f.style.gridColumn="1/-1";
      var l=document.createElement("div");l.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;
      var v=document.createElement("div");v.style.cssText="font-size:12px;color:var(--text)";v.textContent=val||"—";
      f.appendChild(l);f.appendChild(v);detRow.appendChild(f);
    }
    detField("Telephone",r.tel);detField("Mobile",r.mobile);
    detField("Email",r.email,true);detField("Website",r.website);
    detField("Company",r.company);
    if(r.notes)detField("Notes",r.notes,true);
    if(r.lastContact||r.nextVisit){
      detField("Last visited",r.lastContact?r.lastContact.split("-").reverse().join("/"):"");
      detField("Next visit",r.nextVisit?r.nextVisit.split("-").reverse().join("/"):"");
    }
    bd.appendChild(detRow);

    var srcRepCount=(sourcing||[]).filter(function(s){return sourcingMatchesRep(s, r);}).length;
    var srcRepBtn=document.createElement("button");srcRepBtn.style.cssText="margin-bottom:4px;padding:6px 14px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid #e67e22;"+(srcRepCount?"background:#fff4e8;color:#a5590f":"background:#e67e22;color:#fff");
    srcRepBtn.textContent=srcRepCount?("\uD83C\uDFED Special order enquiries ("+srcRepCount+")"):"\uD83C\uDFED + New special order enquiry";
    srcRepBtn.addEventListener("click",function(){document.body.removeChild(overlay);srcRepCount?showSourcing(null,r.id):showSourcingForm(null,null,r.id);});
    bd.appendChild(srcRepBtn);

    // Interaction log section
    var logSec = document.createElement("div");
    // Pending samples from this rep
    var repSamples = samples.filter(function(s){ return s.repId === r.id && s.status !== "Returned" && s.status !== "Order Placed" && s.status !== "Not Interested"; });
    if (repSamples.length) {
      var psTitle = document.createElement("div");
      psTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--border)";
      psTitle.textContent = "Pending samples from this rep (" + repSamples.length + ")";
      bd.appendChild(psTitle);
      repSamples.forEach(function(s, si) {
        var sc = document.createElement("div");
        sc.style.cssText = "background:#f4f7ff;border:2px solid #b8caf5;border-radius:var(--rs);padding:9px 12px;margin-bottom:7px;display:flex;align-items:center;gap:10px;flex-wrap:wrap";
        var sinfo = document.createElement("div"); sinfo.style.flex = "1";
        var snm = document.createElement("div"); snm.style.cssText = "font-weight:700;font-size:11px;color:var(--navy)"; snm.textContent = s.product + (s.detail ? " — " + s.detail : "");
        var sfor = document.createElement("div"); sfor.style.cssText = "font-size:10px;color:var(--muted);margin-top:2px"; sfor.textContent = "For: " + (s.clientName || "Unassigned") + " · Requested: " + s.dateSent;
        sinfo.appendChild(snm); sinfo.appendChild(sfor);
        var rcvBtn2 = document.createElement("button");
        rcvBtn2.style.cssText = "padding:5px 12px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:var(--rs);font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700;white-space:nowrap";
        rcvBtn2.textContent = "✓ Mark Received";
        var globalIdx = samples.indexOf(s);
        rcvBtn2.addEventListener("click", (function(gi){ return function(){ markSampleReceived(gi); rebuild(); }; })(globalIdx));
        sc.appendChild(sinfo); sc.appendChild(rcvBtn2);
        bd.appendChild(sc);
      });
    }

    var logTitle = document.createElement("div");logTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid var(--border)";logTitle.textContent="Interaction log ("+(r.log.length+" entries)");
    logSec.appendChild(logTitle);

    if(r.log.length){
      r.log.forEach(function(l,idx2){
        var entry=document.createElement("div");entry.style.cssText="background:var(--alt);border:2px solid var(--border);border-radius:var(--rs);padding:9px 11px;margin-bottom:7px";
        var meta=document.createElement("div");meta.style.cssText="display:flex;align-items:center;gap:6px;margin-bottom:5px;flex-wrap:wrap";
        var ltype=document.createElement("span");ltype.style.cssText="font-size:9px;font-weight:700;padding:2px 6px;border-radius:20px;background:var(--lbg);color:var(--ltxt)";ltype.textContent=l.type;
        var ldate=document.createElement("span");ldate.style.cssText="font-size:9px;color:var(--muted)";ldate.textContent=l.date;
        var delB=document.createElement("button");delB.style.cssText="margin-left:auto;background:none;border:none;color:var(--muted);cursor:pointer;font-size:13px;padding:0 2px";delB.textContent="×";
        delB.addEventListener("click",(function(i){return function(){r.log.splice(i,1);saveReps();rebuild();};})(idx2));
        meta.appendChild(ltype);meta.appendChild(ldate);meta.appendChild(delB);
        var note=document.createElement("div");note.style.cssText="font-size:11px;line-height:1.5;color:var(--text)";note.textContent=l.note;
        entry.appendChild(meta);entry.appendChild(note);logSec.appendChild(entry);
      });
    } else {
      var noLog=document.createElement("p");noLog.style.cssText="font-size:11px;color:var(--muted);margin-bottom:8px";noLog.textContent="No interactions logged yet.";logSec.appendChild(noLog);
    }

    // Log interaction form
    var logForm = document.createElement("div");
    logForm.style.cssText = "background:var(--abg);border:2px solid #f0c060;border-radius:var(--rs);padding:11px;margin-top:6px";
    var lfTitle = document.createElement("div");lfTitle.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--atxt);margin-bottom:9px";lfTitle.textContent="Log new interaction";
    logForm.appendChild(lfTitle);
    var lfRow = document.createElement("div");lfRow.style.cssText="display:flex;gap:6px;margin-bottom:7px";
    var typesel = document.createElement("select");typesel.id="rep_ltyp";typesel.style.cssText="flex:1;padding:5px 7px;border:2px solid #f0c060;border-radius:var(--rs);font-size:11px;background:#fff;font-family:inherit;color:var(--text);outline:none";
    ["","Phone","Text","Email","Site Visit","Price Request","Problem Resolution","Product Query","Sample Request","Other"].forEach(function(s){var opt=document.createElement("option");opt.value=s;opt.textContent=s||"Type...";typesel.appendChild(opt);});
    var datein = document.createElement("input");datein.type="date";datein.id="rep_ldat";datein.value=new Date().toISOString().split("T")[0];datein.style.cssText="flex:1;padding:5px 7px;border:2px solid #f0c060;border-radius:var(--rs);font-size:11px;background:#fff;font-family:inherit;color:var(--text);outline:none";
    lfRow.appendChild(typesel);lfRow.appendChild(datein);logForm.appendChild(lfRow);
    var ta = document.createElement("textarea");ta.id="rep_lnot";ta.placeholder="What was discussed...";ta.style.cssText="width:100%;padding:5px 7px;border:2px solid #f0c060;border-radius:var(--rs);font-size:11px;background:#fff;resize:vertical;min-height:55px;margin-bottom:7px;font-family:inherit;color:var(--text)";logForm.appendChild(ta);
    var smpF=document.createElement("div");smpF.id="repSmpF";
    smpF.style.cssText="display:none;background:#fff;border:2px solid #f0c060;border-radius:var(--rs);padding:9px;margin-bottom:7px";
    var smpT=document.createElement("div");smpT.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--atxt);margin-bottom:8px";smpT.textContent="Sample request details";smpF.appendChild(smpT);
    var sg=document.createElement("div");sg.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:7px";
    function mkSF(lbl,inp2){var w=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;w.appendChild(l);w.appendChild(inp2);return w;}
    var pSel=document.createElement("select");pSel.id="rep_smpProd";pSel.style.cssText="width:100%;padding:5px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;font-family:inherit";
    var dp2=document.createElement("option");dp2.value="";dp2.textContent="-- Product --";pSel.appendChild(dp2);
    PRODUCTS.forEach(function(p){var opt=document.createElement("option");opt.value=p;opt.textContent=p;pSel.appendChild(opt);});
    var dInp=document.createElement("input");dInp.id="rep_smpDet";dInp.placeholder="Colour, range, size...";dInp.style.cssText="width:100%;padding:5px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;font-family:inherit";
    sg.appendChild(mkSF("Product",pSel));sg.appendChild(mkSF("Detail",dInp));smpF.appendChild(sg);
    var clLbl=document.createElement("label");clLbl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";clLbl.textContent="For which client?";
    var clSel=document.createElement("select");clSel.id="rep_smpClient";clSel.style.cssText="width:100%;padding:5px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;font-family:inherit";
    var nOpt=document.createElement("option");nOpt.value="";nOpt.textContent="-- No specific client --";clSel.appendChild(nOpt);
    clients.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(c){var opt=document.createElement("option");opt.value=c.id;opt.textContent=c.name+" ("+c.binder+")";clSel.appendChild(opt);});
    smpF.appendChild(clLbl);smpF.appendChild(clSel);logForm.appendChild(smpF);
    typesel.addEventListener("change",function(){smpF.style.display=this.value==="Sample Request"?"block":"none";});
    var lfBtns=document.createElement("div");lfBtns.style.cssText="display:flex;gap:6px";
    var saveB=document.createElement("button");saveB.style.cssText="padding:5px 12px;background:var(--red);border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer";saveB.textContent="Save";
    saveB.addEventListener("click",function(){
      var type=document.getElementById("rep_ltyp").value;
      var note=document.getElementById("rep_lnot").value.trim();
      var date=document.getElementById("rep_ldat").value;
      if(!type){toast("Please select an interaction type");return;}
      if(!note&&type!=="Sample Request"){toast("Please add some notes");return;}
      var logEntry={date:fd(date),type:type,note:note};
      if(type==="Sample Request"){
        var prod=document.getElementById("rep_smpProd").value;
        var det=document.getElementById("rep_smpDet").value.trim();
        var lcId=document.getElementById("rep_smpClient").value;
        var lcName="";
        if(lcId){var lc=clients.find(function(x){return x.id===lcId;});if(lc)lcName=lc.name;}
        logEntry.note=note+(lcName?" [For: "+lcName+"]":"");
        samples.push({id:"SMP-"+Date.now(),clientName:lcName||"Unassigned",sampleType:"Loan",
          product:prod||"Other",detail:det,dateSent:fd(date),status:"Sent - Awaiting Return",
          notes:"Requested from "+r.name+" ("+r.manufacturer+"). "+note,
          repId:r.id,repName:r.name,linkedClientId:lcId});
        saveSamples();
        if(lcId){
          var lc2=clients.find(function(x){return x.id===lcId;});
          if(lc2){
            var fu=new Date();fu.setDate(fu.getDate()+5);
            var fuStr=fd(fu.toISOString().split("T")[0]);
            if(!lc2.followup)lc2.followup=fuStr;
            lc2.notes=(lc2.notes?lc2.notes+" | ":"")+"Sample from "+r.name+(prod?" - "+prod:"")+" expected ~"+fuStr;
            saveC();
            toast("Sample logged + follow-up set on "+lc2.name+" \u2713");
          }
        } else { toast("Sample request logged \u2713"); }
      } else { toast("Interaction logged \u2713"); }
      r.log.unshift(logEntry);r.lastInteractionDate=fd(date);r.lastInteractionType=type;
      saveReps();rebuild();
    });
    lfBtns.appendChild(saveB);logForm.appendChild(lfBtns);
    logSec.appendChild(logForm);
    bd.appendChild(logSec);
    box.appendChild(bd);
  }

  rebuild();
  overlay.appendChild(box);document.body.appendChild(overlay);
}


function showRepForm(id){
  var r=id?reps.find(function(x){return x.id===id;}):null;
  var overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box=document.createElement("div");box.style.cssText="background:var(--surface);border-radius:var(--r);width:100%;max-width:520px;max-height:90vh;overflow-y:auto;border-top:3px solid var(--red)";
  var bh=document.createElement("div");bh.style.cssText="background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht=document.createElement("h2");bht.style.cssText="font-size:13px;font-weight:700;color:#fff";bht.textContent=id?"Edit Rep/ASM":"Add Rep / ASM";
  var cx=document.createElement("button");cx.style.cssText="background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1";cx.textContent="\u00d7";cx.addEventListener("click",function(){document.body.removeChild(overlay);});
  bh.appendChild(bht);bh.appendChild(cx);box.appendChild(bh);
  var bd=document.createElement("div");bd.style.cssText="padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkF2(lbl,inp2){var w=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;w.appendChild(l);w.appendChild(inp2);return w;}
  function mkI2(fid,val,ph,type2){var i=document.createElement("input");i.id=fid;i.value=val||"";i.placeholder=ph||"";i.type=type2||"text";i.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";return i;}
  function mkTa2(fid,val,ph){var t=document.createElement("textarea");t.id=fid;t.value=val||"";t.placeholder=ph||"";t.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:70px";return t;}
  var row1=document.createElement("div");row1.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var nw=document.createElement("div");var nl=document.createElement("label");nl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";nl.textContent="Rep / ASM name *";var ni=mkI2("r_name",r?r.name:"","Full name");nw.appendChild(nl);nw.appendChild(ni);
  // Business card scanner button
  var scanWrap = document.createElement("div");
  scanWrap.style.cssText = "background:#eef1f8;border:1px solid var(--navy);border-radius:var(--rs);padding:10px 12px;display:flex;align-items:center;gap:10px;margin-bottom:4px";
  var scanIcon = document.createElement("span"); scanIcon.style.fontSize="20px"; scanIcon.textContent="\uD83D\uDCF7";
  var scanInfo = document.createElement("div"); scanInfo.style.flex="1";
  var scanTitle = document.createElement("div"); scanTitle.style.cssText="font-weight:700;font-size:12px;color:var(--navy)"; scanTitle.textContent="Scan Business Card";
  var scanSub = document.createElement("div"); scanSub.style.cssText="font-size:10px;color:var(--muted)"; scanSub.textContent="Take a photo and AI fills in the form automatically";
  scanInfo.appendChild(scanTitle); scanInfo.appendChild(scanSub);
  var scanBtn = document.createElement("button");
  scanBtn.style.cssText = "padding:6px 12px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap";
  scanBtn.textContent = "\uD83D\uDCF7 Scan";
  scanBtn.addEventListener("click", function(e){ e.preventDefault(); scanBusinessCard(); });
  scanWrap.appendChild(scanIcon); scanWrap.appendChild(scanInfo); scanWrap.appendChild(scanBtn);
  bd.appendChild(scanWrap);

  var mw=document.createElement("div");var ml=document.createElement("label");ml.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";ml.textContent="Manufacturer";
  var ms=document.createElement("select");ms.id="r_mfr";ms.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  MANUFACTURERS.forEach(function(m){var opt=document.createElement("option");opt.value=m;opt.textContent=m;if(r&&r.manufacturer===m)opt.selected=true;ms.appendChild(opt);});
  mw.appendChild(ml);mw.appendChild(ms);row1.appendChild(nw);row1.appendChild(mw);bd.appendChild(row1);
  bd.appendChild(mkF2("Company name",mkI2("r_company",r?r.company:"","e.g. Karndean Designflooring Ltd")));
  var row2=document.createElement("div");row2.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var tw=document.createElement("div");var tl=document.createElement("label");tl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";tl.textContent="Telephone";var ti2=mkI2("r_tel",r?r.tel:"","Mobile / direct","tel");tw.appendChild(tl);tw.appendChild(ti2);
  var mobw=document.createElement("div");var mobl=document.createElement("label");mobl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";mobl.textContent="Mobile";var mobi=mkI2("r_mob",r?r.mobile:"","Mobile number","tel");mobw.appendChild(mobl);mobw.appendChild(mobi);
  row2.appendChild(tw);row2.appendChild(mobw);bd.appendChild(row2);
  bd.appendChild(mkF2("Email",mkI2("r_email",r?r.email:"","name@manufacturer.co.uk","email")));
  bd.appendChild(mkF2("Company website",mkI2("r_web",r?r.website:"","e.g. karndean.com")));
  bd.appendChild(mkF2("Notes (samples, visits, promotions, pricing)",mkTa2("r_notes",r?r.notes:"","Add notes about visits, samples, promotions...")));
  var row3=document.createElement("div");row3.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var lw=document.createElement("div");var ll=document.createElement("label");ll.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";ll.textContent="Last visited";var li2=document.createElement("input");li2.type="date";li2.id="r_last";li2.value=r?r.lastContact:"";li2.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";lw.appendChild(ll);lw.appendChild(li2);
  var nxw=document.createElement("div");var nxl=document.createElement("label");nxl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";nxl.textContent="Next visit / follow-up";var nxi=document.createElement("input");nxi.type="date";nxi.id="r_next";nxi.value=r?r.nextVisit:"";nxi.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";nxw.appendChild(nxl);nxw.appendChild(nxi);
  row3.appendChild(lw);row3.appendChild(nxw);bd.appendChild(row3);

  var trackWrap = document.createElement("div"); trackWrap.style.cssText = "background:var(--alt);border-radius:var(--rs);padding:9px 11px;display:flex;align-items:center;gap:9px";
  var trackChk = document.createElement("input"); trackChk.type = "checkbox"; trackChk.id = "r_excluded"; trackChk.checked = r ? !!r.excludeFromTracking : false; trackChk.style.cssText = "width:15px;height:15px;cursor:pointer;flex-shrink:0";
  var trackLbl = document.createElement("label"); trackLbl.style.cssText = "font-size:11px;color:var(--text);cursor:pointer"; trackLbl.htmlFor = "r_excluded";
  trackLbl.innerHTML = "<strong>Not my area / contact only</strong> \u2014 don't flag this rep as overdue for a visit (e.g. a number you have but they're not your ASM, or a one-off you don't currently use)";
  trackWrap.appendChild(trackChk); trackWrap.appendChild(trackLbl);
  bd.appendChild(trackWrap);

  box.appendChild(bd);
  var foot=document.createElement("div");foot.style.cssText="padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB=document.createElement("button");cancelB.style.cssText="padding:6px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";cancelB.textContent="Cancel";cancelB.addEventListener("click",function(){document.body.removeChild(overlay);});
  var saveB=document.createElement("button");saveB.style.cssText="padding:6px 14px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";saveB.textContent="Save rep";
  saveB.addEventListener("click",function(){
    var name=document.getElementById("r_name").value.trim();if(!name){toast("Name is required");return;}
    var existingRep=id?reps.find(function(x){return x.id===id;}):null;
    var existingLog=existingRep?existingRep.log||[]:[];
    var lastIntDate=existingRep?existingRep.lastInteractionDate||"":"";
    var lastIntType=existingRep?existingRep.lastInteractionType||"":"";
    var data={id:id||("REP-"+Date.now()),name:name,manufacturer:document.getElementById("r_mfr").value,company:document.getElementById("r_company").value.trim(),tel:document.getElementById("r_tel").value.trim(),mobile:document.getElementById("r_mob").value.trim(),email:document.getElementById("r_email").value.trim(),website:document.getElementById("r_web").value.trim(),notes:document.getElementById("r_notes").value.trim(),lastContact:document.getElementById("r_last").value,nextVisit:document.getElementById("r_next").value,log:existingLog,lastInteractionDate:lastIntDate,lastInteractionType:lastIntType,excludeFromTracking:document.getElementById("r_excluded").checked};
    if(id){var idx=reps.findIndex(function(x){return x.id===id;});if(idx>=0)reps[idx]=data;else reps.push(data);}else reps.push(data);
    saveReps();document.body.removeChild(overlay);renderRepsView();toast((id?"Rep updated":"Rep added")+" \u2713");
  });
  foot.appendChild(cancelB);foot.appendChild(saveB);box.appendChild(foot);overlay.appendChild(box);document.body.appendChild(overlay);
}

// ── SALES ─────────────────────────────────────────────────────────
function getDailySalesData(year, month){ // month is 0-indexed (0=Jan)
  var daysInMonth = new Date(year, month+1, 0).getDate();
  var days = []; for (var d=1; d<=daysInMonth; d++) days.push(0);
  var monthTotal = 0;
  clients.forEach(function(c){(c.log||[]).forEach(function(l){
    if(!l.quote||l.quote.status!=="Collected")return;
    var useDate = l.quote.collectedDate || l.date;
    if(!useDate)return;
    var dp=useDate.split("/");if(dp.length!==3)return;
    var d=parseInt(dp[0]),m=parseInt(dp[1])-1,y=parseInt(dp[2]);
    if(y!==year||m!==month)return;
    var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
    days[d-1]+=v; monthTotal+=v;
  });});
  return{days:days,monthTotal:monthTotal,daysInMonth:daysInMonth};
}
function getSalesData(year){
  var qtrs={Q1:0,Q2:0,Q3:0,Q4:0},prodTotals={},qtrProd={Q1:{},Q2:{},Q3:{},Q4:{}},yearTotal=0;
  // subProd[product][subcategory][quarter] = value - only populated for products with a ": " sub-category split
  var subProd={};
  PRODUCTS.forEach(function(p){prodTotals[p]=0;});
  clients.forEach(function(c){(c.log||[]).forEach(function(l){
    if(!l.quote||l.quote.status!=="Collected")return;
    var useDate = l.quote.collectedDate || l.date;
    if(!useDate)return;
    var dp=useDate.split("/");if(dp.length!==3||parseInt(dp[2])!==year)return;
    var m=parseInt(dp[1]);var q=m<=3?"Q1":m<=6?"Q2":m<=9?"Q3":"Q4";
    var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
    var cat=l.quote.category||l.quote.products||"Other";
    var baseCat=cat.indexOf(": ")>-1?cat.split(": ")[0]:cat;
    var subCat=cat.indexOf(": ")>-1?cat.split(": ")[1]:null;
    var matched=PRODUCTS.indexOf(baseCat)>-1?baseCat:"Other";
    qtrs[q]+=v;yearTotal+=v;prodTotals[matched]=(prodTotals[matched]||0)+v;qtrProd[q][matched]=(qtrProd[q][matched]||0)+v;
    if(subCat){
      if(!subProd[matched])subProd[matched]={};
      if(!subProd[matched][subCat])subProd[matched][subCat]={Q1:0,Q2:0,Q3:0,Q4:0,total:0};
      subProd[matched][subCat][q]+=v;
      subProd[matched][subCat].total+=v;
    }
  });});
  return{qtrs:qtrs,prodTotals:prodTotals,qtrProd:qtrProd,yearTotal:yearTotal,subProd:subProd};
}
function getYears(){var y={};y[new Date().getFullYear()]=1;clients.forEach(function(c){(c.log||[]).forEach(function(l){if(l.quote&&l.date){var dp=l.date.split("/");if(dp.length===3)y[parseInt(dp[2])]=1;}});});return Object.keys(y).map(Number).sort();}

var QUARTER_MONTHS = {Q1:[1,2,3], Q2:[4,5,6], Q3:[7,8,9], Q4:[10,11,12]};
var QUARTER_MONTH_NAMES = {Q1:["January","February","March"], Q2:["April","May","June"], Q3:["July","August","September"], Q4:["October","November","December"]};

function getQuarterMonthlyBreakdown(year, quarter) {
  var months = QUARTER_MONTHS[quarter];
  var totals = {}; months.forEach(function(m){ totals[m] = 0; });
  clients.forEach(function(c){ (c.log||[]).forEach(function(l){
    if (!l.quote || l.quote.status!=="Collected") return;
    var useDate = l.quote.collectedDate || l.date;
    if (!useDate) return;
    var dp = useDate.split("/"); if (dp.length!==3 || parseInt(dp[2])!==year) return;
    var m = parseInt(dp[1]); if (months.indexOf(m)===-1) return;
    var v = (parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
    totals[m] = (totals[m]||0) + v;
  });});
  return totals;
}

function showQuarterDetail(year, quarter) {
  var data = getSalesData(year);
  var qTotal = data.qtrs[quarter] || 0;
  var qProd = data.qtrProd[quarter] || {};
  var topProducts = Object.keys(qProd).map(function(p){ return {name:p, value:qProd[p]}; }).filter(function(p){ return p.value>0; }).sort(function(a,b){ return b.value-a.value; });
  var monthly = getQuarterMonthlyBreakdown(year, quarter);
  var months = QUARTER_MONTHS[quarter];
  var monthNamesFull = QUARTER_MONTH_NAMES[quarter];
  var qLabels = {Q1:"Q1 (Jan\u2013Mar)", Q2:"Q2 (Apr\u2013Jun)", Q3:"Q3 (Jul\u2013Sep)", Q4:"Q4 (Oct\u2013Dec)"};

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:560px;max-height:90vh;overflow-y:auto";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:15px;font-weight:700;color:#fff"; bht.textContent = qLabels[quarter] + " " + year + " \u2014 \u00a3" + qTotal.toLocaleString("en-GB");
  var cx = document.createElement("button"); cx.className = "no-print"; cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:16px";

  // Sales per month in the quarter
  var moSec = document.createElement("div");
  var moTitle = document.createElement("div"); moTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:9px;padding-bottom:6px;border-top:1px solid var(--border);padding-top:2px"; moTitle.textContent = "Sales per month";
  moSec.appendChild(moTitle);
  var maxMo = Math.max.apply(null, months.map(function(m){ return monthly[m]||0; }).concat([1]));
  months.forEach(function(m, mi){
    var v = monthly[m]||0;
    var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:center;gap:10px;margin-bottom:7px";
    var mLbl = document.createElement("div"); mLbl.style.cssText = "font-size:11px;color:var(--muted);width:70px;flex-shrink:0"; mLbl.textContent = monthNamesFull[mi];
    var barOuter = document.createElement("div"); barOuter.style.cssText = "flex:1;background:var(--alt);border-radius:20px;height:16px;overflow:hidden";
    var barInner = document.createElement("div"); barInner.style.cssText = "height:100%;background:var(--navy);border-radius:20px;width:"+(maxMo>0?Math.max(2,(v/maxMo)*100):0)+"%";
    barOuter.appendChild(barInner);
    var mVal = document.createElement("div"); mVal.style.cssText = "font-size:12px;font-weight:700;color:var(--text);width:80px;text-align:right;flex-shrink:0"; mVal.textContent = "\u00a3"+v.toLocaleString("en-GB");
    row.appendChild(mLbl); row.appendChild(barOuter); row.appendChild(mVal);
    moSec.appendChild(row);
  });
  bd.appendChild(moSec);

  // Product breakdown for the quarter
  var prodSec = document.createElement("div");
  var prodTitle = document.createElement("div"); prodTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:9px;padding-bottom:6px;border-top:1px solid var(--border);padding-top:12px"; prodTitle.textContent = "Product breakdown this quarter";
  prodSec.appendChild(prodTitle);
  if (!topProducts.length) {
    var noProd = document.createElement("div"); noProd.style.cssText = "font-size:12px;color:var(--muted)"; noProd.textContent = "No collected sales in this quarter."; prodSec.appendChild(noProd);
  } else {
    var pieWrap = document.createElement("div"); pieWrap.style.cssText = "height:220px;position:relative";
    var pieCan = document.createElement("canvas"); pieCan.id = "qtrPieCh";
    pieWrap.appendChild(pieCan);
    prodSec.appendChild(pieWrap);
  }
  bd.appendChild(prodSec);

  box.appendChild(bd);
  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var qtrPrintB = document.createElement("button"); qtrPrintB.className = "no-print"; qtrPrintB.style.cssText = "padding:7px 14px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; qtrPrintB.textContent = "\uD83D\uDDA8\uFE0F Print";
  qtrPrintB.addEventListener("click", function(){ printBodyOverlay(overlay); });
  var closeB = document.createElement("button"); closeB.className = "no-print"; closeB.style.cssText = "padding:7px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; closeB.textContent = "Close";
  closeB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  foot.appendChild(qtrPrintB); foot.appendChild(closeB); box.appendChild(foot);
  overlay.appendChild(box); document.body.appendChild(overlay);
  if (topProducts.length) {
    setTimeout(function(){ mkPieChart("qtrPieCh", topProducts.map(function(p){return p.name;}), topProducts.map(function(p){return p.value;})); }, 60);
  }
}

function renderSalesView(){
  var sv=document.getElementById("salesView");sv.innerHTML="";
  var years=getYears();var data=getSalesData(currentSalesYear);
  var hdr=document.createElement("div");hdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:10px";
  var title=document.createElement("div");title.className="page-title";title.textContent="Sales Intelligence";
  var ysel=document.createElement("div");ysel.className="no-print";ysel.style.cssText="display:flex;gap:5px;align-items:center";
  var yl=document.createElement("span");yl.style.cssText="font-size:10px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.4px";yl.textContent="Year:";ysel.appendChild(yl);
  years.forEach(function(y){var btn=document.createElement("button");btn.style.cssText="padding:4px 12px;border-radius:20px;border:2px solid var(--border);font-size:11px;font-weight:700;cursor:pointer;"+(y===currentSalesYear?"background:var(--navy);color:#fff;border-color:var(--navy)":"background:var(--surface);color:var(--muted)");btn.textContent=y;btn.addEventListener("click",function(){currentSalesYear=y;renderSalesView();});ysel.appendChild(btn);});
  var salesPrintBtn=document.createElement("button");salesPrintBtn.className="no-print";salesPrintBtn.style.cssText="padding:4px 12px;border-radius:20px;border:none;background:var(--navy);color:#fff;font-size:11px;font-weight:700;cursor:pointer";salesPrintBtn.textContent="\uD83D\uDDA8\uFE0F Print summary";
  salesPrintBtn.addEventListener("click",function(){ printSalesSummary(); });
  hdr.appendChild(title);hdr.appendChild(salesPrintBtn);hdr.appendChild(ysel);sv.appendChild(hdr);
  var kr=document.createElement("div");kr.style.cssText="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:20px";kr.id="salesKpiRow";
  [{l:currentSalesYear+" total",v:"\u00a3"+data.yearTotal.toLocaleString("en-GB"),c:"kv-blue",hi:true},{l:"Q1 Jan-Mar",v:"\u00a3"+data.qtrs.Q1.toLocaleString("en-GB"),c:"",q:"Q1"},{l:"Q2 Apr-Jun",v:"\u00a3"+data.qtrs.Q2.toLocaleString("en-GB"),c:"",q:"Q2"},{l:"Q3 Jul-Sep",v:"\u00a3"+data.qtrs.Q3.toLocaleString("en-GB"),c:"",q:"Q3"},{l:"Q4 Oct-Dec",v:"\u00a3"+data.qtrs.Q4.toLocaleString("en-GB"),c:"",q:"Q4"}].forEach(function(k){
    var card=document.createElement("div");card.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px"+(k.hi?";border-top:3px solid var(--navy)":"");
    if(k.q){ card.style.cursor="pointer"; card.addEventListener("click",(function(qq){return function(){ showQuarterDetail(currentSalesYear, qq); }; })(k.q)); }
    var lbl=document.createElement("div");lbl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:5px";lbl.textContent=k.l+(k.q?" \u203a":"");
    var val=document.createElement("div");val.style.cssText="font-size:"+(k.hi?"22":"18")+"px;font-weight:700;color:"+(k.hi?"var(--navy)":"var(--text)");val.textContent=k.v;
    card.appendChild(lbl);card.appendChild(val);kr.appendChild(card);
  });sv.appendChild(kr);
  var monthNames=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var dailyData=getDailySalesData(currentSalesYear,currentSalesMonth);
  var dailyCard=document.createElement("div");dailyCard.className="not-in-sales-summary";dailyCard.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
  var dHdr=document.createElement("div");dHdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:8px";
  var dTitle=document.createElement("div");dTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)";dTitle.textContent="Daily sales \u2014 "+monthNames[currentSalesMonth]+" "+currentSalesYear+" (\u00a3"+dailyData.monthTotal.toLocaleString("en-GB")+")";
  var dNav=document.createElement("div");dNav.style.cssText="display:flex;align-items:center;gap:8px";
  var prevBtn=document.createElement("button");prevBtn.textContent="\u2190";prevBtn.style.cssText="padding:4px 10px;border-radius:var(--rs);border:2px solid var(--border);background:var(--surface);color:var(--text);font-size:12px;cursor:pointer;font-weight:700";
  var monthSel=document.createElement("select");monthSel.style.cssText="padding:4px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;font-family:inherit;color:var(--text)";
  monthNames.forEach(function(mn,mi){var o=document.createElement("option");o.value=mi;o.textContent=mn;if(mi===currentSalesMonth)o.selected=true;monthSel.appendChild(o);});
  var nextBtn=document.createElement("button");nextBtn.textContent="\u2192";nextBtn.style.cssText="padding:4px 10px;border-radius:var(--rs);border:2px solid var(--border);background:var(--surface);color:var(--text);font-size:12px;cursor:pointer;font-weight:700";
  prevBtn.addEventListener("click",function(){currentSalesMonth--;if(currentSalesMonth<0){currentSalesMonth=11;currentSalesYear--;}renderSalesView();});
  nextBtn.addEventListener("click",function(){currentSalesMonth++;if(currentSalesMonth>11){currentSalesMonth=0;currentSalesYear++;}renderSalesView();});
  monthSel.addEventListener("change",function(){currentSalesMonth=parseInt(this.value);renderSalesView();});
  dNav.appendChild(prevBtn);dNav.appendChild(monthSel);dNav.appendChild(nextBtn);
  dHdr.appendChild(dTitle);dHdr.appendChild(dNav);dailyCard.appendChild(dHdr);
  var dBody=document.createElement("div");dBody.style.cssText="display:grid;grid-template-columns:1fr 200px;gap:14px";
  var dChartWrap=document.createElement("div");dChartWrap.style.cssText="position:relative;height:220px";var dCan=document.createElement("canvas");dCan.id="sDailyCh";dChartWrap.appendChild(dCan);
  var dListWrap=document.createElement("div");dListWrap.style.cssText="max-height:220px;overflow-y:auto";
  var dListTitle=document.createElement("div");dListTitle.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);margin-bottom:6px";dListTitle.textContent="Best days";
  dListWrap.appendChild(dListTitle);
  var rankedDays=dailyData.days.map(function(v,i){return{day:i+1,value:v};}).filter(function(d){return d.value>0;}).sort(function(a,b){return b.value-a.value;});
  if(!rankedDays.length){var noD=document.createElement("div");noD.style.cssText="font-size:11px;color:var(--muted);padding:8px 0";noD.textContent="No collected sales this month yet";dListWrap.appendChild(noD);}
  else{rankedDays.forEach(function(d){
    var row=document.createElement("div");row.style.cssText="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--border);font-size:11px";
    var dLbl=document.createElement("span");dLbl.style.cssText="color:var(--muted)";dLbl.textContent=d.day+" "+monthNames[currentSalesMonth].slice(0,3);
    var dVal=document.createElement("span");dVal.style.cssText="font-weight:700;color:var(--navy)";dVal.textContent="\u00a3"+d.value.toLocaleString("en-GB");
    row.appendChild(dLbl);row.appendChild(dVal);dListWrap.appendChild(row);
  });}
  dBody.appendChild(dChartWrap);dBody.appendChild(dListWrap);dailyCard.appendChild(dBody);
  sv.appendChild(dailyCard);
  var cr=document.createElement("div");cr.id="salesChartsRow";cr.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px";
  var barCard=document.createElement("div");barCard.className="not-in-sales-summary";barCard.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px";
  var bTitle=document.createElement("div");bTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)";bTitle.textContent="Quarterly sales "+currentSalesYear;
  var bWrap=document.createElement("div");bWrap.style.cssText="position:relative;height:200px";var bCan=document.createElement("canvas");bCan.id="sBarCh";bWrap.appendChild(bCan);barCard.appendChild(bTitle);barCard.appendChild(bWrap);
  var pieCard=document.createElement("div");pieCard.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px";
  var pTitle=document.createElement("div");pTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between";
  var pTitleTxt=document.createElement("span");pTitleTxt.textContent="Product breakdown "+currentSalesYear+" (%)";
  var pTitleHint=document.createElement("span");pTitleHint.style.cssText="font-size:9px;font-weight:700;color:var(--muted);text-transform:none;letter-spacing:0;opacity:.7";pTitleHint.textContent="\uD83D\uDD0D enlarge";
  pTitle.appendChild(pTitleTxt);pTitle.appendChild(pTitleHint);
  var pWrap=document.createElement("div");pWrap.style.cssText="position:relative;height:200px;cursor:pointer";pWrap.title="Click to enlarge";
  var pCan=document.createElement("canvas");pCan.id="sPieCh";pWrap.appendChild(pCan);pieCard.appendChild(pTitle);pieCard.appendChild(pWrap);
  pWrap.addEventListener("click",function(){
    var ap2=PRODUCTS.filter(function(p){return(data.prodTotals[p]||0)>0;});
    if(!ap2.length){return;}
    showChartModal("Product breakdown "+currentSalesYear,ap2,ap2.map(function(p){return data.prodTotals[p]||0;}));
  });
  cr.appendChild(barCard);cr.appendChild(pieCard);sv.appendChild(cr);
  var activeProd=PRODUCTS.filter(function(p){return(data.prodTotals[p]||0)>0;});
  var tblCard=document.createElement("div");tblCard.className="not-in-sales-summary";tblCard.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:18px;overflow-x:auto";
  var tTitle=document.createElement("div");tTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)";tTitle.textContent="Product sales by quarter "+currentSalesYear;
  tblCard.appendChild(tTitle);
  if(!activeProd.length){var nd=document.createElement("div");nd.className="empty-state";nd.innerHTML="<div>&#128200;</div><div class='es-title'>No paid sales for "+currentSalesYear+" yet</div><div class='es-sub'>Mark quotes as Paid in client interaction logs to see data here</div>";tblCard.appendChild(nd);}
  else{
    var tbl=document.createElement("table");tbl.className="sales-tbl";
    var thead=document.createElement("thead");var hr=document.createElement("tr");
    ["Product","Q1","Q2","Q3","Q4","Total","% of Sales"].forEach(function(h){var th=document.createElement("th");th.style.textAlign=h==="Product"?"left":"right";th.textContent=h;hr.appendChild(th);});thead.appendChild(hr);tbl.appendChild(thead);
    var tbody=document.createElement("tbody");
    activeProd.forEach(function(p,pi){
      var hasSub = data.subProd[p] && Object.keys(data.subProd[p]).length > 0;
      var tr=document.createElement("tr");var rowTotal=data.prodTotals[p]||0;var pct=data.yearTotal>0?((rowTotal/data.yearTotal)*100).toFixed(1):"0.0";
      [p,data.qtrProd.Q1[p]||0,data.qtrProd.Q2[p]||0,data.qtrProd.Q3[p]||0,data.qtrProd.Q4[p]||0,rowTotal,pct+"%"].forEach(function(val,ci){
        var td=document.createElement("td");td.style.textAlign=ci===0?"left":"right";if(ci===5){td.style.fontWeight="700";td.style.color="var(--gtxt)";}
        if(ci===0 && hasSub){
          td.style.cursor="pointer";td.style.userSelect="none";
          var chevron=document.createElement("span");chevron.textContent="\u25B8 ";chevron.style.cssText="display:inline-block;transition:transform .15s;font-size:9px;color:var(--muted)";
          td.appendChild(chevron);td.appendChild(document.createTextNode(val));
        } else {
          td.textContent=ci>0&&ci<6?(val>0?"\u00a3"+Number(val).toLocaleString("en-GB"):"\u2014"):val;
        }
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
      if(hasSub){
        var subRows=[];
        var subNames=Object.keys(data.subProd[p]).sort(function(a,b){return data.subProd[p][b].total-data.subProd[p][a].total;});
        subNames.forEach(function(sn){
          var sd=data.subProd[p][sn];
          var subTr=document.createElement("tr");subTr.style.display="none";subTr.className="subcat-row";
          [sn,sd.Q1,sd.Q2,sd.Q3,sd.Q4,sd.total,""].forEach(function(val,ci){
            var td=document.createElement("td");td.style.textAlign=ci===0?"left":"right";
            td.style.color="var(--muted)";td.style.fontSize="11px";td.style.background="var(--bg)";
            if(ci===0){td.style.paddingLeft="26px";td.textContent="\u2014 "+val;}
            else if(ci<6){td.textContent=val>0?"\u00a3"+Number(val).toLocaleString("en-GB"):"\u2014";}
            subTr.appendChild(td);
          });
          tbody.appendChild(subTr);
          subRows.push(subTr);
        });
        var nameCell=tr.children[0];
        nameCell.addEventListener("click",function(){
          var isOpen=subRows[0].style.display!=="none";
          subRows.forEach(function(sr){sr.style.display=isOpen?"none":"";});
          nameCell.querySelector("span").style.transform=isOpen?"rotate(0deg)":"rotate(90deg)";
        });
      }
    });
    var totRow=document.createElement("tr");totRow.className="total-row";
    ["TOTAL",data.qtrs.Q1,data.qtrs.Q2,data.qtrs.Q3,data.qtrs.Q4,data.yearTotal,"100%"].forEach(function(val,ci){var td=document.createElement("td");td.style.textAlign=ci===0?"left":"right";td.textContent=ci>0&&ci<6?"\u00a3"+Number(val).toLocaleString("en-GB"):val;totRow.appendChild(td);});
    tbody.appendChild(totRow);tbl.appendChild(tbody);tblCard.appendChild(tbl);
  }
  sv.appendChild(tblCard);
  var bk=document.createElement("button");bk.className="bkl no-print";bk.textContent="\u2190 Back to dashboard";bk.addEventListener("click",showDash);sv.appendChild(bk);
  setTimeout(function(){
    mkDailyBarChart("sDailyCh",dailyData.days,currentSalesYear,currentSalesMonth);
    mkBarChart("sBarCh",[data.qtrs.Q1,data.qtrs.Q2,data.qtrs.Q3,data.qtrs.Q4]);
    var ap=PRODUCTS.filter(function(p){return(data.prodTotals[p]||0)>0;});
    if(ap.length)mkPieChart("sPieCh",ap,ap.map(function(p){return data.prodTotals[p]||0;}));
  },100);
}

// ── SAMPLES ───────────────────────────────────────────────────────
function renderSamplesView(){
  var sv=document.getElementById("samplesView");sv.innerHTML="";
  var hdr=document.createElement("div");hdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title=document.createElement("div");title.className="page-title";title.textContent="Sample Tracker";
  var addBtn=document.createElement("button");addBtn.style.cssText="padding:7px 16px;background:var(--red);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";addBtn.textContent="+ Log sample";addBtn.addEventListener("click",function(){showSampleForm();});
  hdr.appendChild(title);hdr.appendChild(addBtn);sv.appendChild(hdr);
  var sr=document.createElement("div");sr.className="stat-row cols4";
  [{l:"Total samples",v:samples.length,c:"kv-blue"},{l:"Loans out",v:samples.filter(function(s){return s.sampleType!=="Leave Behind"&&(s.status==="Sent - Awaiting Return"||s.status==="Sent - No Response");}).length,c:"kv-amber"},{l:"No response",v:samples.filter(function(s){return s.status==="Sent - No Response";}).length,c:"kv-red"},{l:"Orders placed",v:samples.filter(function(s){return s.status==="Order Placed";}).length,c:"kv-green"}].forEach(function(k){
    var card=document.createElement("div");card.className="stat-card";var lbl=document.createElement("div");lbl.className="sc-lbl";lbl.textContent=k.l;var val=document.createElement("div");val.className="sc-val "+k.c;val.textContent=k.v;card.appendChild(lbl);card.appendChild(val);sr.appendChild(card);
  });sv.appendChild(sr);
  // Sort: pending rep samples first, then by date descending
  var sortedSamples = samples.slice().sort(function(a,b){
    var aPending = a.repId && a.status==="Sent - Awaiting Return" ? 1 : 0;
    var bPending = b.repId && b.status==="Sent - Awaiting Return" ? 1 : 0;
    if(bPending !== aPending) return bPending - aPending;
    // Then newest first
    return samples.indexOf(b) - samples.indexOf(a);
  });
  // Build chart data
  var leaveBehindData = {}, loanData = {}, loanReturned = {};
  samples.forEach(function(s){
    var prod = s.product || "Other";
    if (s.sampleType === "Leave Behind") {
      leaveBehindData[prod] = (leaveBehindData[prod]||0) + 1;
    } else {
      loanData[prod] = (loanData[prod]||0) + 1;
      if (s.status === "Returned" || s.status === "Order Placed") {
        loanReturned[prod] = (loanReturned[prod]||0) + 1;
      }
    }
  });

  var hasLB = Object.keys(leaveBehindData).length > 0;
  var hasLoans = Object.keys(loanData).length > 0;

  if (hasLB || hasLoans) {
    var chartRow = document.createElement("div");
    chartRow.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px";

    if (hasLB) {
      var lbCard = document.createElement("div");
      lbCard.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px";
      var lbTitle = document.createElement("div");
      lbTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:4px;padding-bottom:7px;border-bottom:1px solid var(--border)";
      lbTitle.textContent = "Leave behinds by product";
      var lbSub = document.createElement("div");
      lbSub.style.cssText = "font-size:9px;color:var(--muted);margin-bottom:10px";
      lbSub.textContent = "What samples are going out to keep";
      var lbWrap = document.createElement("div");
      lbWrap.style.cssText = "position:relative;height:200px";
      var lbCan = document.createElement("canvas");
      lbCan.id = "smpLBChart";
      lbWrap.appendChild(lbCan);
      lbCard.appendChild(lbTitle);
      lbCard.appendChild(lbSub);
      lbCard.appendChild(lbWrap);
      chartRow.appendChild(lbCard);
    }

    if (hasLoans) {
      var lnCard = document.createElement("div");
      lnCard.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px";
      var lnTitle = document.createElement("div");
      lnTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:4px;padding-bottom:7px;border-bottom:1px solid var(--border)";
      lnTitle.textContent = "Loan samples — out vs returned";
      var lnSub = document.createElement("div");
      lnSub.style.cssText = "font-size:9px;color:var(--muted);margin-bottom:10px";
      lnSub.textContent = "Blue = sent out, Green = returned/order placed";
      var lnWrap = document.createElement("div");
      lnWrap.style.cssText = "position:relative;height:200px";
      var lnCan = document.createElement("canvas");
      lnCan.id = "smpLoanChart";
      lnWrap.appendChild(lnCan);
      lnCard.appendChild(lnTitle);
      lnCard.appendChild(lnSub);
      lnCard.appendChild(lnWrap);
      chartRow.appendChild(lnCard);
    }

    sv.appendChild(chartRow);

    setTimeout(function(){
      if (hasLB) {
        var lbLabels = Object.keys(leaveBehindData);
        var lbVals = lbLabels.map(function(k){ return leaveBehindData[k]; });
        mkPieChart("smpLBChart", lbLabels, lbVals);
      }
      if (hasLoans) {
        var lnLabels = Object.keys(loanData);
        var lnOut = lnLabels.map(function(k){ return loanData[k]; });
        var lnBack = lnLabels.map(function(k){ return loanReturned[k]||0; });
        var ctx = document.getElementById("smpLoanChart");
        if (chartInstances["smpLoanChart"]) { chartInstances["smpLoanChart"].destroy(); delete chartInstances["smpLoanChart"]; }
        if (ctx) chartInstances["smpLoanChart"] = new Chart(ctx.getContext("2d"), {
          type: "bar",
          data: {
            labels: lnLabels,
            datasets: [
              {label:"Sent out", data:lnOut, backgroundColor:"#305CDE", borderRadius:4},
              {label:"Returned / order", data:lnBack, backgroundColor:"#2ecc71", borderRadius:4}
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position:"bottom", labels:{ font:{size:10}, boxWidth:10 } } },
            scales: {
              y: { ticks: { stepSize:1 }, beginAtZero:true }
            }
          }
        });
      }
    }, 100);
  }

  if(!samples.length){var em=document.createElement("div");em.className="empty-state";em.innerHTML="<div>&#128230;</div><div class='es-title'>No samples logged yet</div><div class='es-sub'>Log samples sent to clients and reps — track loans and leave-behinds</div>";sv.appendChild(em);}
  else{
    var statusColors={"Sent - Awaiting Return":"background:var(--abg);color:var(--atxt)","Sent - No Response":"background:var(--rbg);color:var(--rtxt)","Returned":"background:var(--gbg);color:var(--gtxt)","Order Placed":"background:#d0f0d0;color:#1a5c1a","Not Interested":"background:var(--grbg);color:var(--grtxt)","Left with client":"background:var(--lbg);color:var(--ltxt)"};
    sortedSamples.forEach(function(s){
    var si=samples.indexOf(s);
      var card=document.createElement("div");card.className="smp-card";
      var left=document.createElement("div");left.style.flex="1";
      var nm=document.createElement("div");nm.style.cssText="font-weight:700;font-size:12px;margin-bottom:3px";nm.textContent=s.clientName;
      var prod=document.createElement("div");prod.style.cssText="font-size:11px;color:var(--text);margin-bottom:3px";prod.textContent=s.product+(s.detail?" \u2014 "+s.detail:"")+" ["+(s.sampleType||"Loan")+"]";
      var repInfo=s.repName?("From: "+s.repName+(s.repMfr?" ("+s.repMfr+")":"")):"";var meta=document.createElement("div");meta.style.cssText="font-size:10px;color:var(--muted)";meta.textContent=(repInfo?repInfo+" | ":"")+"Date: "+s.dateSent;
      left.appendChild(nm);left.appendChild(prod);left.appendChild(meta);
      var right=document.createElement("div");right.style.cssText="display:flex;align-items:center;gap:7px;flex-shrink:0;flex-wrap:wrap";
      var pill=document.createElement("span");pill.style.cssText="font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;"+(statusColors[s.status]||"background:var(--lbg);color:var(--ltxt)");pill.textContent=s.status;
      var sel=document.createElement("select");sel.style.cssText="padding:4px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;background:#fff;cursor:pointer;outline:none";
      var sOpts=s.sampleType==="Leave Behind"?["Left with client","Order Placed","Not Interested"]:["Sent - Awaiting Return","Sent - No Response","Returned","Order Placed","Not Interested"];
      sOpts.forEach(function(st){var opt=document.createElement("option");opt.value=st;opt.textContent=st;if(s.status===st)opt.selected=true;sel.appendChild(opt);});
      sel.addEventListener("change",(function(i){return function(e){samples[i].status=e.target.value;saveSamples();renderSamplesView();toast("Sample updated");};})(si));
      var delBtn=document.createElement("button");delBtn.style.cssText="padding:4px 7px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;color:var(--muted);cursor:pointer";delBtn.textContent="Delete";
      delBtn.addEventListener("click",(function(i){return function(){if(confirm("Delete this sample?")){samples.splice(i,1);saveSamples();renderSamplesView();toast("Deleted");}};})(si));
      if(s.repId&&s.status!=="Returned"&&s.status!=="Order Placed"&&s.status!=="Not Interested"){
        var rcvBtn=document.createElement("button");
        rcvBtn.style.cssText="padding:4px 9px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:var(--rs);font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700";
        rcvBtn.textContent="\u2713 Received";
        rcvBtn.addEventListener("click",(function(i){return function(){markSampleReceived(i);};})(si));
        right.appendChild(rcvBtn);
      }
      right.appendChild(pill);right.appendChild(sel);right.appendChild(delBtn);card.appendChild(left);card.appendChild(right);sv.appendChild(card);
    });
  }
  var bk=document.createElement("button");bk.className="bkl";bk.textContent="\u2190 Back to dashboard";bk.addEventListener("click",showDash);sv.appendChild(bk);
}

function showSampleForm(){
  var overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box=document.createElement("div");box.style.cssText="background:var(--surface);border-radius:var(--r);width:100%;max-width:480px;border-top:3px solid var(--navy)";
  var bh=document.createElement("div");bh.style.cssText="background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht=document.createElement("h2");bht.style.cssText="font-size:13px;font-weight:700;color:#fff";bht.textContent="Log sample sent";
  var cx=document.createElement("button");cx.style.cssText="background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1";cx.textContent="\u00d7";cx.addEventListener("click",function(){document.body.removeChild(overlay);});
  bh.appendChild(bht);bh.appendChild(cx);box.appendChild(bh);
  var bd=document.createElement("div");bd.style.cssText="padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkF3(lbl,inp3){var w=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;w.appendChild(l);w.appendChild(inp3);return w;}

  // Sample type toggle
  var typeWrap=document.createElement("div");
  var typeLbl=document.createElement("label");typeLbl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px";typeLbl.textContent="Sample type";
  var toggle=document.createElement("div");toggle.className="type-toggle";
  var loanBtn=document.createElement("button");loanBtn.className="on";loanBtn.textContent="Loan (want it back)";loanBtn.type="button";
  var leaveBtn=document.createElement("button");leaveBtn.textContent="Leave behind (keep)";leaveBtn.type="button";
  var currentType="loan";
  var statusSel=document.createElement("select");statusSel.id="smp_status";statusSel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  function updateSmpStatus(){
    statusSel.innerHTML="";
    var opts=currentType==="loan"?["Sent - Awaiting Return","Sent - No Response","Returned","Order Placed","Not Interested"]:["Left with client","Order Placed","Not Interested"];
    opts.forEach(function(s2){var opt=document.createElement("option");opt.textContent=s2;statusSel.appendChild(opt);});
  }
  loanBtn.addEventListener("click",function(){currentType="loan";loanBtn.classList.add("on");leaveBtn.classList.remove("on");updateSmpStatus();});
  leaveBtn.addEventListener("click",function(){currentType="leave";leaveBtn.classList.add("on");loanBtn.classList.remove("on");updateSmpStatus();});
  toggle.appendChild(loanBtn);toggle.appendChild(leaveBtn);typeWrap.appendChild(typeLbl);typeWrap.appendChild(toggle);updateSmpStatus();bd.appendChild(typeWrap);

  var clientSel=document.createElement("select");clientSel.id="smp_client";clientSel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var defOpt=document.createElement("option");defOpt.value="";defOpt.textContent="-- Select client or rep --";clientSel.appendChild(defOpt);
  clients.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(c){var opt=document.createElement("option");opt.value=c.name;opt.textContent=c.name+" ("+c.binder+")";clientSel.appendChild(opt);});
  reps.forEach(function(r){var opt=document.createElement("option");opt.value=r.name;opt.textContent=r.name+" [Rep - "+r.manufacturer+"]";clientSel.appendChild(opt);});

  var prodSel=document.createElement("select");prodSel.id="smp_prod";prodSel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var dp=document.createElement("option");dp.value="";dp.textContent="-- Select product --";prodSel.appendChild(dp);
  PRODUCTS.forEach(function(p){var opt=document.createElement("option");opt.value=p;opt.textContent=p;prodSel.appendChild(opt);});

  var row=document.createElement("div");row.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var dw=document.createElement("div");var dl=document.createElement("label");dl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";dl.textContent="Date sent";var di=document.createElement("input");di.type="date";di.id="smp_date";di.value=new Date().toISOString().split("T")[0];di.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";dw.appendChild(dl);dw.appendChild(di);
  var sw=document.createElement("div");var sl=document.createElement("label");sl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";sl.textContent="Status";sw.appendChild(sl);sw.appendChild(statusSel);
  row.appendChild(dw);row.appendChild(sw);

  bd.appendChild(mkF3("Client or rep *",clientSel));
  bd.appendChild(mkF3("Product / sample",prodSel));
  var detInp=document.createElement("input");detInp.id="smp_detail";detInp.placeholder="e.g. Karndean Korlok Grey Oak 1.5m x 1m";detInp.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkF3("Detail (colour, range, size etc)",detInp));
  bd.appendChild(row);
  var notesInp=document.createElement("input");notesInp.id="smp_notes";notesInp.placeholder="Any follow-up notes...";notesInp.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkF3("Notes",notesInp));
  box.appendChild(bd);
  var foot=document.createElement("div");foot.style.cssText="padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB=document.createElement("button");cancelB.style.cssText="padding:6px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";cancelB.textContent="Cancel";cancelB.addEventListener("click",function(){document.body.removeChild(overlay);});
  var saveB=document.createElement("button");saveB.style.cssText="padding:6px 14px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";saveB.textContent="Save sample";
  saveB.addEventListener("click",function(){
    var client=document.getElementById("smp_client").value;
    if(!client){toast("Please select a client or rep");return;}
    samples.push({id:"SMP-"+Date.now(),clientName:client,sampleType:currentType==="leave"?"Leave Behind":"Loan",product:document.getElementById("smp_prod").value||"Other",detail:document.getElementById("smp_detail").value.trim(),dateSent:fd(document.getElementById("smp_date").value),status:document.getElementById("smp_status").value,notes:document.getElementById("smp_notes").value.trim()});
    saveSamples();document.body.removeChild(overlay);renderSamplesView();toast("Sample logged \u2713");
  });
  foot.appendChild(cancelB);foot.appendChild(saveB);box.appendChild(foot);overlay.appendChild(box);document.body.appendChild(overlay);
}

// ── BIRTHDAYS ─────────────────────────────────────────────────────
function daysUntilBday(ds){if(!ds)return 999;var p=ds.split("-");if(p.length<2)return 999;var t=new Date();var bd=new Date(t.getFullYear(),parseInt(p[1])-1,parseInt(p[2]||1));if(bd<t)bd.setFullYear(t.getFullYear()+1);return Math.ceil((bd-t)/86400000);}
function fmtBday(ds){if(!ds)return"";var months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];var p=ds.split("-");if(p.length>=2)return(p[2]?p[2]+" ":"")+months[parseInt(p[1])-1]+(p[0]&&p[0]!=="0000"?" "+p[0]:"");return ds;}
function renderBirthdaysView(){
  var sv=document.getElementById("birthdaysView");sv.innerHTML="";
  var hdr=document.createElement("div");hdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title=document.createElement("div");title.className="page-title";title.textContent="Key Contact Birthdays";
  var addBtn=document.createElement("button");addBtn.style.cssText="padding:7px 16px;background:var(--red);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";addBtn.textContent="+ Add birthday";addBtn.addEventListener("click",showBdayForm);
  hdr.appendChild(title);hdr.appendChild(addBtn);sv.appendChild(hdr);
  var upcoming=birthdays.filter(function(b){var d=daysUntilBday(b.date);return d>=0&&d<=14;}).sort(function(a,b){return daysUntilBday(a.date)-daysUntilBday(b.date);});
  if(upcoming.length){
    var upCard=document.createElement("div");upCard.style.cssText="background:#fff8e0;border:2px solid #f0c060;border-radius:var(--r);padding:13px 15px;margin-bottom:14px";
    var ut=document.createElement("div");ut.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--atxt);margin-bottom:9px";ut.textContent="Coming up in the next 14 days";upCard.appendChild(ut);
    upcoming.forEach(function(b){
      var row=document.createElement("div");row.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:5px 0;border-bottom:1px solid #f0e0a0";
      var left=document.createElement("div");var nm=document.createElement("div");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent=b.name;var co=document.createElement("div");co.style.cssText="font-size:10px;color:var(--atxt)";co.textContent=(b.company||"")+(b.type?" ["+b.type+"]":"");left.appendChild(nm);left.appendChild(co);
      var d=daysUntilBday(b.date);var badge=document.createElement("span");badge.style.cssText="font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;"+(d===0?"background:var(--red);color:#fff":"background:var(--abg);color:var(--atxt)");badge.textContent=d===0?"TODAY!":d+"d";
      row.appendChild(left);row.appendChild(badge);upCard.appendChild(row);
    });sv.appendChild(upCard);
  }
  if(!birthdays.length){var em=document.createElement("div");em.className="empty-state";em.innerHTML="<div>&#127874;</div><div class='es-title'>No birthdays added yet</div><div class='es-sub'>Add key contact birthdays - never miss a chance to make someone feel valued</div>";sv.appendChild(em);}
  else{
    birthdays.slice().sort(function(a,b){return daysUntilBday(a.date)-daysUntilBday(b.date);}).forEach(function(b){
      var card=document.createElement("div");card.className="bday-card";
      var av=document.createElement("div");av.style.cssText="width:36px;height:36px;border-radius:50%;background:var(--navy);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:#fff;flex-shrink:0";av.textContent=ini(b.name);
      var info=document.createElement("div");info.style.flex="1";
      var nm=document.createElement("div");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent=b.name;
      var meta=document.createElement("div");meta.style.cssText="font-size:10px;color:var(--muted)";meta.textContent=(b.company||"")+(b.type?" ["+b.type+"]":"")+" \u00b7 "+fmtBday(b.date);
      info.appendChild(nm);info.appendChild(meta);
      var d=daysUntilBday(b.date);var badge=document.createElement("span");badge.style.cssText="font-size:9px;padding:2px 7px;border-radius:20px;"+(d===0?"background:var(--red);color:#fff":d<=7?"background:var(--rbg);color:var(--rtxt)":d<=30?"background:var(--abg);color:var(--atxt)":"background:var(--lbg);color:var(--ltxt)");badge.textContent=d===0?"TODAY!":d<=365?d+"d":"\u2014";
      var delBtn=document.createElement("button");delBtn.style.cssText="padding:4px 8px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;color:var(--muted);cursor:pointer";delBtn.textContent="Delete";
      delBtn.addEventListener("click",(function(bid){return function(e2){e2.stopPropagation();if(confirm("Delete this birthday?")){birthdays=birthdays.filter(function(x){return x.id!==bid;});diaryEvents=diaryEvents.filter(function(x){return x.bdId!==bid;});saveBirthdays();saveDiary();renderBirthdaysView();toast("Deleted \u2713");}};})(b.id));
      var editBtn=document.createElement("button");editBtn.style.cssText="padding:4px 8px;background:none;border:1px solid var(--navy);border-radius:var(--rs);font-size:10px;color:var(--navy);cursor:pointer;margin-right:4px";editBtn.textContent="\u270E Edit";
      editBtn.addEventListener("click",(function(bid){return function(e2){e2.stopPropagation();showBdayEdit(bid);};})(b.id));
      card.style.cursor="pointer";
      card.appendChild(av);card.appendChild(info);card.appendChild(badge);card.appendChild(editBtn);card.appendChild(delBtn);sv.appendChild(card);
    });
  }
  var bk=document.createElement("button");bk.className="bkl";bk.textContent="\u2190 Back to dashboard";bk.addEventListener("click",showDash);sv.appendChild(bk);
}
function showBdayEdit(bid) {
  var b = birthdays.find(function(x){ return x.id===bid; });
  if (!b) return;
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:400px;border-top:3px solid #e8a020";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "Edit birthday";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd2 = document.createElement("div"); bd2.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  function mkFbe(lbl, inp2) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp2); return w; }

  var nameInp2 = document.createElement("input"); nameInp2.id="be_name"; nameInp2.value=b.name; nameInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var compInp2 = document.createElement("input"); compInp2.id="be_company"; compInp2.value=b.company||""; compInp2.placeholder="Company / relation"; compInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var dateInp4 = document.createElement("input"); dateInp4.type="date"; dateInp4.id="be_date"; dateInp4.value=b.date||""; dateInp4.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";

  bd2.appendChild(mkFbe("Name *", nameInp2));
  bd2.appendChild(mkFbe("Company / relation", compInp2));
  bd2.appendChild(mkFbe("Birthday", dateInp4));
  box.appendChild(bd2);

  var foot2 = document.createElement("div"); foot2.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB2 = document.createElement("button"); cancelB2.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB2.textContent = "Cancel";
  cancelB2.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB2 = document.createElement("button"); saveB2.style.cssText = "padding:7px 16px;background:#e8a020;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB2.textContent = "Save changes";
  saveB2.addEventListener("click", function(){
    var newName = document.getElementById("be_name").value.trim();
    if (!newName) { toast("Name is required"); return; }
    b.name = newName;
    b.company = document.getElementById("be_company").value.trim();
    b.date = document.getElementById("be_date").value;
    // Update linked diary event
    var linked = diaryEvents.find(function(e){ return e.bdId===bid; });
    if (linked) {
      linked.title = "\uD83C\uDF82 Birthday: " + newName;
      linked.withName = b.linkedType!=="other" ? newName : "";
      if (b.date) {
        var dp2 = b.date.split("-");
        linked.month = parseInt(dp2[1])-1;
        linked.day = parseInt(dp2[2]);
      }
      saveDiary();
    }
    saveBirthdays();
    document.body.removeChild(overlay);
    renderBirthdaysView();
    toast("Birthday updated \u2713");
  });
  foot2.appendChild(cancelB2); foot2.appendChild(saveB2);
  box.appendChild(foot2); overlay.appendChild(box); document.body.appendChild(overlay);
}


function showBdayForm() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;border-top:3px solid #e8a020";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "Add birthday";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  var currentKind = "birthday";

  // Type toggle
  var typeLbl = document.createElement("label"); typeLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px"; typeLbl.textContent = "Who is this for?";
  var toggle = document.createElement("div"); toggle.style.cssText = "display:flex;border:2px solid var(--border);border-radius:var(--rs);overflow:hidden;margin-bottom:2px";
  var btnClient = document.createElement("button"); btnClient.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;background:var(--navy);color:#fff"; btnClient.textContent = "Client";
  var btnRep = document.createElement("button"); btnRep.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;background:var(--surface);color:var(--muted);border-left:1px solid var(--border)"; btnRep.textContent = "Rep/ASM";
  var btnOther = document.createElement("button"); btnOther.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;background:var(--surface);color:var(--muted);border-left:1px solid var(--border)"; btnOther.textContent = "Other";
  toggle.appendChild(btnClient); toggle.appendChild(btnRep); toggle.appendChild(btnOther);

  var currentType = "client";
  var nameInp = document.createElement("input"); nameInp.id = "bd_name"; nameInp.placeholder = "Full name"; nameInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;display:none";
  var nameSel = document.createElement("select"); nameSel.id = "bd_sel"; nameSel.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";

  function setType(t) {
    currentType = t;
    btnClient.style.background = t==="client"?"var(--navy)":"var(--surface)"; btnClient.style.color = t==="client"?"#fff":"var(--muted)";
    btnRep.style.background = t==="rep"?"var(--navy)":"var(--surface)"; btnRep.style.color = t==="rep"?"#fff":"var(--muted)";
    btnOther.style.background = t==="other"?"var(--navy)":"var(--surface)"; btnOther.style.color = t==="other"?"#fff":"var(--muted)";
    nameSel.innerHTML = "";
    if (t === "other") {
      nameSel.style.display = "none"; nameInp.style.display = "block";
    } else {
      nameSel.style.display = "block"; nameInp.style.display = "none";
      var def = document.createElement("option"); def.value = ""; def.textContent = "-- Select "+t+" --"; nameSel.appendChild(def);
      var list = t === "client" ? clients : reps;
      list.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(x){
        var opt = document.createElement("option"); opt.value = x.name;
        opt.textContent = x.name + (t==="client"?" ("+x.binder+")":"");
        nameSel.appendChild(opt);
      });
    }
  }
  btnClient.addEventListener("click", function(){ setType("client"); });
  btnRep.addEventListener("click", function(){ setType("rep"); });
  btnOther.addEventListener("click", function(){ setType("other"); });

  var nameWrap = document.createElement("div");
  var nameLbl2 = document.createElement("label"); nameLbl2.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; nameLbl2.textContent = "Name *";
  nameWrap.appendChild(nameLbl2); nameWrap.appendChild(nameSel); nameWrap.appendChild(nameInp);

  var compInp = document.createElement("input"); compInp.id = "bd_company"; compInp.placeholder = "Company / relation (optional)"; compInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";

  // Birthday date
  var dateWrap = document.createElement("div");
  var dateLbl = document.createElement("label"); dateLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; dateLbl.textContent = "Birthday";
  var dateInp3 = document.createElement("input"); dateInp3.type = "date"; dateInp3.id = "bd_date"; dateInp3.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var dateNote = document.createElement("div"); dateNote.style.cssText = "font-size:10px;color:var(--muted);margin-top:3px"; dateNote.textContent = "Year is optional — just pick any year if you only know day and month";
  dateWrap.appendChild(dateLbl); dateWrap.appendChild(dateInp3); dateWrap.appendChild(dateNote);

  var typeLblWrap = document.createElement("div"); typeLblWrap.appendChild(typeLbl); typeLblWrap.appendChild(toggle);
  bd.appendChild(typeLblWrap);

  // Work / Personal category toggle
  var bdCatLbl = document.createElement("label"); bdCatLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px;margin-top:4px"; bdCatLbl.textContent = "Category";
  var bdCatWrap = document.createElement("div"); bdCatWrap.style.cssText = "display:flex;gap:6px";
  var bdCatWork = document.createElement("button"); bdCatWork.type = "button"; bdCatWork.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:1px solid var(--navy);background:var(--navy);color:#fff;font-size:11px;font-weight:700;cursor:pointer"; bdCatWork.textContent = "💼 Work";
  var bdCatPersonal = document.createElement("button"); bdCatPersonal.type = "button"; bdCatPersonal.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;font-weight:700;cursor:pointer"; bdCatPersonal.textContent = "🏠 Personal";
  bdCatWrap.appendChild(bdCatWork); bdCatWrap.appendChild(bdCatPersonal);
  var bdCatWrapOuter = document.createElement("div"); bdCatWrapOuter.appendChild(bdCatLbl); bdCatWrapOuter.appendChild(bdCatWrap);
  bd.appendChild(bdCatWrapOuter);
  var currentBdCategory = "work";
  function setBdCategory(cat) {
    currentBdCategory = cat;
    bdCatWork.style.background = cat==="work"?"var(--navy)":"var(--surface)"; bdCatWork.style.color = cat==="work"?"#fff":"var(--muted)"; bdCatWork.style.borderColor = cat==="work"?"var(--navy)":"var(--border)";
    bdCatPersonal.style.background = cat==="personal"?"#e91e8c":"var(--surface)"; bdCatPersonal.style.color = cat==="personal"?"#fff":"var(--muted)"; bdCatPersonal.style.borderColor = cat==="personal"?"#e91e8c":"var(--border)";
  }
  bdCatWork.addEventListener("click", function(){ setBdCategory("work"); });
  bdCatPersonal.addEventListener("click", function(){ setBdCategory("personal"); });

  bd.appendChild(nameWrap);
  bd.appendChild(compInp);
  bd.appendChild(dateWrap);
  box.appendChild(bd);

  // Init with client dropdown
  setType("client");

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:#e8a020;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Save birthday";
  saveB.addEventListener("click", function(){
    var name = currentType === "other" ? document.getElementById("bd_name").value.trim() : document.getElementById("bd_sel").value;
    if (!name) { toast("Please enter a name"); return; }
    var date = document.getElementById("bd_date").value;
    if (!date) { toast(currentKind==="anniversary"?"Please select an anniversary date":"Please select a birthday date"); return; }
    var annivLabel = currentKind==="anniversary" ? (document.getElementById("anniv_label").value.trim() || "Anniversary") : "";
    var bdId = "BD-"+Date.now();
    birthdays.push({
      id: bdId,
      name: name,
      company: document.getElementById("bd_company").value.trim(),
      type: currentType==="client"?"Client":currentType==="rep"?"Rep/ASM":"Other",
      date: date,
      linkedType: currentType,
      category: currentBdCategory,
      eventKind: currentKind,
      annivLabel: annivLabel
    });
    saveBirthdays();
    // Auto-create diary event for this year's occurrence
    if (date) {
      var dp = date.split("-");
      if (dp.length === 3) {
        var bdMonth = parseInt(dp[1])-1;
        var bdDay = parseInt(dp[2]);
        var today2 = new Date();
        var bdYear = today2.getFullYear();
        // If date already passed this year use next year
        var bdThisYear = new Date(bdYear, bdMonth, bdDay);
        if (bdThisYear < today2) bdYear++;
        // Check if diary event already exists for this occurrence
        var existing = diaryEvents.find(function(e){ return e.bdId===bdId; });
        if (!existing) {
          var titleText = currentKind==="anniversary" ? "\uD83D\uDC8D "+annivLabel+": "+name : "\uD83C\uDF82 Birthday: "+name;
          diaryEvents.push({
            id: "EV-BD-"+Date.now(),
            bdId: bdId,
            year: bdYear,
            month: bdMonth,
            day: bdDay,
            hour: null,
            minute: null,
            allDay: true,
            type: currentKind==="anniversary" ? "Anniversary" : "Birthday",
            title: titleText,
            notes: (document.getElementById("bd_company").value.trim()||""),
            withName: currentType!=="other"?name:"",
            withType: currentType!=="other"?currentType:"none",
            completed: false,
            isBirthday: true,
            category: currentBdCategory
          });
          saveDiary();
        }
      }
    }
    document.body.removeChild(overlay);
    renderBirthdaysView();
    renderDash();
    toast("Birthday saved \u2713 Added to diary");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
}

function showAnnivForm() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;border-top:3px solid #c0392b";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "\uD83D\uDC8D Add anniversary";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  function mkFd2(lbl, inp) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp); return w; }

  var nameInp2 = document.createElement("input"); nameInp2.id="anniv_name"; nameInp2.placeholder="e.g. Tom & Sarah, or a client name"; nameInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd2("Name(s) *", nameInp2));

  var labelInp2 = document.createElement("input"); labelInp2.id="anniv_type_label"; labelInp2.placeholder="e.g. Wedding Anniversary, Work Anniversary"; labelInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd2("Anniversary type *", labelInp2));

  var dateInp2 = document.createElement("input"); dateInp2.id="anniv_date"; dateInp2.type="date"; dateInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd2("Date *", dateInp2));

  // Work / Personal category toggle
  var catLbl2 = document.createElement("label"); catLbl2.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px;margin-top:4px"; catLbl2.textContent = "Category";
  var catWrap2 = document.createElement("div"); catWrap2.style.cssText = "display:flex;gap:6px";
  var catWork2 = document.createElement("button"); catWork2.type = "button"; catWork2.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;font-weight:700;cursor:pointer"; catWork2.textContent = "\uD83D\uDCBC Work";
  var catPersonal2 = document.createElement("button"); catPersonal2.type = "button"; catPersonal2.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:2px solid #9333ea;background:#9333ea;color:#fff;font-size:11px;font-weight:700;cursor:pointer"; catPersonal2.textContent = "\uD83C\uDFE0 Personal";
  catWrap2.appendChild(catWork2); catWrap2.appendChild(catPersonal2);
  var catWrapOuter2 = document.createElement("div"); catWrapOuter2.appendChild(catLbl2); catWrapOuter2.appendChild(catWrap2);
  bd.appendChild(catWrapOuter2);
  var currentAnnivCategory = "personal";
  function setAnnivCategory(cat) {
    currentAnnivCategory = cat;
    catWork2.style.background = cat==="work"?"var(--navy)":"var(--surface)"; catWork2.style.color = cat==="work"?"#fff":"var(--muted)"; catWork2.style.borderColor = cat==="work"?"var(--navy)":"var(--border)";
    catPersonal2.style.background = cat==="personal"?"#9333ea":"var(--surface)"; catPersonal2.style.color = cat==="personal"?"#fff":"var(--muted)"; catPersonal2.style.borderColor = cat==="personal"?"#9333ea":"var(--border)";
  }
  catWork2.addEventListener("click", function(){ setAnnivCategory("work"); });
  catPersonal2.addEventListener("click", function(){ setAnnivCategory("personal"); });

  box.appendChild(bd);

  var foot2 = document.createElement("div"); foot2.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px";
  var cancelB2 = document.createElement("button"); cancelB2.style.cssText = "padding:7px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB2.textContent = "Cancel";
  cancelB2.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB2 = document.createElement("button"); saveB2.style.cssText = "padding:7px 16px;background:#c0392b;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB2.textContent = "Save anniversary";
  saveB2.addEventListener("click", function(){
    var name = nameInp2.value.trim();
    var label = labelInp2.value.trim();
    var date = dateInp2.value;
    if (!name) { toast("Please enter a name"); return; }
    if (!label) { toast("Please enter the anniversary type"); return; }
    if (!date) { toast("Please select a date"); return; }

    var bdId = "ANNIV-"+Date.now();
    birthdays.push({
      id: bdId,
      name: name,
      company: "",
      type: "Other",
      date: date,
      linkedType: "other",
      category: currentAnnivCategory,
      eventKind: "anniversary",
      annivLabel: label
    });
    saveBirthdays();

    var dp = date.split("-");
    if (dp.length === 3) {
      var annMonth = parseInt(dp[1])-1;
      var annDay = parseInt(dp[2]);
      var today3 = new Date();
      var annYear = today3.getFullYear();
      var annThisYear = new Date(annYear, annMonth, annDay);
      if (annThisYear < today3) annYear++;
      diaryEvents.push({
        id: "EV-ANNIV-"+Date.now(),
        bdId: bdId,
        year: annYear,
        month: annMonth,
        day: annDay,
        hour: null,
        minute: null,
        allDay: true,
        type: "Anniversary",
        title: "\uD83D\uDC8D "+label+": "+name,
        notes: "",
        withName: "",
        withType: "none",
        completed: false,
        isBirthday: true,
        category: currentAnnivCategory
      });
      saveDiary();
    }

    document.body.removeChild(overlay);
    renderDiaryView();
    renderDash();
    toast("Anniversary saved \u2713 Added to diary");
  });
  foot2.appendChild(cancelB2); foot2.appendChild(saveB2);
  box.appendChild(foot2); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ nameInp2.focus(); }, 100);
}


function renderComplaintsView() {
  var sv = document.getElementById("complaintsView");
  sv.innerHTML = "";
  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Complaint Tracker";
  var addBtn = document.createElement("button");
  addBtn.style.cssText = "padding:7px 16px;background:var(--red);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  addBtn.textContent = "+ Log complaint";
  addBtn.addEventListener("click", function(){ showComplaintForm(); });
  var cmpPrintBtn = document.createElement("button"); cmpPrintBtn.className = "no-print";
  cmpPrintBtn.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  cmpPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print all";
  cmpPrintBtn.addEventListener("click", function(){ window.print(); });
  hdr.appendChild(title); hdr.appendChild(cmpPrintBtn); hdr.appendChild(addBtn); sv.appendChild(hdr);

  var sr = document.createElement("div"); sr.className = "stat-row cols4";
  [{l:"Total logged",v:complaints.length,c:"kv-blue"},
   {l:"Open",v:complaints.filter(function(c){return c.status==="Open";}).length,c:"kv-red"},
   {l:"In progress",v:complaints.filter(function(c){return c.status==="In Progress";}).length,c:"kv-amber"},
   {l:"Resolved",v:complaints.filter(function(c){return c.status==="Resolved";}).length,c:"kv-green"}
  ].forEach(function(k){
    var card=document.createElement("div");card.className="stat-card";
    var lbl=document.createElement("div");lbl.className="sc-lbl";lbl.textContent=k.l;
    var val=document.createElement("div");val.className="sc-val "+k.c;val.textContent=k.v;
    card.appendChild(lbl);card.appendChild(val);sr.appendChild(card);
  });
  sv.appendChild(sr);

  if (!complaints.length) {
    var em = document.createElement("div"); em.className = "empty-state";
    em.innerHTML = "<div>&#128221;</div><div class='es-title'>No complaints logged yet</div><div class='es-sub'>Log complaints for clients and reps and track them through to resolution</div>";
    sv.appendChild(em);
  } else {
    var scols = {"Open":"background:var(--rbg);color:var(--rtxt)","In Progress":"background:var(--abg);color:var(--atxt)","Resolved":"background:var(--gbg);color:var(--gtxt)","Closed":"background:var(--grbg);color:var(--grtxt)"};
    var order = {Open:0,"In Progress":1,Resolved:2,Closed:3};
    complaints.slice().sort(function(a,b){return(order[a.status]||0)-(order[b.status]||0);}).forEach(function(c){
      var card = document.createElement("div"); card.className = "cmp-card";
      var top = document.createElement("div"); top.style.cssText = "display:flex;align-items:flex-start;justify-content:space-between;gap:9px;margin-bottom:7px;flex-wrap:wrap";
      var left = document.createElement("div");
      var nm = document.createElement("div"); nm.style.cssText = "font-weight:700;font-size:12px;margin-bottom:2px"; nm.textContent = c.clientName+(c.type?" ["+c.type+"]":"");
      var subj = document.createElement("div"); subj.style.cssText = "font-size:12px;color:var(--text);margin-bottom:2px"; subj.textContent = c.subject;
      var meta = document.createElement("div"); meta.style.cssText = "font-size:10px;color:var(--muted)"; meta.textContent = "Logged: "+c.dateLogged+(c.product?" | "+c.product:"");
      left.appendChild(nm); left.appendChild(subj); left.appendChild(meta);
      var right = document.createElement("div"); right.style.cssText = "display:flex;align-items:center;gap:6px;flex-shrink:0";
      var pill = document.createElement("span"); pill.style.cssText = "font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;"+(scols[c.status]||"background:var(--lbg);color:var(--ltxt)"); pill.textContent = c.status;
      var sel = document.createElement("select"); sel.style.cssText = "padding:4px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;background:#fff;cursor:pointer;outline:none";
      ["Open","In Progress","Resolved","Closed"].forEach(function(s2){var opt=document.createElement("option");opt.value=s2;opt.textContent=s2;if(c.status===s2)opt.selected=true;sel.appendChild(opt);});
      sel.addEventListener("change",(function(cid){return function(e){var comp=complaints.find(function(x){return x.id===cid;});if(comp){comp.status=e.target.value;saveComplaints();renderComplaintsView();toast("Updated");}};})(c.id));
      var delBtn=document.createElement("button");delBtn.style.cssText="padding:4px 7px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;color:var(--muted);cursor:pointer";delBtn.textContent="Delete";
      delBtn.addEventListener("click",(function(cid){return function(){if(confirm("Delete?")){complaints=complaints.filter(function(x){return x.id!==cid;});saveComplaints();renderComplaintsView();toast("Deleted");}};})(c.id));
      var cmpCardPrintBtn=document.createElement("button");cmpCardPrintBtn.className="no-print";cmpCardPrintBtn.style.cssText="padding:4px 7px;background:none;border:2px solid var(--navy);border-radius:var(--rs);font-size:10px;color:var(--navy);cursor:pointer";cmpCardPrintBtn.textContent="\uD83D\uDDA8\uFE0F Print";
      cmpCardPrintBtn.addEventListener("click",(function(cardEl){return function(){ isolatePrintEl(cardEl, null); };})(card));
      right.appendChild(pill);right.appendChild(sel);right.appendChild(cmpCardPrintBtn);right.appendChild(delBtn);
      top.appendChild(left);top.appendChild(right);card.appendChild(top);
      if(c.description){var desc=document.createElement("div");desc.style.cssText="background:var(--alt);border-radius:var(--rs);padding:7px 9px;font-size:11px;color:var(--text);line-height:1.5;margin-bottom:7px";desc.textContent=c.description;card.appendChild(desc);}
      if(c.resolution){var res=document.createElement("div");res.style.cssText="background:var(--gbg);border-radius:var(--rs);padding:7px 9px;font-size:11px;color:var(--gtxt);line-height:1.5";res.innerHTML="<strong>Resolution:</strong> "+c.resolution;card.appendChild(res);}
      sv.appendChild(card);
    });
  }
  var bk = document.createElement("button"); bk.className = "bkl"; bk.textContent = "← Back to dashboard"; bk.addEventListener("click", showDash); sv.appendChild(bk);
}


function showComplaintForm(){
  var overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box=document.createElement("div");box.style.cssText="background:var(--surface);border-radius:var(--r);width:100%;max-width:500px;max-height:90vh;overflow-y:auto;border-top:3px solid var(--red)";
  var bh=document.createElement("div");bh.style.cssText="background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";var bht=document.createElement("h2");bht.style.cssText="font-size:13px;font-weight:700;color:#fff";bht.textContent="Log complaint";
  var cx=document.createElement("button");cx.style.cssText="background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1";cx.textContent="\u00d7";cx.addEventListener("click",function(){document.body.removeChild(overlay);});bh.appendChild(bht);bh.appendChild(cx);box.appendChild(bh);
  var bd=document.createElement("div");bd.style.cssText="padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkFc(lbl,inp5){var w=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;w.appendChild(l);w.appendChild(inp5);return w;}
  function mkIc(fid,ph){var i=document.createElement("input");i.id=fid;i.placeholder=ph||"";i.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";return i;}
  function mkTac(fid,ph){var t=document.createElement("textarea");t.id=fid;t.placeholder=ph||"";t.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:65px";return t;}
  var csel=document.createElement("select");csel.id="cmp_client";csel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var dop=document.createElement("option");dop.value="";dop.textContent="-- Select client or rep --";csel.appendChild(dop);
  clients.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(c){var opt=document.createElement("option");opt.value=c.name;opt.textContent=c.name+" (Client)";csel.appendChild(opt);});
  reps.forEach(function(r){var opt=document.createElement("option");opt.value=r.name;opt.textContent=r.name+" [Rep - "+r.manufacturer+"]";csel.appendChild(opt);});
  var tsel=document.createElement("select");tsel.id="cmp_type";tsel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  ["Client","Rep/ASM"].forEach(function(t){var o=document.createElement("option");o.textContent=t;tsel.appendChild(o);});
  var ssel=document.createElement("select");ssel.id="cmp_status";ssel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  ["Open","In Progress","Resolved","Closed"].forEach(function(s2){var o=document.createElement("option");o.textContent=s2;ssel.appendChild(o);});
  var row=document.createElement("div");row.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var tw=document.createElement("div");var tl=document.createElement("label");tl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";tl.textContent="Type";tw.appendChild(tl);tw.appendChild(tsel);
  var dw=document.createElement("div");var dl=document.createElement("label");dl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";dl.textContent="Date logged";var di=document.createElement("input");di.type="date";di.id="cmp_date";di.value=new Date().toISOString().split("T")[0];di.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";dw.appendChild(dl);dw.appendChild(di);
  row.appendChild(tw);row.appendChild(dw);
  bd.appendChild(mkFc("Client or rep *",csel));bd.appendChild(mkFc("Subject / complaint title *",mkIc("cmp_subject","e.g. Wrong product delivered, Damaged goods")));bd.appendChild(row);bd.appendChild(mkFc("Product involved",mkIc("cmp_product","e.g. LVT, Screed")));bd.appendChild(mkFc("Description",mkTac("cmp_desc","Full details of the complaint...")));bd.appendChild(mkFc("Resolution (if known)",mkTac("cmp_res","How was it resolved?")));bd.appendChild(mkFc("Status",ssel));box.appendChild(bd);
  var foot=document.createElement("div");foot.style.cssText="padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB=document.createElement("button");cancelB.style.cssText="padding:6px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";cancelB.textContent="Cancel";cancelB.addEventListener("click",function(){document.body.removeChild(overlay);});
  var saveB=document.createElement("button");saveB.style.cssText="padding:6px 14px;background:var(--red);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";saveB.textContent="Save complaint";
  saveB.addEventListener("click",function(){
    var client=document.getElementById("cmp_client").value;var subject=document.getElementById("cmp_subject").value.trim();
    if(!client||!subject){toast("Please fill in client and subject");return;}
    complaints.push({id:"CMP-"+Date.now(),clientName:client,type:document.getElementById("cmp_type").value,subject:subject,dateLogged:fd(document.getElementById("cmp_date").value),product:document.getElementById("cmp_product").value.trim(),description:document.getElementById("cmp_desc").value.trim(),resolution:document.getElementById("cmp_res").value.trim(),status:document.getElementById("cmp_status").value});
    saveComplaints();document.body.removeChild(overlay);renderComplaintsView();toast("Complaint logged \u2713");
  });
  foot.appendChild(cancelB);foot.appendChild(saveB);box.appendChild(foot);overlay.appendChild(box);document.body.appendChild(overlay);
}

// ── QUICK SALE LOG ────────────────────────────────────────────────
function showSaleForm(clientId, clientName) {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;border-top:3px solid var(--gtxt)";
  var bh = document.createElement("div");
  bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid var(--gtxt)";
  var bht = document.createElement("h2");
  bht.style.cssText = "font-size:13px;font-weight:700;color:#fff";
  bht.textContent = "£ Log a sale — " + clientName;
  var cx = document.createElement("button");
  cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1";
  cx.textContent = "×";
  cx.addEventListener("click", function() { document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div");
  bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  var note = document.createElement("div");
  note.style.cssText = "font-size:11px;color:var(--muted);background:var(--gbg);border-radius:var(--rs);padding:8px 10px;border:2px solid #b8e0a0";
  note.textContent = "Add each product as a separate sale line. Goods taken there and then go straight to Collected in your sales figures.";
  bd.appendChild(note);

  function mkF2(lbl, inp2) {
    var w = document.createElement("div");
    var l = document.createElement("label");
    l.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";
    l.textContent = lbl; w.appendChild(l); w.appendChild(inp2); return w;
  }

  // Product dropdown
  var prodSel = document.createElement("select");
  prodSel.id = "sl_prod";
  prodSel.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var dp = document.createElement("option"); dp.value = ""; dp.textContent = "-- Select product --"; prodSel.appendChild(dp);
  PRODUCTS.forEach(function(p) { var opt = document.createElement("option"); opt.value = p; opt.textContent = p; prodSel.appendChild(opt); });
  bd.appendChild(mkF2("Product *", prodSel));

  // Other product specify field (hidden unless Other selected)
  var otherWrap = document.createElement("div");
  otherWrap.id = "sl_other_wrap";
  otherWrap.style.display = "none";
  var otherInp = document.createElement("input");
  otherInp.id = "sl_other"; otherInp.placeholder = "e.g. Stair rods, Door bars...";
  otherInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  otherWrap.appendChild((function(){var w=mkF2("Specify product",otherInp);return w;})());
  bd.appendChild(otherWrap);

  // Generic sub-category dropdown: one per product key in PRODUCT_SUBCATS, hidden until that product is selected.
  // sl_subcat_wraps maps product name -> {wrap, sel, rangeWrap, rangeSel} so the change listener and save logic can look any of them up.
  var sl_subcat_wraps = {};
  Object.keys(PRODUCT_SUBCATS).forEach(function(prodName) {
    var list = PRODUCT_SUBCATS[prodName];
    var w = document.createElement("div");
    w.style.display = "none";
    var sel = document.createElement("select");
    sel.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
    var blank = document.createElement("option"); blank.value = ""; blank.textContent = "-- Select " + prodName + " sub-category --"; sel.appendChild(blank);
    list.forEach(function(item) { var opt = document.createElement("option"); opt.value = item.name; opt.textContent = item.note ? (item.name + " (" + item.note + ")") : item.name; sel.appendChild(opt); });
    w.appendChild(mkF2(prodName + " category *", sel));
    bd.appendChild(w);

    // Range dropdown (second level) - hidden unless the chosen sub-category item has ranges
    var rangeWrap = document.createElement("div");
    rangeWrap.style.display = "none";
    var rangeSel = document.createElement("select");
    rangeSel.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
    rangeWrap.appendChild(mkF2("Range *", rangeSel));
    bd.appendChild(rangeWrap);

    sel.addEventListener("change", function() {
      var chosen = list.filter(function(item) { return item.name === sel.value; })[0];
      var ranges = (chosen && chosen.ranges) ? chosen.ranges : [];
      if (ranges.length) {
        rangeSel.innerHTML = "";
        var rblank = document.createElement("option"); rblank.value = ""; rblank.textContent = "-- Select range --"; rangeSel.appendChild(rblank);
        ranges.forEach(function(rg) { var ro = document.createElement("option"); ro.value = rg; ro.textContent = rg; rangeSel.appendChild(ro); });
        rangeWrap.style.display = "";
      } else {
        rangeWrap.style.display = "none";
        rangeSel.innerHTML = "";
      }
    });

    sl_subcat_wraps[prodName] = { wrap: w, sel: sel, rangeWrap: rangeWrap, rangeSel: rangeSel };
  });


  prodSel.addEventListener("change", function(){
    var selectedProd = this.value;
    otherWrap.style.display = selectedProd === "Other" ? "" : "none";
    Object.keys(sl_subcat_wraps).forEach(function(prodName) {
      var entry = sl_subcat_wraps[prodName];
      var show = (selectedProd === prodName);
      entry.wrap.style.display = show ? "" : "none";
      if (!show) { entry.rangeWrap.style.display = "none"; entry.sel.value = ""; entry.rangeSel.innerHTML = ""; }
    });
  });

  // Sale amount
  var valInp = document.createElement("input");
  valInp.id = "sl_val"; valInp.type = "number"; valInp.placeholder = "e.g. 245.00";
  valInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkF2("Sale amount (£) *", valInp));

  // Qty / detail
  var detInp = document.createElement("input");
  detInp.id = "sl_det"; detInp.placeholder = "e.g. 25m², 5 boxes, 3 tubs";
  detInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkF2("Qty / detail (optional)", detInp));

  // Date
  var dateInp = document.createElement("input");
  dateInp.type = "date"; dateInp.id = "sl_date";
  dateInp.value = new Date().toISOString().split("T")[0];
  dateInp.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkF2("Date", dateInp));

  // Add another line checkbox
  var anotherWrap = document.createElement("div");
  anotherWrap.style.cssText = "display:flex;align-items:center;gap:6px";
  var anotherChk = document.createElement("input"); anotherChk.type = "checkbox"; anotherChk.id = "sl_another";
  var anotherLbl = document.createElement("label"); anotherLbl.setAttribute("for","sl_another");
  anotherLbl.style.fontSize = "11px"; anotherLbl.textContent = "Save and add another product";
  anotherWrap.appendChild(anotherChk); anotherWrap.appendChild(anotherLbl);
  bd.appendChild(anotherWrap);

  box.appendChild(bd);

  var foot = document.createElement("div");
  foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button");
  cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";
  cancelB.textContent = "Done"; cancelB.addEventListener("click", function() { document.body.removeChild(overlay); renderDet(); });
  var saveB = document.createElement("button");
  saveB.style.cssText = "padding:7px 16px;background:var(--gtxt);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  saveB.textContent = "Save sale";

  saveB.addEventListener("click", function() {
    var prod = document.getElementById("sl_prod").value;
    var otherTxt = (document.getElementById("sl_other")||{}).value || "";
    if (prod === "Other" && otherTxt.trim()) prod = "Other: " + otherTxt.trim();
    if (sl_subcat_wraps[prod]) {
      var subVal = sl_subcat_wraps[prod].sel.value;
      if (!subVal) { toast("Please select a " + prod + " category"); return; }
      var rangeWrapEntry = sl_subcat_wraps[prod];
      if (rangeWrapEntry.rangeWrap.style.display !== "none") {
        var rangeVal = rangeWrapEntry.rangeSel.value;
        if (!rangeVal) { toast("Please select a range"); return; }
        prod = prod + ": " + subVal + " - " + rangeVal;
      } else {
        prod = prod + ": " + subVal;
      }
    }
    var val = document.getElementById("sl_val").value;
    var det = document.getElementById("sl_det").value.trim();
    var date = document.getElementById("sl_date").value;
    var another = document.getElementById("sl_another").checked;

    if (!prod || !val) { toast("Please select a product and enter an amount"); return; }

    var c = null;
    for (var i = 0; i < clients.length; i++) { if (clients[i].id === clientId) { c = clients[i]; break; } }
    if (!c) return;
    if (!c.log) c.log = [];

    var saleNote = prod + (det ? " — " + det : "") + " — £" + parseFloat(val).toLocaleString("en-GB");
    c.log.unshift({
      date: fd(date),
      type: "Sale",
      note: saleNote,
      quote: {
        ref: "SALE-" + Date.now(),
        value: val,
        products: prod + (det ? " (" + det + ")" : ""),
        category: prod,
        status: "Collected",
        paidDate: fd(date),
        collectedDate: fd(date)
      }
    });
    c.lastContact = fd(date);
    c.interactionType = "Sale";
    saveC();
    toast("£ Sale logged ✓");

    if (another) {
      // Clear fields for next product
      document.getElementById("sl_prod").value = "";
      document.getElementById("sl_val").value = "";
      document.getElementById("sl_det").value = "";
      document.getElementById("sl_another").checked = false;
      var otherEl=document.getElementById("sl_other");if(otherEl)otherEl.value="";
      var otherWrapEl=document.getElementById("sl_other_wrap");if(otherWrapEl)otherWrapEl.style.display="none";
      Object.keys(sl_subcat_wraps).forEach(function(prodName) {
        sl_subcat_wraps[prodName].sel.value = "";
        sl_subcat_wraps[prodName].wrap.style.display = "none";
        sl_subcat_wraps[prodName].rangeWrap.style.display = "none";
        sl_subcat_wraps[prodName].rangeSel.innerHTML = "";
      });
    } else {
      document.body.removeChild(overlay);
      renderDet();
    }
  });

  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function() { prodSel.focus(); }, 100);
}


// ── MARK SAMPLE RECEIVED ──────────────────────────────────────────
function markSampleReceived(idx) {
  var s = samples[idx];
  if (!s) return;
  s.status = "Returned";
  s.dateReceived = fd(new Date().toISOString().split("T")[0]);

  // Notify linked client
  if (s.linkedClientId) {
    var c = clients.find(function(x){ return x.id === s.linkedClientId; });
    if (c) {
      // Set follow-up to today
      var today = fd(new Date().toISOString().split("T")[0]);
      c.followup = today;
      c.notes = (c.notes ? c.notes + " | " : "") + 
        "Sample arrived: " + s.product + (s.detail ? " - " + s.detail : "") + 
        (s.repName ? " (from " + s.repName + ")" : "") + ". Contact client.";
      if (!c.log) c.log = [];
      c.log.unshift({
        date: today,
        type: "Note",
        note: "SAMPLE ARRIVED: " + s.product + (s.detail ? " - " + s.detail : "") + 
              (s.repName ? " from " + s.repName + " (" + (s.repMfr||"") + ")" : "") + 
              ". Follow up with client."
      });
      saveC();
      toast("Sample marked received ✓ Follow-up set on " + c.name);
    }
  } else {
    toast("Sample marked as received ✓");
  }
  saveSamples();
  renderSamplesView();
}


// ── DIARY ────────────────────────────────────────────────────────
var DIARY_STORE = "sftc_diary_v1";

// UK Bank Holidays (England & Wales)
var UK_BANK_HOLIDAYS = {
  "2026-01-01":"New Year's Day","2026-04-03":"Good Friday","2026-04-06":"Easter Monday",
  "2026-05-04":"Early May Bank Holiday","2026-05-25":"Spring Bank Holiday",
  "2026-08-31":"Summer Bank Holiday","2026-12-25":"Christmas Day","2026-12-28":"Boxing Day (substitute)",
  "2027-01-01":"New Year's Day","2027-03-26":"Good Friday","2027-03-29":"Easter Monday",
  "2027-05-03":"Early May Bank Holiday","2027-05-31":"Spring Bank Holiday",
  "2027-08-30":"Summer Bank Holiday","2027-12-27":"Christmas Day (substitute)","2027-12-28":"Boxing Day (substitute)",
  "2028-01-03":"New Year's Day (substitute)","2028-04-14":"Good Friday","2028-04-17":"Easter Monday",
  "2028-05-01":"Early May Bank Holiday","2028-05-29":"Spring Bank Holiday",
  "2028-08-28":"Summer Bank Holiday","2028-12-25":"Christmas Day","2028-12-26":"Boxing Day",
  "2029-01-01":"New Year's Day","2029-03-30":"Good Friday","2029-04-02":"Easter Monday",
  "2029-05-07":"Early May Bank Holiday","2029-05-28":"Spring Bank Holiday",
  "2029-08-27":"Summer Bank Holiday","2029-12-25":"Christmas Day","2029-12-26":"Boxing Day",
  "2030-01-01":"New Year's Day","2030-04-19":"Good Friday","2030-04-22":"Easter Monday",
  "2030-05-06":"Early May Bank Holiday","2030-05-27":"Spring Bank Holiday",
  "2030-08-26":"Summer Bank Holiday","2030-12-25":"Christmas Day","2030-12-26":"Boxing Day"
};

function isBankHoliday(y,m,d) {
  var key = y+"-"+String(m+1).padStart(2,"0")+"-"+String(d).padStart(2,"0");
  return UK_BANK_HOLIDAYS[key]||null;
}
// UK Observances (Saints' days, Valentine's, Mother's & Father's Day) - shown as labels, not day-off holidays
var UK_OBSERVANCES = {
  "2026-02-14":"Valentine's Day","2026-03-01":"St David's Day","2026-03-15":"Mother's Day",
  "2026-03-17":"St Patrick's Day","2026-03-29":"Clocks Forward (BST starts)","2026-04-23":"St George's Day",
  "2026-06-21":"Father's Day","2026-10-25":"Clocks Back (BST ends)","2026-11-08":"Remembrance Sunday",
  "2026-11-11":"Remembrance Day","2026-11-30":"St Andrew's Day",
  "2027-02-14":"Valentine's Day","2027-03-01":"St David's Day","2027-03-07":"Mother's Day",
  "2027-03-17":"St Patrick's Day","2027-03-28":"Clocks Forward (BST starts)","2027-04-23":"St George's Day",
  "2027-06-20":"Father's Day","2027-10-31":"Clocks Back (BST ends)","2027-11-11":"Remembrance Day",
  "2027-11-14":"Remembrance Sunday","2027-11-30":"St Andrew's Day",
  "2028-02-14":"Valentine's Day","2028-03-01":"St David's Day","2028-03-17":"St Patrick's Day",
  "2028-03-26":"Mother's Day & Clocks Forward (BST starts)","2028-04-23":"St George's Day",
  "2028-06-18":"Father's Day","2028-10-29":"Clocks Back (BST ends)","2028-11-11":"Remembrance Day",
  "2028-11-12":"Remembrance Sunday","2028-11-30":"St Andrew's Day",
  "2029-02-14":"Valentine's Day","2029-03-01":"St David's Day","2029-03-11":"Mother's Day",
  "2029-03-17":"St Patrick's Day","2029-03-25":"Clocks Forward (BST starts)","2029-04-23":"St George's Day",
  "2029-06-17":"Father's Day","2029-10-28":"Clocks Back (BST ends)","2029-11-11":"Remembrance Day (Remembrance Sunday)",
  "2029-11-30":"St Andrew's Day",
  "2030-02-14":"Valentine's Day","2030-03-01":"St David's Day","2030-03-17":"St Patrick's Day",
  "2030-03-31":"Mother's Day & Clocks Forward (BST starts)","2030-04-23":"St George's Day",
  "2030-06-16":"Father's Day","2030-10-27":"Clocks Back (BST ends)","2030-11-10":"Remembrance Sunday",
  "2030-11-11":"Remembrance Day","2030-11-30":"St Andrew's Day"
};
function getObservance(y,m,d) {
  var key = y+"-"+String(m+1).padStart(2,"0")+"-"+String(d).padStart(2,"0");
  return UK_OBSERVANCES[key]||null;
}
// ISO 8601 week number (Mon-start weeks, week 1 = week containing first Thursday of the year)
function isoWeekNumber(y,m,d) {
  var date = new Date(Date.UTC(y, m, d));
  var dayNum = date.getUTCDay() || 7; // Mon=1..Sun=7
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  var yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
}
var diaryEvents = [];
var diaryYear = new Date().getFullYear();
var diaryMonth = new Date().getMonth(); // 0-11

function loadDiary() {
  try { var r = localStorage.getItem(DIARY_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
// saveDiary handled by Supabase version above

function showDiary() {
  activeId = null; renderList(); showView("diary"); renderDiaryView();
}

function eventsForDay(y, m, d) {
  var stored = diaryEvents.filter(function(e){
    return e.year===y && e.month===m && e.day===d && !e.completed && !e.isBirthday;
  });
  // Live-calculated birthdays/anniversaries: always show on their date, every year, until removed
  var liveBdays = birthdays.filter(function(b){
    if (!b.date) return false;
    if (b.lastDoneYear === y) return false;
    var dp = b.date.split("-");
    if (dp.length !== 3) return false;
    var bMonth = parseInt(dp[1]) - 1;
    var bDay = parseInt(dp[2]);
    return bMonth === m && bDay === d;
  }).map(function(b){
    var isAnniv = b.eventKind === "anniversary";
    var titleText = isAnniv ? "\uD83D\uDC8D " + (b.annivLabel||"Anniversary") + ": " + (b.name||"") : "\uD83C\uDF82 Birthday: " + (b.name||"");
    return {
      id: "LIVE-"+b.id+"-"+y,
      bdId: b.id,
      year: y, month: m, day: d,
      hour: null, minute: null, allDay: true,
      type: isAnniv ? "Anniversary" : "Birthday",
      title: titleText,
      notes: b.company || "",
      withName: b.linkedType !== "other" ? (b.name||"") : "",
      withType: b.linkedType !== "other" ? (b.linkedType||"none") : "none",
      completed: false,
      isBirthday: true,
      category: b.category || "personal"
    };
  });
  return stored.concat(liveBdays).sort(function(a,b){ return (a.allDay?0:a.hour*60+a.minute) - (b.allDay?0:b.hour*60+b.minute); });
}

function renderDiaryView() {
  var dv = document.getElementById("diaryView");
  dv.innerHTML = "";
  var today = new Date();
  var monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  var dayNames = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

  // Header
  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Diary";
  var nav = document.createElement("div"); nav.style.cssText = "display:flex;align-items:center;gap:8px";

  // Prev year
  var pyr = document.createElement("button"); pyr.style.cssText = "padding:4px 8px;border:2px solid var(--border);border-radius:var(--rs);background:var(--surface);cursor:pointer;font-size:11px"; pyr.textContent = "◄◄";
  pyr.addEventListener("click", function(){ diaryYear--; renderDiaryView(); });

  // Prev month
  var pm = document.createElement("button"); pm.style.cssText = "padding:4px 10px;border:2px solid var(--border);border-radius:var(--rs);background:var(--surface);cursor:pointer;font-size:13px;font-weight:700"; pm.textContent = "◄";
  pm.addEventListener("click", function(){ diaryMonth--; if(diaryMonth<0){diaryMonth=11;diaryYear--;} renderDiaryView(); });

  var monthLbl = document.createElement("div"); monthLbl.style.cssText = "font-size:14px;font-weight:700;min-width:160px;text-align:center"; monthLbl.textContent = monthNames[diaryMonth] + " " + diaryYear;

  // Next month
  var nm2 = document.createElement("button"); nm2.style.cssText = "padding:4px 10px;border:2px solid var(--border);border-radius:var(--rs);background:var(--surface);cursor:pointer;font-size:13px;font-weight:700"; nm2.textContent = "►";
  nm2.addEventListener("click", function(){ diaryMonth++; if(diaryMonth>11){diaryMonth=0;diaryYear++;} renderDiaryView(); });

  // Next year
  var nyr = document.createElement("button"); nyr.style.cssText = "padding:4px 8px;border:2px solid var(--border);border-radius:var(--rs);background:var(--surface);cursor:pointer;font-size:11px"; nyr.textContent = "►►";
  nyr.addEventListener("click", function(){ diaryYear++; renderDiaryView(); });

  // Today button
  var todayBtn = document.createElement("button"); todayBtn.style.cssText = "padding:4px 12px;border:1px solid var(--navy);border-radius:var(--rs);background:var(--navy);color:#fff;cursor:pointer;font-size:11px;font-weight:700;margin-left:6px"; todayBtn.textContent = "Today";
  todayBtn.addEventListener("click", function(){ diaryYear=new Date().getFullYear(); diaryMonth=new Date().getMonth(); renderDiaryView(); });

  nav.appendChild(pyr); nav.appendChild(pm); nav.appendChild(monthLbl); nav.appendChild(nm2); nav.appendChild(nyr); nav.appendChild(todayBtn);
  hdr.appendChild(title); hdr.appendChild(nav); dv.appendChild(hdr);

  // Calendar grid
  var cal = document.createElement("div"); cal.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);overflow:hidden;margin-bottom:20px";

  // Day headers
  var dayHdr = document.createElement("div"); dayHdr.style.cssText = "display:grid;grid-template-columns:repeat(7,1fr);background:var(--navy)";
  dayNames.forEach(function(d,di){
    var isWknd = di>=5;
    var dh = document.createElement("div"); dh.style.cssText = "padding:8px 4px;text-align:center;font-size:10px;font-weight:700;letter-spacing:.5px;color:#fff;"+(isWknd?"opacity:0.6;":""); dh.textContent = d; dayHdr.appendChild(dh);
  });
  cal.appendChild(dayHdr);

  // Days grid
  var grid = document.createElement("div"); grid.style.cssText = "display:grid;grid-template-columns:repeat(7,1fr)";

  var firstDay = new Date(diaryYear, diaryMonth, 1).getDay(); // 0=Sun
  // Convert to Mon=0
  var startOffset = (firstDay === 0) ? 6 : firstDay - 1;
  var daysInMonth = new Date(diaryYear, diaryMonth + 1, 0).getDate();
  var daysInPrevMonth = new Date(diaryYear, diaryMonth, 0).getDate();

  // Prev month padding
  for (var i = 0; i < startOffset; i++) {
    var pd = document.createElement("div"); pd.className="diary-cell"; pd.style.cssText = "border:2px solid var(--border);padding:4px;background:#f0f0f2;color:#ccc;font-size:11px;overflow:hidden;"; pd.textContent = daysInPrevMonth - startOffset + 1 + i; grid.appendChild(pd);
  }

  // Current month days
  for (var day = 1; day <= daysInMonth; day++) {
    var isToday = day === today.getDate() && diaryMonth === today.getMonth() && diaryYear === today.getFullYear();
    var cellDow = new Date(diaryYear, diaryMonth, day).getDay(); // 0=Sun,6=Sat
    var isWeekend = cellDow === 0 || cellDow === 6;
    var bh = isBankHoliday(diaryYear, diaryMonth, day);
    var cellBg = isToday ? "#eef1f8" : bh ? "#fff8f0" : isWeekend ? "#f4f4f6" : "#fff";
    var cell = document.createElement("div");
    cell.className = "diary-cell";
    cell.style.cssText = "border:2px solid var(--border);padding:4px;cursor:pointer;position:relative;overflow:hidden;background:"+cellBg+";";
    cell.addEventListener("click", (function(d){ return function(){ openDiaryDay(d); }; })(day));

    var dayNum = document.createElement("div"); dayNum.style.cssText = "font-size:11px;font-weight:700;margin-bottom:3px;width:22px;height:22px;display:flex;align-items:center;justify-content:center;border-radius:50%;" + (isToday ? "background:var(--navy);color:#fff;" : "color:var(--text);");
    dayNum.textContent = day; cell.appendChild(dayNum);
    // Week number (ISO, shown on Mondays only)
    if (cellDow === 1) {
      var wkEl = document.createElement("div");
      wkEl.style.cssText = "position:absolute;top:4px;right:4px;font-size:8px;color:var(--muted);font-weight:700;";
      wkEl.textContent = "Wk "+isoWeekNumber(diaryYear, diaryMonth, day);
      cell.appendChild(wkEl);
    }
    // Bank holiday label
    if (bh) {
      var bhEl = document.createElement("div");
      bhEl.style.cssText = "font-size:8px;color:#854f0b;font-weight:700;margin-bottom:2px;line-height:1.2;background:#fff3e0;padding:1px 3px;border-radius:2px";
      bhEl.textContent = bh;
      cell.appendChild(bhEl);
    }
    // Observance label (saints' days, Valentine's, Mother's/Father's Day)
    var obs = getObservance(diaryYear, diaryMonth, day);
    if (obs) {
      var obsEl = document.createElement("div");
      obsEl.style.cssText = "font-size:8px;color:#6b2d8b;font-weight:700;margin-bottom:2px;line-height:1.2;background:#f0e6f6;padding:1px 3px;border-radius:2px";
      obsEl.textContent = obs;
      cell.appendChild(obsEl);
    }
    // Weekend indicator
    if (isWeekend && !isToday) {
      cell.style.opacity = "0.75";
    }

    var dayEvts = eventsForDay(diaryYear, diaryMonth, day);
    dayEvts.slice(0, 3).forEach(function(e) {
      var evtEl = document.createElement("div");
      var typeColors = {"Meeting":"#305CDE","Site Visit":"#2ecc71","Call":"#f39c12","Rep Visit":"#9b59b6","Delivery":"#e67e22","Family Event":"#e91e8c","Birthday":"#e8a020","Anniversary":"#c0392b","Holiday":"#16a085","Other":"#7f8c8d"};
      var col = e.category==="personal" ? "#9333ea" : (typeColors[e.type] || "#305CDE");
      evtEl.style.cssText = "font-size:9px;padding:2px 4px;border-radius:3px;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff;background:"+col+";cursor:pointer";
      var timeStr = e.allDay ? "" : String(e.hour).padStart(2,"0")+":"+String(e.minute).padStart(2,"0")+" ";
      evtEl.textContent = timeStr + e.title; cell.appendChild(evtEl);
      evtEl.addEventListener("click", (function(eid){ return function(ev2){ ev2.stopPropagation(); editDiaryEvent(eid); }; })(e.id));
    });
    if (dayEvts.length > 3) {
      var more = document.createElement("div"); more.style.cssText = "font-size:9px;color:var(--muted)"; more.textContent = "+" + (dayEvts.length-3) + " more"; cell.appendChild(more);
    }
    grid.appendChild(cell);
  }

  // Next month padding
  var totalCells = startOffset + daysInMonth;
  var remaining = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
  for (var j = 1; j <= remaining; j++) {
    var nd = document.createElement("div"); nd.className="diary-cell"; nd.style.cssText = "border:2px solid var(--border);padding:4px;background:#f0f0f2;color:#ccc;font-size:11px;overflow:hidden;"; nd.textContent = j; grid.appendChild(nd);
  }
  cal.appendChild(grid); dv.appendChild(cal);

  var diaryPrintBtn = document.createElement("button"); diaryPrintBtn.className = "no-print";
  diaryPrintBtn.style.cssText = "padding:4px 12px;border:1px solid var(--navy);border-radius:var(--rs);background:var(--navy);color:#fff;cursor:pointer;font-size:11px;font-weight:700;margin-left:6px";
  diaryPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print month";
  diaryPrintBtn.addEventListener("click", function(){ isolatePrintEl(cal, null); });
  nav.appendChild(diaryPrintBtn);

  // Upcoming events list (next 14 days only, keeps this section manageable)
  // Build day-by-day so live-calculated birthdays/anniversaries are correctly included
  // even when their next occurrence falls in a different year than any stored copy.
  var upcoming = [];
  var todayForUpcoming = new Date();
  for (var dOffset = -1; dOffset <= 14; dOffset++) {
    var checkDate = new Date(todayForUpcoming.getFullYear(), todayForUpcoming.getMonth(), todayForUpcoming.getDate() + dOffset);
    var dayItems = eventsForDay(checkDate.getFullYear(), checkDate.getMonth(), checkDate.getDate());
    dayItems.forEach(function(e){ if (!e.completed) upcoming.push(e); });
  }
  upcoming.sort(function(a,b){
    var da = new Date(a.year,a.month,a.day)*1000000 + (a.allDay?0:a.hour*60+a.minute);
    var db = new Date(b.year,b.month,b.day)*1000000 + (b.allDay?0:b.hour*60+b.minute);
    return da-db;
  });

  if (upcoming.length) {
    var upTitle = document.createElement("div"); upTitle.style.cssText = "font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid var(--border)"; upTitle.textContent = "Upcoming events (next 14 days)";
    dv.appendChild(upTitle);
    upcoming.forEach(function(e) {
      var evtDate = new Date(e.year, e.month, e.day);
      var diff = Math.ceil((evtDate - new Date()) / 86400000);
      var diffStr = diff < 0 ? Math.abs(diff)+"d ago" : diff === 0 ? "Today" : diff === 1 ? "Tomorrow" : diff+"d";
      var diffCls = diff < 0 ? "background:var(--rbg);color:var(--rtxt)" : diff <= 1 ? "background:var(--abg);color:var(--atxt)" : "background:var(--lbg);color:var(--ltxt)";
      var typeColors = {"Meeting":"#305CDE","Site Visit":"#2ecc71","Call":"#f39c12","Rep Visit":"#9b59b6","Delivery":"#e67e22","Family Event":"#e91e8c","Birthday":"#e8a020","Anniversary":"#c0392b","Holiday":"#16a085","Other":"#7f8c8d"};
      var col = e.category==="personal" ? "#9333ea" : (typeColors[e.type] || "#305CDE");
      var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:center;gap:10px;padding:9px 12px;background:var(--surface);border:2px solid var(--border);border-radius:var(--rs);margin-bottom:7px;border-left:4px solid "+col+";cursor:pointer";
      row.addEventListener("click", (function(eid){ return function(){ editDiaryEvent(eid); }; })(e.id));
      var dot = document.createElement("div"); dot.style.cssText = "width:10px;height:10px;border-radius:50%;background:"+col+";flex-shrink:0";
      var info = document.createElement("div"); info.style.flex = "1";
      var etitle = document.createElement("div"); etitle.style.cssText = "font-weight:700;font-size:12px"; etitle.textContent = e.title;
      var emeta = document.createElement("div"); emeta.style.cssText = "font-size:10px;color:var(--muted)";
      var timeStr = e.allDay ? "All day" : String(e.hour).padStart(2,"0")+":"+String(e.minute).padStart(2,"0");
      emeta.textContent = e.type + " · " + timeStr + " · " + ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][e.month]+" "+e.day+", "+e.year + (e.withName ? " · With: "+e.withName : "");
      info.appendChild(etitle); info.appendChild(emeta);
      if (e.notes) { var en = document.createElement("div"); en.style.cssText = "font-size:11px;color:var(--muted);margin-top:3px"; en.textContent = e.notes; info.appendChild(en); }
      var badge = document.createElement("span"); badge.style.cssText = "font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;flex-shrink:0;"+diffCls; badge.textContent = diffStr;
      var doneBtn = document.createElement("button"); doneBtn.style.cssText = "padding:4px 10px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:20px;font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700;flex-shrink:0"; doneBtn.textContent = "✓ Done";
      doneBtn.addEventListener("click", (function(eid,isBday,bdId,evYear){ return function(ev3){
        ev3.stopPropagation();
        if(isBday){
          var b=birthdays.find(function(x){return x.id===bdId;});
          if(b){ b.lastDoneYear=evYear; saveBirthdays(); renderDiaryView(); renderDash(); toast("Marked done for this year \u2713"); }
        } else {
          var ev=diaryEvents.find(function(x){return x.id===eid;});
          if(ev){ev.completed=true;saveDiary();renderDiaryView();renderDash();toast("Event marked done ✓");}
        }
      }; })(e.id, e.isBirthday, e.bdId, e.year));
      row.appendChild(dot); row.appendChild(info); row.appendChild(badge); row.appendChild(doneBtn);
      dv.appendChild(row);
    });
  }

  var bk = document.createElement("button"); bk.className = "bkl"; bk.textContent = "← Back to dashboard"; bk.addEventListener("click", showDash); dv.appendChild(bk);
}

function openDiaryDay(day) {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:480px;max-height:90vh;overflow-y:auto;border-top:3px solid var(--navy)";
  var monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = monthNames[diaryMonth]+" "+day+", "+diaryYear;
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "×";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  // Existing events for this day (includes live-generated birthdays/anniversaries)
  var dayEvts = eventsForDay(diaryYear, diaryMonth, day);
  if (dayEvts.length) {
    var existTitle = document.createElement("div"); existTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:4px"; existTitle.textContent = "Events this day";
    bd.appendChild(existTitle);
    dayEvts.forEach(function(e) {
      var er = document.createElement("div"); er.style.cssText = "display:flex;align-items:center;gap:8px;padding:7px 9px;background:var(--alt);border-radius:var(--rs);margin-bottom:4px";
      var typeColors = {"Meeting":"#305CDE","Site Visit":"#2ecc71","Call":"#f39c12","Rep Visit":"#9b59b6","Delivery":"#e67e22","Family Event":"#e91e8c","Birthday":"#e8a020","Anniversary":"#c0392b","Holiday":"#16a085","Other":"#7f8c8d"};
      var dot2 = document.createElement("div"); dot2.style.cssText = "width:8px;height:8px;border-radius:50%;background:"+(e.category==="personal"?"#9333ea":(typeColors[e.type]||"#305CDE"))+";flex-shrink:0";
      var et = document.createElement("div"); et.style.flex="1"; et.style.fontSize="12px"; et.style.fontWeight="700"; et.textContent = (e.allDay?"All day":String(e.hour).padStart(2,"0")+":"+String(e.minute).padStart(2,"0"))+" "+e.title+(e.withName?" with "+e.withName:"");
      var eb2 = document.createElement("button"); eb2.style.cssText = "padding:3px 7px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);font-size:10px;color:var(--navy);cursor:pointer"; eb2.textContent = e.isBirthday ? "Remove" : "Edit";
      eb2.addEventListener("click", (function(eid){ return function(){ document.body.removeChild(overlay); editDiaryEvent(eid); }; })(e.id));
      er.appendChild(dot2); er.appendChild(et); er.appendChild(eb2);
      if (!e.isBirthday) {
        var db2 = document.createElement("button"); db2.style.cssText = "padding:3px 7px;background:var(--rbg);border:1px solid var(--rtxt);border-radius:var(--rs);font-size:10px;color:var(--rtxt);cursor:pointer"; db2.textContent = "Delete";
        db2.addEventListener("click", (function(eid, bdLinkId){ return async function(){
          diaryEvents=diaryEvents.filter(function(x){return x.id!==eid;});
          await sbDelete("diary_events", eid);
          if (bdLinkId) {
            birthdays = birthdays.filter(function(x){ return x.id!==bdLinkId; });
            await sbDelete("birthdays", bdLinkId);
            saveBirthdays();
          }
          saveDiary();
          document.body.removeChild(overlay);
          renderDiaryView();
          toast("Deleted \u2713");
        }; })(e.id, e.bdId));
        er.appendChild(db2);
      }
      bd.appendChild(er);
    });
    var divider = document.createElement("div"); divider.style.cssText = "border-top:1px solid var(--border);margin:4px 0"; bd.appendChild(divider);
  }

  // Add new event form
  var formTitle = document.createElement("div"); formTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px"; formTitle.textContent = "Add new event";
  bd.appendChild(formTitle);

  function mkFd(lbl, inp2) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp2); return w; }

  // Work / Personal toggle
  var catWrap = document.createElement("div"); catWrap.style.cssText = "display:flex;gap:6px;margin-bottom:2px";
  var catWork = document.createElement("button"); catWork.type = "button"; catWork.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:1px solid var(--navy);background:var(--navy);color:#fff;font-size:11px;font-weight:700;cursor:pointer"; catWork.textContent = "💼 Work";
  var catPersonal = document.createElement("button"); catPersonal.type = "button"; catPersonal.style.cssText = "flex:1;padding:7px 10px;border-radius:var(--rs);border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;font-weight:700;cursor:pointer"; catPersonal.textContent = "🏠 Personal";
  catWrap.appendChild(catWork); catWrap.appendChild(catPersonal);
  bd.appendChild(catWrap);
  var currentCategory = "work";

  // All day toggle
  var allDayWrap = document.createElement("label"); allDayWrap.style.cssText = "display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;color:var(--text);cursor:pointer;margin-bottom:2px";
  var allDayChk = document.createElement("input"); allDayChk.type = "checkbox"; allDayChk.id = "ev_allday"; allDayChk.style.cssText = "width:14px;height:14px;cursor:pointer";
  allDayWrap.appendChild(allDayChk); allDayWrap.appendChild(document.createTextNode("All day (no specific time)"));
  bd.appendChild(allDayWrap);

  // Time row
  var timeRow = document.createElement("div"); timeRow.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:9px";

  // Hour dropdown
  var hourSel = document.createElement("select"); hourSel.id = "ev_hour"; hourSel.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  for (var h2 = 6; h2 <= 22; h2++) { var ho = document.createElement("option"); ho.value = h2; ho.textContent = String(h2).padStart(2,"0")+":00"; if(h2===9) ho.selected=true; hourSel.appendChild(ho); }

  // Minute dropdown (15 min intervals)
  var minSel = document.createElement("select"); minSel.id = "ev_min"; minSel.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  [0,15,30,45].forEach(function(m){ var mo=document.createElement("option"); mo.value=m; mo.textContent=":"+String(m).padStart(2,"0"); minSel.appendChild(mo); });

  var hwrap = document.createElement("div"); var hl = document.createElement("label"); hl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; hl.textContent = "Hour"; hwrap.appendChild(hl); hwrap.appendChild(hourSel);
  var mwrap = document.createElement("div"); var ml2 = document.createElement("label"); ml2.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; ml2.textContent = "Mins"; mwrap.appendChild(ml2); mwrap.appendChild(minSel);
  timeRow.appendChild(hwrap); timeRow.appendChild(mwrap);
  bd.appendChild(timeRow);
  allDayChk.addEventListener("change", function(){ timeRow.style.display = this.checked ? "none" : "grid"; });

  // Event type
  var typeSel2 = document.createElement("select"); typeSel2.id = "ev_type"; typeSel2.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  ["Meeting","Site Visit","Call","Rep Visit","Delivery","Family Event","Holiday","Birthday","Anniversary","Other"].forEach(function(t){ var o=document.createElement("option"); o.value=t; o.textContent=t; typeSel2.appendChild(o); });
  bd.appendChild(mkFd("Event type", typeSel2));

  // Birthday note (only shown when type = Birthday) \u2014 redirects to the dedicated birthday form
  var bdayNoteWrap = document.createElement("div"); bdayNoteWrap.style.display = "none"; bdayNoteWrap.style.cssText = "display:none;font-size:11px;color:var(--muted);background:var(--alt);padding:10px;border-radius:var(--rs)";
  bdayNoteWrap.textContent = "Birthdays use their own quick form so they repeat every year automatically. Opening it now\u2026";
  bd.appendChild(bdayNoteWrap);

  var annivNoteWrap = document.createElement("div"); annivNoteWrap.style.display = "none"; annivNoteWrap.style.cssText = "display:none;font-size:11px;color:var(--muted);background:var(--alt);padding:10px;border-radius:var(--rs)";
  annivNoteWrap.textContent = "Anniversaries use their own quick form so they repeat every year automatically. Opening it now\u2026";
  bd.appendChild(annivNoteWrap);

  typeSel2.addEventListener("change", function(){
    if (typeSel2.value === "Birthday") {
      bdayNoteWrap.style.display = "block";
      setTimeout(function(){
        document.body.removeChild(overlay);
        showBdayForm();
      }, 350);
      return;
    } else if (typeSel2.value === "Anniversary") {
      annivNoteWrap.style.display = "block";
      setTimeout(function(){
        document.body.removeChild(overlay);
        showAnnivForm();
      }, 350);
      return;
    } else {
      bdayNoteWrap.style.display = "none";
      annivNoteWrap.style.display = "none";
    }
  });

  // Holiday end date (only shown when type = Holiday)
  var holEndWrap = document.createElement("div"); holEndWrap.style.display = "none";
  var holEndLbl = document.createElement("label"); holEndLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; holEndLbl.textContent = "Last day of holiday";
  var holEndInp = document.createElement("input"); holEndInp.type = "date"; holEndInp.id = "ev_hol_end";
  var startDateStr = diaryYear+"-"+String(diaryMonth+1).padStart(2,"0")+"-"+String(day).padStart(2,"0");
  holEndInp.value = startDateStr; holEndInp.min = startDateStr;
  holEndInp.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  holEndWrap.appendChild(holEndLbl); holEndWrap.appendChild(holEndInp);
  bd.appendChild(holEndWrap);

  typeSel2.addEventListener("change", function(){
    var isHoliday = typeSel2.value === "Holiday";
    holEndWrap.style.display = isHoliday ? "block" : "none";
    if (isHoliday) { setCategory("personal"); }
  });

  // Title
  var titleInp = document.createElement("input"); titleInp.id = "ev_title"; titleInp.placeholder = "What's happening..."; titleInp.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkFd("Event title *", titleInp));

  // Notes
  var notesInp2 = document.createElement("textarea"); notesInp2.id = "ev_notes"; notesInp2.placeholder = "Additional notes..."; notesInp2.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:50px";
  bd.appendChild(mkFd("Notes", notesInp2));

  // Who with - client or rep selector
  var withToggle = document.createElement("div"); withToggle.style.cssText = "background:var(--alt);border-radius:var(--rs);padding:10px";
  var withLbl = document.createElement("div"); withLbl.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:7px"; withLbl.textContent = "Who is it with? (optional)";
  withToggle.appendChild(withLbl);
  var withTypeRow = document.createElement("div"); withTypeRow.style.cssText = "display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap";
  var withNone = document.createElement("button"); withNone.style.cssText = "padding:4px 10px;border-radius:20px;border:1px solid var(--navy);background:var(--navy);color:#fff;font-size:11px;cursor:pointer;font-weight:700"; withNone.textContent = "No one specific";
  var withClient = document.createElement("button"); withClient.style.cssText = "padding:4px 10px;border-radius:20px;border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;cursor:pointer"; withClient.textContent = "Client";
  var withRep = document.createElement("button"); withRep.style.cssText = "padding:4px 10px;border-radius:20px;border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;cursor:pointer"; withRep.textContent = "Rep / ASM";
  var withFamily = document.createElement("button"); withFamily.style.cssText = "padding:4px 10px;border-radius:20px;border:2px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;cursor:pointer"; withFamily.textContent = "Family";
  withTypeRow.appendChild(withNone); withTypeRow.appendChild(withClient); withTypeRow.appendChild(withRep); withTypeRow.appendChild(withFamily);
  withToggle.appendChild(withTypeRow);

  var withSelWrap = document.createElement("div"); withSelWrap.style.display = "none";
  var withSel = document.createElement("select"); withSel.id = "ev_with"; withSel.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  withSelWrap.appendChild(withSel); withToggle.appendChild(withSelWrap);

  var withFamilyWrap = document.createElement("div"); withFamilyWrap.style.display = "none";
  var withFamilyInp = document.createElement("input"); withFamilyInp.type="text"; withFamilyInp.id = "ev_with_family"; withFamilyInp.placeholder = "e.g. Mum, the kids, whole family"; withFamilyInp.style.cssText = "width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  withFamilyWrap.appendChild(withFamilyInp); withToggle.appendChild(withFamilyWrap);
  bd.appendChild(withToggle);

  var currentWithType = "none";
  function setWithType(type) {
    currentWithType = type;
    withNone.style.background = type==="none"?"var(--navy)":"var(--surface)"; withNone.style.color = type==="none"?"#fff":"var(--muted)"; withNone.style.borderColor = type==="none"?"var(--navy)":"var(--border)";
    withClient.style.background = type==="client"?"var(--navy)":"var(--surface)"; withClient.style.color = type==="client"?"#fff":"var(--muted)"; withClient.style.borderColor = type==="client"?"var(--navy)":"var(--border)";
    withRep.style.background = type==="rep"?"var(--navy)":"var(--surface)"; withRep.style.color = type==="rep"?"#fff":"var(--muted)"; withRep.style.borderColor = type==="rep"?"var(--navy)":"var(--border)";
    withFamily.style.background = type==="family"?"var(--navy)":"var(--surface)"; withFamily.style.color = type==="family"?"#fff":"var(--muted)"; withFamily.style.borderColor = type==="family"?"var(--navy)":"var(--border)";
    withSel.innerHTML = "";
    withSelWrap.style.display = "none";
    withFamilyWrap.style.display = "none";
    if (type === "none") { return; }
    if (type === "family") { withFamilyWrap.style.display = "block"; return; }
    withSelWrap.style.display = "block";
    var defOpt = document.createElement("option"); defOpt.value = ""; defOpt.textContent = "-- Select --"; withSel.appendChild(defOpt);
    if (type === "client") {
      clients.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(c){var o=document.createElement("option");o.value=c.name;o.textContent=c.name+" ("+c.binder+")";withSel.appendChild(o);});
    } else {
      reps.slice().sort(function(a,b){return a.name.localeCompare(b.name);}).forEach(function(r){var o=document.createElement("option");o.value=r.name;o.textContent=r.name+" ("+r.manufacturer+")";withSel.appendChild(o);});
    }
  }
  withNone.addEventListener("click", function(){ setWithType("none"); });
  withClient.addEventListener("click", function(){ setWithType("client"); });
  withRep.addEventListener("click", function(){ setWithType("rep"); });
  withFamily.addEventListener("click", function(){ setWithType("family"); });

  function setCategory(cat) {
    currentCategory = cat;
    catWork.style.background = cat==="work"?"var(--navy)":"var(--surface)"; catWork.style.color = cat==="work"?"#fff":"var(--muted)"; catWork.style.borderColor = cat==="work"?"var(--navy)":"var(--border)";
    catPersonal.style.background = cat==="personal"?"#e91e8c":"var(--surface)"; catPersonal.style.color = cat==="personal"?"#fff":"var(--muted)"; catPersonal.style.borderColor = cat==="personal"?"#e91e8c":"var(--border)";
    withClient.style.display = cat==="personal" ? "none" : "inline-block";
    withRep.style.display = cat==="personal" ? "none" : "inline-block";
    if (cat === "personal" && (currentWithType==="client" || currentWithType==="rep")) {
      setWithType("family");
    }
  }
  catWork.addEventListener("click", function(){ setCategory("work"); });
  catPersonal.addEventListener("click", function(){ setCategory("personal"); });

  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Save event";
  saveB.addEventListener("click", function(){
    var evTitle = document.getElementById("ev_title").value.trim();
    if (!evTitle) { toast("Please add an event title"); return; }
    var withName = "";
    if (currentWithType === "family") { withName = document.getElementById("ev_with_family").value.trim(); }
    else if (currentWithType !== "none" && document.getElementById("ev_with").value) { withName = document.getElementById("ev_with").value; }
    var isAllDay = document.getElementById("ev_allday").checked;
    var evType = document.getElementById("ev_type").value;

    if (evType === "Holiday") {
      var endDateVal = document.getElementById("ev_hol_end").value; // "YYYY-MM-DD"
      var endParts = endDateVal.split("-").map(Number);
      var startDateObj = new Date(diaryYear, diaryMonth, day);
      var endDateObj = new Date(endParts[0], endParts[1]-1, endParts[2]);
      if (endDateObj < startDateObj) { toast("Last day can't be before the first day"); return; }
      var dayCount = 0;
      var cursor = new Date(startDateObj);
      while (cursor <= endDateObj) {
        diaryEvents.push({
          id: "EV-"+Date.now()+"-"+dayCount,
          year: cursor.getFullYear(), month: cursor.getMonth(), day: cursor.getDate(),
          hour: null, minute: null, allDay: true,
          type: "Holiday", title: evTitle,
          notes: document.getElementById("ev_notes").value.trim(),
          withName: "", withType: "none", completed: false, category: "personal"
        });
        cursor.setDate(cursor.getDate()+1); dayCount++;
      }
      saveDiary();
      document.body.removeChild(overlay);
      renderDiaryView();
      toast("Holiday added \u2713 " + dayCount + " day" + (dayCount!==1?"s":""));
      return;
    }

    var newEvt={id:"EV-"+Date.now(),year:diaryYear,month:diaryMonth,day:day,
      hour:isAllDay?null:parseInt(document.getElementById("ev_hour").value),
      minute:isAllDay?null:parseInt(document.getElementById("ev_min").value),
      allDay:isAllDay,
      type:evType,
      title:evTitle,
      notes:document.getElementById("ev_notes").value.trim(),
      withName:withName,withType:currentWithType,completed:false,category:currentCategory};
    diaryEvents.push(newEvt);
    saveDiary();
    // Auto-log on linked client
    if(currentWithType==="client"&&withName){
      var lc3=clients.find(function(x){return x.name===withName;});
      if(lc3){
        if(!lc3.log)lc3.log=[];
        var ds3=String(day).padStart(2,"0")+"/"+String(diaryMonth+1).padStart(2,"0")+"/"+diaryYear;
        var ts3=String(parseInt(document.getElementById("ev_hour").value)).padStart(2,"0")+":"+String(parseInt(document.getElementById("ev_min").value)).padStart(2,"0");
        lc3.log.unshift({date:ds3,type:"Diary",note:"DIARY: "+newEvt.type+" scheduled "+ds3+" at "+ts3+(evTitle?" — "+evTitle:"")+(newEvt.notes?" — "+newEvt.notes:""),isDiary:true,diaryId:newEvt.id});
        saveC();
      }
    }
    // Auto-log on linked rep
    if(currentWithType==="rep"&&withName){
      var lr3=reps.find(function(x){return x.name===withName;});
      if(lr3){
        if(!lr3.log)lr3.log=[];
        var ds4=String(day).padStart(2,"0")+"/"+String(diaryMonth+1).padStart(2,"0")+"/"+diaryYear;
        var ts4=String(parseInt(document.getElementById("ev_hour").value)).padStart(2,"0")+":"+String(parseInt(document.getElementById("ev_min").value)).padStart(2,"0");
        lr3.log.unshift({date:ds4,type:"Diary",note:"DIARY: "+newEvt.type+" scheduled "+ds4+" at "+ts4+(evTitle?" — "+evTitle:"")+(newEvt.notes?" — "+newEvt.notes:""),isDiary:true,diaryId:newEvt.id});
        saveReps();
      }
    }
    toast("Event saved ✓"+(withName?" — logged on "+withName:""));
    document.body.removeChild(overlay);
    renderDiaryView();
    renderDash();
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ titleInp.focus(); }, 100);
}


function markDiaryDone(eid) {
  var ev = diaryEvents.find(function(x){ return x.id===eid; });
  if (!ev) return;
  ev.completed = true;
  saveDiary();
  // Log completion on linked client
  if (ev.withType === "client" && ev.withName) {
    var lc4 = clients.find(function(x){ return x.name === ev.withName; });
    if (lc4) {
      if (!lc4.log) lc4.log = [];
      var today4 = fd(new Date().toISOString().split("T")[0]);
      lc4.log.unshift({
        date: today4, type: "Diary",
        note: "DIARY COMPLETED: "+ev.type+(ev.title?" — "+ev.title:"")+(ev.notes?" — "+ev.notes:""),
        isDiary: true, diaryId: eid
      });
      saveC();
    }
  }
  // Log completion on linked rep
  if (ev.withType === "rep" && ev.withName) {
    var lr4 = reps.find(function(x){ return x.name === ev.withName; });
    if (lr4) {
      if (!lr4.log) lr4.log = [];
      var today5 = fd(new Date().toISOString().split("T")[0]);
      lr4.log.unshift({
        date: today5, type: "Diary",
        note: "DIARY COMPLETED: "+ev.type+(ev.title?" — "+ev.title:"")+(ev.notes?" — "+ev.notes:""),
        isDiary: true, diaryId: eid
      });
      saveReps();
    }
  }
  renderDash();
  toast("Done ✓"+(ev.withName?" — logged on "+ev.withName:""));
}

function editDiaryEvent(eid) {
  // Live-generated birthday/anniversary chips have a synthetic id (LIVE-{bdId}-{year}) since
  // they don't exist as real diaryEvents rows. Route these to a simple delete-the-record flow instead.
  if (typeof eid === "string" && eid.indexOf("LIVE-") === 0) {
    var bdRecordId = eid.replace(/^LIVE-/, "").replace(/-\d{4}$/, "");
    var bdRecord = birthdays.find(function(b){ return b.id === bdRecordId; });
    if (!bdRecord) return;
    var isAnnivR = bdRecord.eventKind === "anniversary";
    var label = isAnnivR ? (bdRecord.annivLabel||"Anniversary") + ": " + bdRecord.name : "Birthday: " + bdRecord.name;
    if (confirm("Remove \"" + label + "\" completely? This deletes it from every year, not just this one.")) {
      birthdays = birthdays.filter(function(b){ return b.id !== bdRecordId; });
      saveBirthdays();
      diaryEvents = diaryEvents.filter(function(e){ return e.bdId !== bdRecordId; });
      saveDiary();
      renderDiaryView();
      renderDash();
      toast("Removed \u2713");
    }
    return;
  }
  var ev = diaryEvents.find(function(x){ return x.id===eid; });
  if (!ev) return;
  var monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:440px;border-top:3px solid #e8a020";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy3);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "Edit / Reschedule event";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "×";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);
  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkFe(lbl,inp2){var w=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";l.textContent=lbl;w.appendChild(l);w.appendChild(inp2);return w;}
  // Date
  var dateInp2 = document.createElement("input"); dateInp2.type="date"; dateInp2.id="ed_date";
  var curDate = new Date(ev.year,ev.month,ev.day).toISOString().split("T")[0];
  dateInp2.value = curDate;
  dateInp2.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkFe("Date", dateInp2));
  // Time row
  var timeRow2=document.createElement("div");timeRow2.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:9px";
  var hourSel2=document.createElement("select");hourSel2.id="ed_hour";hourSel2.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  for(var h3=6;h3<=22;h3++){var ho2=document.createElement("option");ho2.value=h3;ho2.textContent=String(h3).padStart(2,"0")+":00";if(h3===ev.hour)ho2.selected=true;hourSel2.appendChild(ho2);}
  var minSel2=document.createElement("select");minSel2.id="ed_min";minSel2.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  [0,15,30,45].forEach(function(m){var mo2=document.createElement("option");mo2.value=m;mo2.textContent=":"+String(m).padStart(2,"0");if(m===ev.minute)mo2.selected=true;minSel2.appendChild(mo2);});
  var hw2=document.createElement("div");var hl2=document.createElement("label");hl2.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";hl2.textContent="Hour";hw2.appendChild(hl2);hw2.appendChild(hourSel2);
  var mw2=document.createElement("div");var ml3=document.createElement("label");ml3.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";ml3.textContent="Mins";mw2.appendChild(ml3);mw2.appendChild(minSel2);
  timeRow2.appendChild(hw2);timeRow2.appendChild(mw2);bd.appendChild(timeRow2);
  // Title
  var titleInp2=document.createElement("input");titleInp2.id="ed_title";titleInp2.value=ev.title;titleInp2.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  bd.appendChild(mkFe("Title", titleInp2));
  // Notes
  var notesInp3=document.createElement("textarea");notesInp3.id="ed_notes";notesInp3.value=ev.notes||"";notesInp3.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:50px";
  bd.appendChild(mkFe("Notes", notesInp3));
  // Info note
  var infoNote=document.createElement("div");infoNote.style.cssText="font-size:11px;color:var(--muted);background:var(--alt);border-radius:var(--rs);padding:8px 10px";infoNote.textContent="If the event didn’t happen, update the date and save to reschedule.";bd.appendChild(infoNote);
  box.appendChild(bd);
  var foot=document.createElement("div");foot.style.cssText="padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:space-between;gap:7px";
  var delB3=document.createElement("button");delB3.style.cssText="padding:7px 12px;background:none;border:1px solid var(--rtxt);border-radius:var(--rs);color:var(--rtxt);font-size:12px;cursor:pointer";delB3.textContent="Delete event";
  delB3.addEventListener("click",async function(){
    if(confirm("Delete this event?")){
      diaryEvents=diaryEvents.filter(function(x){return x.id!==eid;});
      await sbDelete("diary_events", eid);
      if (ev.bdId) {
        birthdays = birthdays.filter(function(x){ return x.id!==ev.bdId; });
        await sbDelete("birthdays", ev.bdId);
        saveBirthdays();
      }
      saveDiary();
      document.body.removeChild(overlay);
      renderDash();
      renderDiaryView&&renderDiaryView();
      toast("Deleted \u2713");
    }
  });
  var rightBtns=document.createElement("div");rightBtns.style.cssText="display:flex;gap:7px";
  var cancelB4=document.createElement("button");cancelB4.style.cssText="padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";cancelB4.textContent="Cancel";cancelB4.addEventListener("click",function(){document.body.removeChild(overlay);});
  var saveB4=document.createElement("button");saveB4.style.cssText="padding:7px 16px;background:#e8a020;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";saveB4.textContent="Save changes";
  saveB4.addEventListener("click",function(){
    var newDate=document.getElementById("ed_date").value;
    if(!newDate){toast("Please select a date");return;}
    var dp=newDate.split("-");
    ev.year=parseInt(dp[0]);ev.month=parseInt(dp[1])-1;ev.day=parseInt(dp[2]);
    ev.hour=parseInt(document.getElementById("ed_hour").value);
    ev.minute=parseInt(document.getElementById("ed_min").value);
    ev.title=document.getElementById("ed_title").value.trim()||ev.title;
    ev.notes=document.getElementById("ed_notes").value.trim();
    saveDiary();document.body.removeChild(overlay);
    renderDash();
    toast("Event updated ✓");
  });
  rightBtns.appendChild(cancelB4);rightBtns.appendChild(saveB4);
  foot.appendChild(delB3);foot.appendChild(rightBtns);box.appendChild(foot);
  overlay.appendChild(box);document.body.appendChild(overlay);
}


// ── QUOTES ────────────────────────────────────────────────────────
function showQuotes() {
  activeId = null; renderList(); showView("quotes"); renderQuotesView();
}

function scrollToDash(section) {
  showDash();
  setTimeout(function(){
    var el = document.getElementById("dash-"+section);
    if (el) el.scrollIntoView({behavior:"smooth", block:"start"});
  }, 100);
}

function renderQuotesView() {
  var qv = document.getElementById("quotesView");
  qv.innerHTML = "";

  // Collect all quotes from all clients
  var allQuotes = [];
  clients.forEach(function(c) {
    (c.log||[]).forEach(function(l, li) {
      if (l.quote) {
        var daysOpen = 0;
        if (l.date) {
          var dp = l.date.split("/");
          if (dp.length===3) {
            var qDate = new Date(dp[2], dp[1]-1, dp[0]);
            daysOpen = Math.round((new Date()-qDate)/86400000);
          }
        }
        var expired = l.quote.expiry ? new Date() > new Date(l.quote.expiry) : false;
        allQuotes.push({
          client: c, logIdx: li, log: l,
          val: parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0,
          daysOpen: daysOpen,
          expired: expired
        });
      }
    });
  });

  // Sort by status priority then value
  var statusOrder = {"Quote":0,"Confirmed":1,"Invoiced":2,"Paid":3,"Collected":4,"Lost":5,"Expired":6};
  allQuotes.sort(function(a,b){
    var so = (statusOrder[a.log.quote.status]||0) - (statusOrder[b.log.quote.status]||0);
    return so !== 0 ? so : b.val - a.val;
  });

  // Header
  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Quote Pipeline";

  // Filter buttons
  var filters = document.createElement("div"); filters.style.cssText = "display:flex;gap:5px;flex-wrap:wrap";
  var activeFilter2 = "Quote";
  ["All","Quote","Confirmed","Invoiced","Paid","Collected","Lost","Expired"].forEach(function(f) {
    var btn = document.createElement("button");
    btn.style.cssText = "padding:4px 12px;border-radius:20px;border:2px solid var(--border);font-size:11px;font-weight:700;cursor:pointer;"+(f===activeFilter2?"background:var(--navy);color:#fff;border-color:var(--navy)":"background:var(--surface);color:var(--muted)");
    btn.textContent = f;
    btn.addEventListener("click", function() {
      filters.querySelectorAll("button").forEach(function(b){b.style.background="var(--surface)";b.style.color="var(--muted)";b.style.borderColor="var(--border)";});
      btn.style.background="var(--navy)";btn.style.color="#fff";btn.style.borderColor="var(--navy)";
      activeFilter2=f; renderFilteredQuotes();
    });
    filters.appendChild(btn);
  });
  hdr.appendChild(title); hdr.appendChild(filters); qv.appendChild(hdr);

  // KPI row
  var openVal=0, confirmedVal=0, invoicedVal=0, paidVal=0, collectedVal=0;
  var nowYearQP = new Date().getFullYear();
  function qpCollectedYear(q){
    var ds = q.log.quote.collectedDate || q.log.date;
    if (!ds) return null;
    var parts = ds.split("/");
    return parts.length===3 ? parseInt(parts[2],10) : null;
  }
  allQuotes.forEach(function(q){
    if(q.log.quote.status==="Quote")openVal+=q.val;
    else if(q.log.quote.status==="Confirmed")confirmedVal+=q.val;
    else if(q.log.quote.status==="Invoiced")invoicedVal+=q.val;
    else if(q.log.quote.status==="Paid")paidVal+=q.val;
    else if(q.log.quote.status==="Collected" && qpCollectedYear(q)===nowYearQP)collectedVal+=q.val;
  });
  var lostVal=0,expiredVal=0;
  allQuotes.forEach(function(q){
    if(q.log.quote.status==="Lost")lostVal+=q.val;
    else if(q.log.quote.status==="Expired")expiredVal+=q.val;
  });
  var kpiRow = document.createElement("div");
  kpiRow.style.cssText = "display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:8px";
  [
    {l:"Quoted",v:openVal,c:"kv-amber",s:allQuotes.filter(function(q){return q.log.quote.status==="Quote";}).length+" quotes"},
    {l:"Confirmed",v:confirmedVal,c:"kv-green",s:allQuotes.filter(function(q){return q.log.quote.status==="Confirmed";}).length+" quotes"},
    {l:"Paid (awaiting collection)",v:paidVal,c:"kv-green",s:allQuotes.filter(function(q){return q.log.quote.status==="Paid";}).length+" quotes"}
  ].forEach(function(k){
    var card=document.createElement("div");card.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px";
    var lbl=document.createElement("div");lbl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:5px";lbl.textContent=k.l;
    var val=document.createElement("div");val.style.cssText="font-size:20px;font-weight:700";val.className=k.c;val.textContent="£"+k.v.toLocaleString("en-GB");
    var sub=document.createElement("div");sub.style.cssText="font-size:10px;color:var(--muted);margin-top:2px";sub.textContent=k.s;
    card.appendChild(lbl);card.appendChild(val);card.appendChild(sub);kpiRow.appendChild(card);
  });
  qv.appendChild(kpiRow);
  var kpiRow2 = document.createElement("div");
  kpiRow2.style.cssText = "display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px";
  [
    {l:"Invoiced",v:invoicedVal,c:"kv-blue",s:allQuotes.filter(function(q){return q.log.quote.status==="Invoiced";}).length+" quotes"},
    {l:"Collected ("+nowYearQP+")",v:collectedVal,c:"kv-blue",s:allQuotes.filter(function(q){return q.log.quote.status==="Collected" && qpCollectedYear(q)===nowYearQP;}).length+" quotes this year"},
    {l:"Lost",v:lostVal,c:"kv-red",s:allQuotes.filter(function(q){return q.log.quote.status==="Lost";}).length+" quotes"},
    {l:"Expired",v:expiredVal,c:"kv-amber",s:allQuotes.filter(function(q){return q.log.quote.status==="Expired";}).length+" quotes"}
  ].forEach(function(k){
    var card=document.createElement("div");card.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px";
    var lbl=document.createElement("div");lbl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:5px";lbl.textContent=k.l;
    var val=document.createElement("div");val.style.cssText="font-size:20px;font-weight:700";val.className=k.c;val.textContent="£"+k.v.toLocaleString("en-GB");
    var sub=document.createElement("div");sub.style.cssText="font-size:10px;color:var(--muted);margin-top:2px";sub.textContent=k.s;
    card.appendChild(lbl);card.appendChild(val);card.appendChild(sub);kpiRow2.appendChild(card);
  });
  qv.appendChild(kpiRow2);

  // Quote list container
  var listWrap = document.createElement("div"); listWrap.id = "quoteListWrap"; qv.appendChild(listWrap);

  function renderFilteredQuotes() {
    listWrap.innerHTML = "";
    var filtered = activeFilter2==="All" ? allQuotes.filter(function(q){return q.log.quote.status!=="Lost"&&q.log.quote.status!=="Expired";}) : allQuotes.filter(function(q){return q.log.quote.status===activeFilter2;});
    if (!filtered.length) {
      var em=document.createElement("div");em.className="empty-state";em.innerHTML="<div>&#128178;</div><div class='es-title'>No "+activeFilter2.toLowerCase()+" quotes</div>";listWrap.appendChild(em);return;
    }
    var statusCols={"Quote":"background:var(--abg);color:var(--atxt)","Confirmed":"background:var(--gbg);color:var(--gtxt)","Invoiced":"background:var(--lbg);color:var(--ltxt)","Paid":"background:#d0f0d0;color:#1a5c1a","Collected":"background:#d0e8f5;color:#0a4a7a","Lost":"background:var(--rbg);color:var(--rtxt)","Expired":"background:var(--grbg);color:var(--grtxt)"};
    filtered.forEach(function(q) {
      var card=document.createElement("div");card.style.cssText="background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px;margin-bottom:9px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;cursor:pointer";
      card.addEventListener("click",(function(cid,li4){return function(){showQuoteEditForm(cid,li4);};})(q.client.id,q.logIdx));
      // Left - client info
      var left=document.createElement("div");left.style.flex="1";left.style.minWidth="180px";
      var av=document.createElement("div");av.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:4px";
      var avCircle=document.createElement("div");avCircle.style.cssText="width:28px;height:28px;border-radius:50%;background:var(--navy);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;flex-shrink:0";avCircle.textContent=ini(q.client.name);
      var cname=document.createElement("div");cname.style.cssText="font-weight:700;font-size:13px";cname.textContent=q.client.name;
      av.appendChild(avCircle);av.appendChild(cname);
      var isCounterSale = (q.log.quote.ref||"").indexOf("SALE-")===0;
      if (isCounterSale) {
        var saleTag=document.createElement("span");saleTag.style.cssText="font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:2px 7px;border-radius:20px;background:#1a5c1a;color:#fff";saleTag.textContent="\uD83D\uDED2 Counter Sale";
        av.appendChild(saleTag);
      }
      var prod=document.createElement("div");prod.style.cssText="font-size:11px;color:var(--muted);margin-left:36px";prod.textContent=(q.log.quote.products||"")+(q.log.date?" · Quoted "+q.log.date:"")+(q.log.quote.paidDate?" · Paid "+q.log.quote.paidDate:"")+(q.log.quote.collectedDate?" · Collected "+q.log.quote.collectedDate:"");
      left.appendChild(av);left.appendChild(prod);
      if(q.log.quote.status==="Lost"&&q.log.quote.lostReason){
        var lostReasonDiv=document.createElement("div");lostReasonDiv.style.cssText="font-size:11px;color:var(--rtxt);background:var(--rbg);border-radius:var(--rs);padding:3px 8px;margin-left:36px;margin-top:4px;display:inline-block";
        lostReasonDiv.innerHTML="<strong>Lost reason:</strong> "+q.log.quote.lostReason;
        left.appendChild(lostReasonDiv);
      }
      // Middle - value and days open
      var mid=document.createElement("div");mid.style.cssText="text-align:right;min-width:100px";
      var val2=document.createElement("div");val2.style.cssText="font-size:18px;font-weight:700;color:var(--gtxt)";val2.textContent=money(q.val);
      var days=document.createElement("div");days.style.cssText="font-size:10px;color:"+(q.daysOpen>30?"var(--rtxt)":"var(--muted)");days.textContent=q.daysOpen+"d open"+(q.expired?" ⚠ EXPIRED":"");
      mid.appendChild(val2);mid.appendChild(days);
      // Right - status + expiry + update
      var right=document.createElement("div");right.style.cssText="display:flex;flex-direction:column;align-items:flex-end;gap:5px;flex-shrink:0";
      var pillRow=document.createElement("div");pillRow.style.cssText="display:flex;align-items:center;gap:6px";
      var pill=document.createElement("span");pill.style.cssText="font-size:9px;font-weight:700;padding:2px 9px;border-radius:20px;"+(statusCols[q.log.quote.status]||"background:var(--lbg);color:var(--ltxt)");pill.textContent=q.log.quote.status;
      var editBtn3=document.createElement("button");editBtn3.style.cssText="padding:2px 8px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:9px;font-weight:700;cursor:pointer";editBtn3.textContent="\u270E Edit";
      editBtn3.addEventListener("click",(function(cid,li4){return function(e4){e4.stopPropagation();showQuoteEditForm(cid,li4);};})(q.client.id,q.logIdx));
      var delBtn4=document.createElement("button");delBtn4.style.cssText="padding:2px 8px;background:var(--rbg);border:1px solid var(--rtxt);border-radius:var(--rs);color:var(--rtxt);font-size:9px;font-weight:700;cursor:pointer";delBtn4.textContent="\uD83D\uDDD1 Delete";
      delBtn4.addEventListener("click",(function(cid,li5,clientName,quoteVal){return function(e5){
        e5.stopPropagation();
        if(confirm("Delete this quote (\u00a3"+quoteVal+") from "+clientName+"? This cannot be undone.")){
          var c2=null;for(var i2=0;i2<clients.length;i2++){if(clients[i2].id===cid){c2=clients[i2];break;}}
          if(c2&&c2.log){
            c2.log.splice(li5,1);
            saveC();
            renderQuotesView();
            toast("Quote deleted \u2713");
          }
        }
      };})(q.client.id,q.logIdx,q.client.name,q.log.quote.value));
      pillRow.appendChild(pill);pillRow.appendChild(editBtn3);pillRow.appendChild(delBtn4);
      // Expiry
      var expRow=document.createElement("div");expRow.style.cssText="display:flex;align-items:center;gap:5px";
      var expLbl=document.createElement("span");expLbl.style.cssText="font-size:9px;color:var(--muted)";expLbl.textContent="Expires:";
      var expInp=document.createElement("input");expInp.type="date";expInp.value=q.log.quote.expiry||"";expInp.style.cssText="padding:2px 5px;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;font-family:inherit;outline:none;color:var(--text)";
      expInp.addEventListener("click",function(e){e.stopPropagation();});
      expInp.addEventListener("change",(function(client2,li2){return function(e2){e2.stopPropagation();client2.log[li2].quote.expiry=this.value;saveC();toast("Expiry set ✓");};})(q.client,q.logIdx));
      var exp4wkBtn2=document.createElement("button");exp4wkBtn2.type="button";exp4wkBtn2.textContent="+4wk";exp4wkBtn2.style.cssText="padding:2px 7px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:9px;font-weight:700;cursor:pointer";
      exp4wkBtn2.addEventListener("click",(function(client4,li5,inpEl){return function(e5){
        e5.stopPropagation();
        var d=new Date(); d.setDate(d.getDate()+28);
        var dateStr=d.toISOString().split("T")[0];
        inpEl.value=dateStr;
        client4.log[li5].quote.expiry=dateStr;
        saveC();
        toast("Expiry set \u2713");
      };})(q.client,q.logIdx,expInp));
      expRow.appendChild(expLbl);expRow.appendChild(expInp);expRow.appendChild(exp4wkBtn2);
      // Status update
      var statSel=document.createElement("select");statSel.style.cssText="padding:3px 7px;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;background:#fff;cursor:pointer;outline:none";
      ["Quote","Confirmed","Invoiced","Paid","Collected","Lost"].forEach(function(s2){var opt=document.createElement("option");opt.value=s2;opt.textContent=s2;if(q.log.quote.status===s2)opt.selected=true;statSel.appendChild(opt);});
      statSel.addEventListener("click",function(e){e.stopPropagation();});
      statSel.addEventListener("change",(function(client3,li3){return function(e3){
        e3.stopPropagation();
        var newStatus = this.value;
        if (newStatus === "Lost" && client3.log[li3].quote.status !== "Lost") {
          var reasonOverlay=document.createElement("div");reasonOverlay.style.cssText="position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:500;display:flex;align-items:center;justify-content:center;padding:16px";
          var reasonBox=document.createElement("div");reasonBox.style.cssText="background:var(--surface);border-radius:var(--r);width:100%;max-width:400px;border-top:3px solid var(--rtxt);padding:20px";
          var reasonTitle=document.createElement("div");reasonTitle.style.cssText="font-size:14px;font-weight:700;margin-bottom:14px;color:var(--rtxt)";reasonTitle.textContent="Why was this quote lost?";
          var reasonSel=document.createElement("select");reasonSel.style.cssText="width:100%;padding:8px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;margin-bottom:10px;font-family:inherit";
          ["Price too high","Went with competitor","No response","Job cancelled","Timing/not ready","Budget cut","Went direct to supplier","Other"].forEach(function(r){var o=document.createElement("option");o.value=r;o.textContent=r;reasonSel.appendChild(o);});
          var reasonNotes=document.createElement("input");reasonNotes.placeholder="Additional notes (optional)";reasonNotes.style.cssText="width:100%;padding:8px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;margin-bottom:14px;font-family:inherit";
          var reasonBtns=document.createElement("div");reasonBtns.style.cssText="display:flex;gap:8px;justify-content:flex-end";
          var reasonCancel=document.createElement("button");reasonCancel.textContent="Cancel";reasonCancel.style.cssText="padding:7px 16px;border:2px solid var(--border);border-radius:var(--rs);background:none;cursor:pointer;font-size:12px";
          var reasonConfirm=document.createElement("button");reasonConfirm.textContent="Mark Lost";reasonConfirm.style.cssText="padding:7px 16px;background:var(--rtxt);border:none;border-radius:var(--rs);color:#fff;cursor:pointer;font-size:12px;font-weight:700";
          reasonCancel.addEventListener("click",function(){document.body.removeChild(reasonOverlay);renderQuotesView();});
          reasonConfirm.addEventListener("click",function(){
            client3.log[li3].quote.lostReason=reasonSel.value+(reasonNotes.value?" - "+reasonNotes.value:"");
            client3.log[li3].quote.status="Lost";
            client3.log[li3].quote.paidDate="";
            client3.log[li3].quote.collectedDate="";
            saveC();
            document.body.removeChild(reasonOverlay);
            renderQuotesView();
            toast("Quote marked lost");
          });
          reasonBtns.appendChild(reasonCancel);reasonBtns.appendChild(reasonConfirm);
          reasonBox.appendChild(reasonTitle);reasonBox.appendChild(reasonSel);reasonBox.appendChild(reasonNotes);reasonBox.appendChild(reasonBtns);
          reasonOverlay.appendChild(reasonBox);document.body.appendChild(reasonOverlay);
          return;
        }
        if (newStatus === "Paid" && client3.log[li3].quote.status !== "Paid") {
          var today9 = new Date();
          var defaultPaid = String(today9.getDate()).padStart(2,"0")+"/"+String(today9.getMonth()+1).padStart(2,"0")+"/"+today9.getFullYear();
          var enteredDate = prompt("Date paid (DD/MM/YYYY):", defaultPaid);
          if (enteredDate === null) { renderQuotesView(); return; } // cancelled, revert dropdown
          client3.log[li3].quote.paidDate = enteredDate.trim() || defaultPaid;
        }
        if (newStatus === "Collected" && client3.log[li3].quote.status !== "Collected") {
          var today12 = new Date();
          var defaultCollected2 = String(today12.getDate()).padStart(2,"0")+"/"+String(today12.getMonth()+1).padStart(2,"0")+"/"+today12.getFullYear();
          var enteredCollected2 = prompt("Date collected (DD/MM/YYYY):", defaultCollected2);
          if (enteredCollected2 === null) { renderQuotesView(); return; }
          client3.log[li3].quote.collectedDate = enteredCollected2.trim() || defaultCollected2;
        }
        client3.log[li3].quote.status = newStatus;
        saveC();
        renderQuotesView();
        toast("Quote updated \u2713");
      };})(q.client,q.logIdx));
      right.appendChild(pillRow);right.appendChild(expRow);right.appendChild(statSel);
      card.appendChild(left);card.appendChild(mid);card.appendChild(right);listWrap.appendChild(card);
    });
  }
  renderFilteredQuotes();

  var bk=document.createElement("button");bk.className="bkl";bk.textContent="← Back to dashboard";bk.addEventListener("click",showDash);qv.appendChild(bk);
}


// ── USEFUL WEBSITES ───────────────────────────────────────────────
var WEB_STORE = "spcrm_websites_v1";
var websites = [];

function loadWebsites() {
  try { var r = localStorage.getItem(WEB_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
// saveWebsites handled by Supabase version above

function showWebsites() {
  activeId = null; renderList(); showView("websites"); renderWebsitesView();
}

var TOOLS_LIST = [
  { name: "Margin Calculator", desc: "Nett price + margin % \u2192 customer price ex/inc VAT, plus box pricing.", icon: "\uD83E\uDDEE", native: true, renderFn: renderMarginCalcNative },
  { name: "Measurement Converter", desc: "Feet & inches \u2194 metres/yards/cm, plus room area in m\u00b2, ft\u00b2 and yd\u00b2.", icon: "\uD83D\uDCD0", native: true, renderFn: renderMeasureConverterNative },
  { name: "Margin Cutter", desc: "Work out the discount needed to hit a target margin, inc/ex VAT.", icon: "\uD83D\uDCB0", url: "margin-cutter.html" },
  { name: "Roll Planner", desc: "Carpet area & roll-width planner for rectangles, L-shapes, stairs and chimney breasts.", icon: "\uD83D\uDCD0", url: "roll-planner.html" }
];

function renderToolsView() {
  var tv = document.getElementById("toolsView");
  tv.innerHTML = "";

  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Trade Tools";
  tv.appendChild(title);

  var sub = document.createElement("div");
  sub.style.cssText = "font-size:12px;color:var(--muted);margin-bottom:16px;margin-top:-8px";
  sub.textContent = "Quick calculators for the trade counter.";
  tv.appendChild(sub);

  var grid = document.createElement("div");
  grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px";

  TOOLS_LIST.forEach(function(t){
    var card = document.createElement("div");
    card.style.cssText = "display:block;background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:16px;cursor:pointer;color:var(--text);box-shadow:0 1px 4px rgba(0,0,0,.06);transition:border-color .15s ease";
    card.onmouseenter = function(){ card.style.borderColor = "var(--navy)"; };
    card.onmouseleave = function(){ card.style.borderColor = "var(--border)"; };
    card.onclick = function(){ openToolInline(t); };

    var iconEl = document.createElement("div"); iconEl.style.cssText = "font-size:26px;margin-bottom:8px"; iconEl.textContent = t.icon;
    var nameEl = document.createElement("div"); nameEl.style.cssText = "font-size:14px;font-weight:700;margin-bottom:4px;color:var(--navy)"; nameEl.textContent = t.name;
    var descEl = document.createElement("div"); descEl.style.cssText = "font-size:11.5px;color:var(--muted);line-height:1.4"; descEl.textContent = t.desc;

    card.appendChild(iconEl); card.appendChild(nameEl); card.appendChild(descEl);
    grid.appendChild(card);
  });

  tv.appendChild(grid);
}

function openToolInline(t){
  var tv = document.getElementById("toolsView");
  tv.innerHTML = "";

  var barWrap = document.createElement("div");
  barWrap.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px";

  var backBtn = document.createElement("button");
  backBtn.className = "nav-btn";
  backBtn.style.cssText = "background:var(--navy);color:#fff;border-color:var(--navy)";
  backBtn.textContent = "\u2190 Back to Tools";
  backBtn.onclick = function(){ renderToolsView(); };

  var label = document.createElement("div");
  label.style.cssText = "font-size:14px;font-weight:700;color:var(--navy)";
  label.textContent = t.icon + " " + t.name;

  barWrap.appendChild(backBtn);
  barWrap.appendChild(label);

  if (t.native) {
    tv.appendChild(barWrap);
    t.renderFn(tv);
    return;
  }

  var openNewTab = document.createElement("a");
  openNewTab.href = t.url; openNewTab.target = "_blank"; openNewTab.rel = "noopener";
  openNewTab.style.cssText = "font-size:11px;color:var(--muted);text-decoration:underline";
  openNewTab.textContent = "open in new tab \u2197";
  barWrap.appendChild(openNewTab);
  tv.appendChild(barWrap);

  var iframe = document.createElement("iframe");
  iframe.src = t.url;
  iframe.style.cssText = "width:100%;height:78vh;border:2px solid var(--border);border-radius:var(--r);background:#fff";
  tv.appendChild(iframe);
}

// Built-in Margin Calculator — nett price + margin % <-> customer price ex/inc VAT,
// plus box pricing, fully native (no iframe), matching CRM styling.
function renderMarginCalcNative(container) {
  var wrap = document.createElement("div");
  wrap.style.cssText = "max-width:520px";
  var FIELD_W = "150px"; // just enough width for a value like £1234.00 — boxes no longer stretch to fill the row

  function mkCard(titleTxt) {
    var card = document.createElement("div");
    card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
    var h = document.createElement("div");
    h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)";
    h.textContent = titleTxt;
    card.appendChild(h);
    wrap.appendChild(card);
    return card;
  }
  function mkFd(lbl, inp, extraCss) {
    var w = document.createElement("div"); w.style.cssText = "margin-bottom:10px;width:"+FIELD_W+";flex:0 0 auto" + (extraCss||"");
    var l = document.createElement("label"); l.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:4px;white-space:nowrap"; l.textContent = lbl;
    w.appendChild(l); w.appendChild(inp);
    return w;
  }
  function mkMoneyInput(id) {
    var box = document.createElement("div"); box.style.cssText = "display:flex;align-items:center;border:2px solid var(--border);border-radius:var(--rs);background:#fff;overflow:hidden;width:"+FIELD_W+";box-sizing:border-box";
    var pre = document.createElement("span"); pre.style.cssText = "color:var(--muted);font-size:14px;font-weight:600;padding-left:9px"; pre.textContent = "\u00a3";
    var inp = document.createElement("input"); inp.id = id; inp.type = "number"; inp.step = "0.01";
    inp.style.cssText = "border:none;width:0;flex:1;min-width:0;padding:7px 8px 7px 3px;font-size:14px;font-family:inherit;outline:none;background:transparent";
    box.appendChild(pre); box.appendChild(inp);
    return { box: box, inp: inp };
  }
  function mkStat(lblTxt, id, colorVar) {
    var s = document.createElement("div"); s.style.cssText = "background:var(--alt);border-radius:var(--rs);padding:7px 9px;width:"+FIELD_W+";box-sizing:border-box;flex:0 0 auto";
    var l = document.createElement("div"); l.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"; l.textContent = lblTxt;
    var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:baseline";
    var pre = document.createElement("span"); pre.style.cssText = "font-size:13px;font-weight:700;margin-right:2px;flex-shrink:0;color:"+colorVar; pre.textContent = "\u00a3";
    var inp = document.createElement("input"); inp.id = id; inp.type = "number"; inp.step = "0.01";
    inp.style.cssText = "font-size:15px;font-weight:700;font-family:inherit;border:none;background:none;padding:0;outline:none;color:"+colorVar+";width:0;flex:1;min-width:0";
    row.appendChild(pre); row.appendChild(inp);
    s.appendChild(l); s.appendChild(row);
    return { el: s, inp: inp };
  }
  function mkStatic(lblTxt) {
    var s = document.createElement("div"); s.style.cssText = "background:var(--alt);border-radius:var(--rs);padding:7px 9px;width:"+FIELD_W+";box-sizing:border-box;flex:0 0 auto";
    var l = document.createElement("div"); l.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"; l.textContent = lblTxt;
    var v = document.createElement("div"); v.style.cssText = "font-size:14px;font-weight:700;color:var(--navy)"; v.textContent = "\u2014";
    s.appendChild(l); s.appendChild(v);
    return { el: s, valEl: v };
  }

  // Card 1: inputs
  var c1 = mkCard("Per m\u00b2 (or per unit)");
  var row1 = document.createElement("div"); row1.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";
  var nettEx = mkMoneyInput("mc_nettEx");
  row1.appendChild(mkFd("Our nett price ex VAT", nettEx.box));
  var marginBox = document.createElement("div"); marginBox.style.cssText = "display:flex;align-items:center;border:2px solid #e6a15c;border-radius:var(--rs);background:#fff4e8;overflow:hidden;width:"+FIELD_W+";box-sizing:border-box";
  var marginInp = document.createElement("input"); marginInp.id = "mc_margin"; marginInp.type = "number"; marginInp.step = "0.1"; marginInp.placeholder = "40";
  marginInp.style.cssText = "border:none;width:0;flex:1;min-width:0;padding:7px 4px 7px 8px;font-size:14px;font-family:inherit;outline:none;background:transparent";
  var marginSuf = document.createElement("span"); marginSuf.style.cssText = "color:#CC9400;font-size:14px;font-weight:600;padding-right:9px"; marginSuf.textContent = "%";
  marginBox.appendChild(marginInp); marginBox.appendChild(marginSuf);
  var marginFd = mkFd("Margin % (on cust. price)", marginBox);
  marginFd.querySelector("label").style.color = "#CC9400";
  row1.appendChild(marginFd);
  c1.appendChild(row1);
  var swapHint = document.createElement("div"); swapHint.style.cssText = "font-size:10.5px;color:var(--muted);margin-top:8px"; swapHint.textContent = "Prefer to type the customer price instead? Fill that box below and the margin works itself out.";
  c1.appendChild(swapHint);

  // Card 2: results
  var c2 = mkCard("Results");
  var resGrid = document.createElement("div"); resGrid.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";
  var nettInc = mkStat("Nett inc VAT", "mc_nettInc", "var(--navy)");
  var custEx = mkStat("Cust. price ex VAT", "mc_custEx", "#e67e22");
  var custInc = mkStat("Cust. price inc VAT", "mc_custInc", "#e67e22");
  resGrid.appendChild(nettInc.el); resGrid.appendChild(custEx.el); resGrid.appendChild(custInc.el);
  c2.appendChild(resGrid);
  var resHint = document.createElement("div"); resHint.style.cssText = "font-size:11px;color:var(--muted);margin-top:8px;line-height:1.5"; resHint.textContent = "Every box above is editable \u2014 change any of them and the rest recalculate, including the margin %.";
  c2.appendChild(resHint);

  // Card 3: box pricing
  var c3 = mkCard("Box price");
  var m2Box = document.createElement("input"); m2Box.id = "mc_m2Box"; m2Box.type = "number"; m2Box.step = "0.01"; m2Box.placeholder = "2.16";
  m2Box.style.cssText = "width:100%;box-sizing:border-box;padding:7px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:14px;font-family:inherit;outline:none";
  c3.appendChild(mkFd("m\u00b2 per box", m2Box));
  var boxGrid = document.createElement("div"); boxGrid.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";
  var boxNettEx = mkStatic("Nett ex VAT");
  var boxNettInc = mkStatic("Nett inc VAT");
  var boxCustEx = mkStatic("Cust. ex VAT"); boxCustEx.valEl.style.color = "#e67e22";
  var boxCustInc = mkStatic("Cust. inc VAT"); boxCustInc.valEl.style.color = "#e67e22";
  boxGrid.appendChild(boxNettEx.el); boxGrid.appendChild(boxNettInc.el); boxGrid.appendChild(boxCustEx.el); boxGrid.appendChild(boxCustInc.el);
  c3.appendChild(boxGrid);

  container.appendChild(wrap);

  // Wiring — same bidirectional logic as the standalone tool
  function fmtMoney(v) { return isFinite(v) ? ("\u00a3" + v.toFixed(2)) : "\u2014"; }
  function recalcFromNettMargin() {
    var ne = parseFloat(nettEx.inp.value);
    var m = parseFloat(marginInp.value);
    if (!isNaN(ne)) nettInc.inp.value = (ne * 1.2).toFixed(2);
    if (!isNaN(ne) && !isNaN(m) && m >= 0 && m < 100) {
      var ce = ne / (1 - m / 100);
      custEx.inp.value = ce.toFixed(2);
      custInc.inp.value = (ce * 1.2).toFixed(2);
    }
    updateBox();
  }
  function recalcMarginFromCust() {
    var ne = parseFloat(nettEx.inp.value);
    var ce = parseFloat(custEx.inp.value);
    if (!isNaN(ne) && !isNaN(ce) && ce > 0) marginInp.value = (((ce - ne) / ce) * 100).toFixed(1);
    if (!isNaN(ce)) custInc.inp.value = (ce * 1.2).toFixed(2);
    updateBox();
  }
  function updateBox() {
    var m2 = parseFloat(m2Box.value);
    var ne = parseFloat(nettEx.inp.value), ni = parseFloat(nettInc.inp.value);
    var ce = parseFloat(custEx.inp.value), ci = parseFloat(custInc.inp.value);
    boxNettEx.valEl.textContent = (!isNaN(m2) && !isNaN(ne)) ? fmtMoney(ne * m2) : "\u2014";
    boxNettInc.valEl.textContent = (!isNaN(m2) && !isNaN(ni)) ? fmtMoney(ni * m2) : "\u2014";
    boxCustEx.valEl.textContent = (!isNaN(m2) && !isNaN(ce)) ? fmtMoney(ce * m2) : "\u2014";
    boxCustInc.valEl.textContent = (!isNaN(m2) && !isNaN(ci)) ? fmtMoney(ci * m2) : "\u2014";
  }
  nettEx.inp.addEventListener("input", function(){ if (marginInp.value.trim() !== "") recalcFromNettMargin(); else recalcMarginFromCust(); });
  marginInp.addEventListener("input", recalcFromNettMargin);
  custEx.inp.addEventListener("input", recalcMarginFromCust);
  custInc.inp.addEventListener("input", function(){ var v = parseFloat(this.value); if (!isNaN(v)) custEx.inp.value = (v / 1.2).toFixed(2); recalcMarginFromCust(); });
  nettInc.inp.addEventListener("input", function(){ var v = parseFloat(this.value); if (!isNaN(v)) nettEx.inp.value = (v / 1.2).toFixed(2); if (marginInp.value.trim() !== "") recalcFromNettMargin(); else recalcMarginFromCust(); });
  m2Box.addEventListener("input", updateBox);
}

// Built-in Measurement Converter — feet & inches <-> metres/yards/cm, live,
// plus a room-area calculator giving m² / ft² / yd² for ordering flooring.
// Footfall Pattern Analyzer — enter weekly footfall counts by category (same
// categories as the Footfall Tracker spreadsheet) and see category share,
// week-on-week trend, and which categories tend to move together.
var FOOTFALL_CATS = ["Best @ Floorstore","Existing Customer Picked Up/Paid","Existing Customer Query","Floorstore Customer Pickup","New Walk In - Query","New Walk In - Purchase","House Build Fitters"];
var FOOTFALL_CATS_SHORT = ["Best @ Floorstore","Existing \u2013 Picked Up","Existing \u2013 Query","Floorstore Pickup","New Walk In \u2013 Query","New Walk In \u2013 Purchase","House Build Fitters"];

function pearsonCorr(x, y) {
  var n = x.length;
  if (n < 3) return null;
  var mx = x.reduce(function(a,b){return a+b;},0)/n;
  var my = y.reduce(function(a,b){return a+b;},0)/n;
  var num=0, dx2=0, dy2=0;
  for (var i=0;i<n;i++){ var dx=x[i]-mx, dy=y[i]-my; num+=dx*dy; dx2+=dx*dx; dy2+=dy*dy; }
  if (dx2===0 || dy2===0) return null;
  return num/Math.sqrt(dx2*dy2);
}

function mkFootfallPieChart(id, labels, values) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var colors = ["#305CDE","#C0392B","#2ecc71","#f39c12","#9b59b6","#1abc9c","#e67e22"];
  var cfg = {
    type: "doughnut",
    data: { labels: labels, datasets: [{ data: values, backgroundColor: colors, borderWidth: 2, borderColor: "#fff" }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: "right", labels: { font: { size: 10 }, boxWidth: 10,
        generateLabels: function(chart) {
          var d = chart.data; var tot = d.datasets[0].data.reduce(function(a,b){return a+b;},0);
          return d.labels.map(function(lbl,i){ var v=d.datasets[0].data[i]; var pct = tot>0?((v/tot)*100).toFixed(1):0; return { text: lbl+" ("+pct+"%)", fillStyle: d.datasets[0].backgroundColor[i], hidden:false, index:i }; });
        } } } }
    }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}

function mkFootfallTrendChart(id, weekLabels, totals) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var cfg = {
    type: "bar",
    data: { labels: weekLabels, datasets: [{ label: "Footfall", data: totals, backgroundColor: "#305CDE", borderRadius: 5 }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}

function renderMeasureConverterNative(container) {
  var wrap = document.createElement("div");
  wrap.style.cssText = "max-width:560px";

  function mkCard(titleTxt) {
    var card = document.createElement("div");
    card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
    var h = document.createElement("div");
    h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)";
    h.textContent = titleTxt;
    card.appendChild(h);
    wrap.appendChild(card);
    return card;
  }
  function mkNumBox(id, placeholder, w) {
    var inp = document.createElement("input"); inp.id = id; inp.type = "number"; inp.step = "any"; inp.placeholder = placeholder||"";
    inp.style.cssText = "border:2px solid var(--border);border-radius:var(--rs);width:"+(w||"84px")+";box-sizing:border-box;padding:7px 8px;font-size:14px;font-family:inherit;outline:none;background:#fff";
    return inp;
  }
  function mkFd(lbl, el) {
    var w = document.createElement("div"); w.style.cssText = "display:flex;flex-direction:column;gap:4px";
    var l = document.createElement("label"); l.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;white-space:nowrap"; l.textContent = lbl;
    w.appendChild(l); w.appendChild(el);
    return w;
  }
  function mkStat(lblTxt) {
    var s = document.createElement("div"); s.style.cssText = "background:var(--alt);border-radius:var(--rs);padding:8px 10px;flex:1;min-width:100px";
    var l = document.createElement("div"); l.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);margin-bottom:3px;white-space:nowrap"; l.textContent = lblTxt;
    var v = document.createElement("div"); v.style.cssText = "font-size:15px;font-weight:700;color:var(--navy)"; v.textContent = "\u2014";
    s.appendChild(l); s.appendChild(v);
    return { el: s, valEl: v };
  }

  // ── Card 1: Length converter ──────────────────────────────────
  var c1 = mkCard("Length converter — type into any box");
  var row1 = document.createElement("div"); row1.style.cssText = "display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end";
  var feetInp = mkNumBox("mv_feet", "0", "70px");
  var inchInp = mkNumBox("mv_inch", "0", "70px");
  var metresInp = mkNumBox("mv_metres", "0", "90px");
  var yardsInp = mkNumBox("mv_yards", "0", "90px");
  var cmInp = mkNumBox("mv_cm", "0", "90px");
  row1.appendChild(mkFd("Feet", feetInp));
  row1.appendChild(mkFd("Inches", inchInp));
  row1.appendChild(mkFd("Metres", metresInp));
  row1.appendChild(mkFd("Yards", yardsInp));
  row1.appendChild(mkFd("Centimetres", cmInp));
  c1.appendChild(row1);

  var FT_TO_M = 0.3048, IN_TO_M = 0.0254, YD_TO_M = 0.9144;
  function pushLength(m, skip) {
    if (skip !== "fi") {
      var totalIn = m / IN_TO_M;
      var ft = Math.floor(totalIn / 12 + 1e-9);
      var inch = Math.round((totalIn - ft * 12) * 100) / 100;
      feetInp.value = ft; inchInp.value = inch;
    }
    if (skip !== "m") metresInp.value = m.toFixed(3);
    if (skip !== "y") yardsInp.value = (m / YD_TO_M).toFixed(3);
    if (skip !== "cm") cmInp.value = (m * 100).toFixed(1);
  }
  feetInp.addEventListener("input", function(){ pushLength(((parseFloat(feetInp.value)||0)*12 + (parseFloat(inchInp.value)||0)) * IN_TO_M, "fi"); });
  inchInp.addEventListener("input", function(){ pushLength(((parseFloat(feetInp.value)||0)*12 + (parseFloat(inchInp.value)||0)) * IN_TO_M, "fi"); });
  metresInp.addEventListener("input", function(){ pushLength(parseFloat(metresInp.value)||0, "m"); });
  yardsInp.addEventListener("input", function(){ pushLength((parseFloat(yardsInp.value)||0) * YD_TO_M, "y"); });
  cmInp.addEventListener("input", function(){ pushLength((parseFloat(cmInp.value)||0) / 100, "cm"); });

  // ── Card 2: Room area calculator ────────────────────────────────
  var c2 = mkCard("Room area — length \u00d7 width");
  var modeRow = document.createElement("div"); modeRow.style.cssText = "display:flex;gap:8px;margin-bottom:12px";
  var modeFi = document.createElement("button"); modeFi.type = "button"; modeFi.textContent = "Feet & inches";
  var modeM = document.createElement("button"); modeM.type = "button"; modeM.textContent = "Metres";
  [modeFi, modeM].forEach(function(b){ b.style.cssText = "padding:6px 12px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:2px solid var(--border);background:#fff;color:var(--muted)"; });
  modeRow.appendChild(modeFi); modeRow.appendChild(modeM);
  c2.appendChild(modeRow);

  var dimsRow = document.createElement("div"); dimsRow.style.cssText = "display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:12px";
  c2.appendChild(dimsRow);

  var resultsRow = document.createElement("div"); resultsRow.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";
  var statM2 = mkStat("Area (m\u00b2)"), statFt2 = mkStat("Area (ft\u00b2)"), statYd2 = mkStat("Area (yd\u00b2)");
  resultsRow.appendChild(statM2.el); resultsRow.appendChild(statFt2.el); resultsRow.appendChild(statYd2.el);
  c2.appendChild(resultsRow);

  var wasteRow = document.createElement("div"); wasteRow.style.cssText = "display:flex;align-items:flex-end;gap:10px;margin-top:12px";
  var wasteInp = mkNumBox("mv_waste", "10", "70px");
  wasteRow.appendChild(mkFd("+ Waste %", wasteInp));
  var statGross = mkStat("Gross area (m\u00b2, inc. waste)");
  wasteRow.appendChild(statGross.el);
  c2.appendChild(wasteRow);

  var areaMode = "fi";
  function setAreaMode(m) {
    areaMode = m;
    modeFi.style.cssText += (m==="fi" ? ";background:var(--navy);color:#fff;border-color:var(--navy)" : ";background:#fff;color:var(--muted);border-color:var(--border)");
    modeM.style.cssText += (m==="m" ? ";background:var(--navy);color:#fff;border-color:var(--navy)" : ";background:#fff;color:var(--muted);border-color:var(--border)");
    dimsRow.innerHTML = "";
    if (m === "fi") {
      var lf = mkNumBox("mv_lf","0","60px"), li = mkNumBox("mv_li","0","60px");
      var wf = mkNumBox("mv_wf","0","60px"), wi = mkNumBox("mv_wi","0","60px");
      dimsRow.appendChild(mkFd("Length ft", lf)); dimsRow.appendChild(mkFd("in", li));
      dimsRow.appendChild(mkFd("Width ft", wf)); dimsRow.appendChild(mkFd("in", wi));
      [lf,li,wf,wi].forEach(function(inp){ inp.addEventListener("input", recalcArea); });
    } else {
      var lm = mkNumBox("mv_lm","0","90px"), wm = mkNumBox("mv_wm","0","90px");
      dimsRow.appendChild(mkFd("Length (m)", lm)); dimsRow.appendChild(mkFd("Width (m)", wm));
      [lm,wm].forEach(function(inp){ inp.addEventListener("input", recalcArea); });
    }
    recalcArea();
  }
  function recalcArea() {
    var lenM, widM;
    if (areaMode === "fi") {
      var lf = parseFloat(document.getElementById("mv_lf") && document.getElementById("mv_lf").value) || 0;
      var li = parseFloat(document.getElementById("mv_li") && document.getElementById("mv_li").value) || 0;
      var wf = parseFloat(document.getElementById("mv_wf") && document.getElementById("mv_wf").value) || 0;
      var wi = parseFloat(document.getElementById("mv_wi") && document.getElementById("mv_wi").value) || 0;
      lenM = (lf*12 + li) * IN_TO_M;
      widM = (wf*12 + wi) * IN_TO_M;
    } else {
      lenM = parseFloat(document.getElementById("mv_lm") && document.getElementById("mv_lm").value) || 0;
      widM = parseFloat(document.getElementById("mv_wm") && document.getElementById("mv_wm").value) || 0;
    }
    var m2 = lenM * widM;
    if (m2 > 0) {
      statM2.valEl.textContent = m2.toFixed(2);
      statFt2.valEl.textContent = (m2 / (FT_TO_M*FT_TO_M)).toFixed(2);
      statYd2.valEl.textContent = (m2 / (YD_TO_M*YD_TO_M)).toFixed(2);
      var waste = parseFloat(wasteInp.value) || 0;
      statGross.valEl.textContent = (m2 * (1 + waste/100)).toFixed(2);
    } else {
      statM2.valEl.textContent = statFt2.valEl.textContent = statYd2.valEl.textContent = statGross.valEl.textContent = "\u2014";
    }
  }
  wasteInp.addEventListener("input", recalcArea);
  modeFi.addEventListener("click", function(){ setAreaMode("fi"); });
  modeM.addEventListener("click", function(){ setAreaMode("m"); });
  setAreaMode("fi");

  container.appendChild(wrap);
}

function renderWebsitesView() {
  var wv = document.getElementById("websitesView");
  wv.innerHTML = "";

  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Useful Websites";
  var addBtn = document.createElement("button");
  addBtn.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  addBtn.textContent = "+ Add website";
  addBtn.addEventListener("click", function(){ showAddWebsite(); });
  hdr.appendChild(title); hdr.appendChild(addBtn); wv.appendChild(hdr);

  // Search box
  var sw = document.createElement("div");
  sw.style.cssText = "display:flex;align-items:center;gap:8px;background:var(--surface);border:2px solid var(--navy);border-radius:var(--rs);padding:9px 12px;margin-bottom:14px;max-width:360px;box-shadow:0 1px 4px rgba(0,0,0,.06)";
  var sIcon = document.createElement("span"); sIcon.textContent = "\uD83D\uDD0D"; sIcon.style.cssText = "font-size:14px";
  var si = document.createElement("input"); si.type = "text"; si.id = "webSearch"; si.placeholder = "Search websites by name, URL or description...";
  si.style.cssText = "background:none;border:none;outline:none;font-size:13px;color:var(--text);flex:1;min-width:0";
  si.addEventListener("input", function(){ activeSearch = this.value; renderList2(); });
  sw.appendChild(sIcon); sw.appendChild(si); wv.appendChild(sw);
  var activeSearch = "";

  // Category filter
  var cats = ["All"];
  websites.forEach(function(w){ if(w.category && cats.indexOf(w.category)<0) cats.push(w.category); });
  var activeCat = "All";

  if (cats.length > 1) {
    var catRow = document.createElement("div"); catRow.style.cssText = "display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px";
    cats.forEach(function(cat) {
      var btn = document.createElement("button");
      btn.style.cssText = "padding:4px 12px;border-radius:20px;border:2px solid var(--border);font-size:11px;font-weight:700;cursor:pointer;"+(cat==="All"?"background:var(--navy);color:#fff;border-color:var(--navy)":"background:var(--surface);color:var(--muted)");
      btn.textContent = cat;
      btn.addEventListener("click", function(){
        catRow.querySelectorAll("button").forEach(function(b){b.style.background="var(--surface)";b.style.color="var(--muted)";b.style.borderColor="var(--border)";});
        btn.style.background="var(--navy)";btn.style.color="#fff";btn.style.borderColor="var(--navy)";
        activeCat=cat; renderList2();
      });
      catRow.appendChild(btn);
    });
    wv.appendChild(catRow);
  }

  var listWrap = document.createElement("div"); listWrap.id = "webListWrap"; wv.appendChild(listWrap);

  function renderList2() {
    listWrap.innerHTML = "";
    var filtered = activeCat==="All" ? websites : websites.filter(function(w){ return w.category===activeCat; });
    var q = (activeSearch||"").toLowerCase();
    if (q) {
      filtered = filtered.filter(function(w){
        return [w.name, w.url, w.description, w.category].some(function(v){ return (v||"").toLowerCase().indexOf(q) > -1; });
      });
    }
    if (!filtered.length) {
      var em = document.createElement("div"); em.className = "empty-state";
      em.innerHTML = q ? "<div>&#128269;</div><div class='es-title'>No results found</div><div class='es-sub'>Try a different search term</div>" : "<div>&#127760;</div><div class='es-title'>No websites added yet</div><div class='es-sub'>Add your useful trade websites, supplier portals, reference sites — they travel with you wherever you go</div>";
      listWrap.appendChild(em); return;
    }

    // Group by category
    var groups = {};
    filtered.forEach(function(w){
      var cat = w.category || "General";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(w);
    });

    Object.keys(groups).sort().forEach(function(cat) {
      if (activeCat === "All" && Object.keys(groups).length > 1) {
        var catHdr = document.createElement("div");
        catHdr.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:8px;margin-top:14px;padding-bottom:5px;border-bottom:2px solid var(--navy)";
        catHdr.textContent = cat; listWrap.appendChild(catHdr);
      }
      var grid = document.createElement("div");
      grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;margin-bottom:10px";
      groups[cat].forEach(function(w, wi) {
        var realIdx = websites.indexOf(w);
        var card = document.createElement("div");
        card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;display:flex;flex-direction:column;gap:8px;transition:box-shadow .15s";
        card.addEventListener("mouseenter", function(){ this.style.boxShadow="0 2px 12px rgba(0,51,160,.1)"; });
        card.addEventListener("mouseleave", function(){ this.style.boxShadow="none"; });

        var top = document.createElement("div"); top.style.cssText = "display:flex;align-items:flex-start;gap:10px";
        var icon = document.createElement("div");
        icon.style.cssText = "width:36px;height:36px;border-radius:8px;background:var(--navy);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0";
        icon.textContent = w.icon || "\uD83C\uDF10";
        var info = document.createElement("div"); info.style.flex = "1";
        var nm = document.createElement("div"); nm.style.cssText = "font-weight:700;font-size:13px;margin-bottom:2px"; nm.textContent = w.name;
        var url = document.createElement("div"); url.style.cssText = "font-size:10px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"; url.textContent = w.url;
        info.appendChild(nm); info.appendChild(url); top.appendChild(icon); top.appendChild(info);

        if (w.description) {
          var desc = document.createElement("div"); desc.style.cssText = "font-size:11px;color:var(--muted);line-height:1.5"; desc.textContent = w.description;
          card.appendChild(top); card.appendChild(desc);
        } else {
          card.appendChild(top);
        }
        if (w.notes) {
          var noteDiv = document.createElement("div"); noteDiv.style.cssText = "font-size:11px;color:var(--text);font-style:italic;background:var(--alt);border-radius:var(--rs);padding:6px 8px;line-height:1.4"; noteDiv.textContent = w.notes;
          card.appendChild(noteDiv);
        }

        var btns = document.createElement("div"); btns.style.cssText = "display:flex;gap:6px;margin-top:4px";
        var openBtn = document.createElement("button");
        openBtn.style.cssText = "flex:1;padding:6px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer";
        openBtn.textContent = "\uD83D\uDD17 Open site";
        openBtn.addEventListener("click", (function(u){ return function(){ window.open(u.indexOf("http")===0?u:"https://"+u,"_blank"); }; })(w.url));
        var editBtn2 = document.createElement("button");
        editBtn2.style.cssText = "padding:6px 10px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;cursor:pointer;color:var(--muted)";
        editBtn2.textContent = "\u270E";
        editBtn2.addEventListener("click", (function(idx2){ return function(){ showAddWebsite(idx2); }; })(realIdx));
        var webPrintBtn = document.createElement("button"); webPrintBtn.className = "no-print";
        webPrintBtn.style.cssText = "padding:6px 10px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;cursor:pointer;color:var(--navy)";
        webPrintBtn.textContent = "\uD83D\uDDA8\uFE0F";
        webPrintBtn.addEventListener("click", (function(site){ return function(){ printWebsiteSlip(site); }; })(w));
        var delBtn2 = document.createElement("button");
        delBtn2.style.cssText = "padding:6px 10px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;cursor:pointer;color:var(--rtxt)";
        delBtn2.textContent = "\u00d7";
        delBtn2.addEventListener("click", (function(idx2){ return async function(){ if(confirm("Remove this website?")){ var siteToDelete=websites[idx2]; websites.splice(idx2,1); if(siteToDelete&&siteToDelete.id){ await sbDelete("websites", siteToDelete.id); } saveWebsites(); renderWebsitesView(); toast("Removed"); } }; })(realIdx));
        btns.appendChild(openBtn); btns.appendChild(editBtn2); btns.appendChild(webPrintBtn); btns.appendChild(delBtn2);
        card.appendChild(btns); grid.appendChild(card);
      });
      listWrap.appendChild(grid);
    });
  }
  renderList2();

  var bk = document.createElement("button"); bk.className = "bkl"; bk.textContent = "\u2190 Back to dashboard"; bk.addEventListener("click", showDash); wv.appendChild(bk);
}

function showAddWebsite(editIdx) {
  var w = editIdx !== undefined ? websites[editIdx] : null;
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:460px;border-top:3px solid var(--navy)";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = w ? "Edit website" : "Add useful website";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkFw(lbl, inp2){ var d=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; l.textContent=lbl; d.appendChild(l); d.appendChild(inp2); return d; }
  function mkIw(id2,val,ph){ var i=document.createElement("input"); i.id=id2; i.value=val||""; i.placeholder=ph||""; i.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none"; return i; }

  var nameInp3 = mkIw("w_name", w?w.name:"", "e.g. Karndean Trade Portal");
  var urlInp = mkIw("w_url", w?w.url:"", "e.g. trade.karndean.com");
  var descInp2 = document.createElement("textarea"); descInp2.id="w_desc"; descInp2.value=w?w.description||"":""; descInp2.placeholder="What is this site for? e.g. Karndean trade pricing and sample orders"; descInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:60px";
  var notesInp2 = document.createElement("textarea"); notesInp2.id="w_notes"; notesInp2.value=w?w.notes||"":""; notesInp2.placeholder="Any personal notes \u2014 login reminders, account numbers, quirks of the site, etc."; notesInp2.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:60px";

  // Category
  var catInp = mkIw("w_cat", w?w.category||"":"", "e.g. Suppliers, Pricing, Reference, Trade");

  // Icon picker
  var iconRow = document.createElement("div"); iconRow.style.cssText = "display:flex;gap:6px;flex-wrap:wrap";
  var icons = ["\uD83C\uDF10","\uD83D\uDCB0","\uD83D\uDCCA","\uD83D\uDCE6","\uD83D\uDD27","\uD83C\uDFE0","\uD83D\uDCCB","\u2139\uFE0F","\uD83D\uDCDE","\uD83D\uDEE0"];
  var selIcon = w?w.icon||"\uD83C\uDF10":"\uD83C\uDF10";
  icons.forEach(function(ic){
    var btn2=document.createElement("button");btn2.type="button";
    btn2.style.cssText="width:36px;height:36px;border-radius:8px;border:2px solid "+(ic===selIcon?"var(--navy)":"var(--border)")+";background:"+(ic===selIcon?"#eef1f8":"var(--surface)")+";font-size:18px;cursor:pointer";
    btn2.textContent=ic;
    btn2.addEventListener("click",function(){
      iconRow.querySelectorAll("button").forEach(function(b){b.style.borderColor="var(--border)";b.style.background="var(--surface)";});
      btn2.style.borderColor="var(--navy)";btn2.style.background="#eef1f8";selIcon=ic;
    });
    iconRow.appendChild(btn2);
  });
  var iconWrap=document.createElement("div");var iconLbl=document.createElement("label");iconLbl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px";iconLbl.textContent="Icon";iconWrap.appendChild(iconLbl);iconWrap.appendChild(iconRow);

  bd.appendChild(mkFw("Site name *", nameInp3));
  bd.appendChild(mkFw("Web address *", urlInp));
  bd.appendChild(mkFw("Description", descInp2));
  bd.appendChild(mkFw("Notes", notesInp2));
  bd.appendChild(mkFw("Category", catInp));
  bd.appendChild(iconWrap);
  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = w?"Save changes":"Add website";
  saveB.addEventListener("click", function(){
    var name = document.getElementById("w_name").value.trim();
    var url2 = document.getElementById("w_url").value.trim();
    if (!name || !url2) { toast("Please add a name and web address"); return; }
    var data = { name:name, url:url2, description:document.getElementById("w_desc").value.trim(), notes:document.getElementById("w_notes").value.trim(), category:document.getElementById("w_cat").value.trim()||"General", icon:selIcon };
    if (w && editIdx!==undefined) { data.id = w.id || ("WEB-"+Date.now()); websites[editIdx]=data; }
    else { data.id = "WEB-"+Date.now(); websites.push(data); }
    saveWebsites(); document.body.removeChild(overlay); renderWebsitesView();
    toast((w?"Website updated":"Website added")+" \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ nameInp3.focus(); }, 100);
}


// ── DOCS & SPECS ──────────────────────────────────────────────────
var DOCS_STORE = "spcrm_docs_v1";
var docs = [];

function loadDocs() {
  try { var r = localStorage.getItem(DOCS_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
// saveDocs handled by Supabase version above

function showDocs() {
  activeId = null; renderList(); showView("docs"); renderDocsView();
}

// ── TASKS / TO-DO ───────────────────────────────────────────────
var TASKS_STORE = "spcrm_tasks_v1";
var tasks = [];

var FOOTFALL_STORE = "spcrm_footfall_v1";
var footfallEntries = [];
function loadFootfallEntries() {
  try { var r = localStorage.getItem(FOOTFALL_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
function saveFootfallEntries() {
  try { localStorage.setItem(FOOTFALL_STORE, JSON.stringify(footfallEntries)); } catch(e) {}
  sbSaveAll("footfall_entries", footfallEntries, "id");
}

var FOOTFALL_WEATHER_OPTS = ["Sunny","Cloudy","Rain","Heavy Rain","Snow","Windy","Mixed"];
var ffEditingId = null;

function ffToUKDate(iso) {
  if (!iso) return "";
  var p = iso.split("-"); if (p.length!==3) return iso;
  return p[2]+"/"+p[1]+"/"+p[0];
}
function ffDayName(iso) {
  var d = new Date(iso+"T00:00:00");
  return ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][d.getDay()];
}
function ffTodayISO() {
  var d = new Date();
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}

function showFootfall() { activeId=null; renderList(); showView("footfall"); renderFootfallView(); }

function renderFootfallView() {
  var fv = document.getElementById("footfallView");
  fv.innerHTML = "";
  var wrap = document.createElement("div"); wrap.style.cssText = "max-width:960px";

  var hdr = document.createElement("div"); hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("h2"); title.style.cssText = "font-size:18px;font-weight:700"; title.textContent = "\uD83D\uDC63 Footfall Log";
  var ffPrintBtn = document.createElement("button"); ffPrintBtn.className = "no-print"; ffPrintBtn.style.cssText = "padding:8px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; ffPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print summary";
  ffPrintBtn.addEventListener("click", function(){ window.print(); });
  hdr.appendChild(title); hdr.appendChild(ffPrintBtn);
  wrap.appendChild(hdr);

  function mkCard(titleTxt, cls) {
    var card = document.createElement("div");
    card.className = cls || "";
    card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
    if (titleTxt) {
      var h = document.createElement("div");
      h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)";
      h.textContent = titleTxt;
      card.appendChild(h);
    }
    wrap.appendChild(card);
    return card;
  }

  // ── Entry form ──
  var c1 = mkCard(ffEditingId ? "Editing entry" : "Log today's footfall", "no-print");
  var formRow = document.createElement("div"); formRow.style.cssText = "display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:10px";

  function mkFld(labelTxt, inputEl) {
    var f = document.createElement("div"); f.style.cssText = "display:flex;flex-direction:column;gap:3px";
    var l = document.createElement("label"); l.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px"; l.textContent = labelTxt;
    f.appendChild(l); f.appendChild(inputEl);
    formRow.appendChild(f);
    return f;
  }

  var dateInp = document.createElement("input"); dateInp.type = "date"; dateInp.id = "ffDateInp"; dateInp.value = ffTodayISO();
  dateInp.style.cssText = "padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
  mkFld("Date", dateInp);

  var catInputs = {};
  FOOTFALL_CATS.forEach(function(cat, ci){
    var inp = document.createElement("input"); inp.type = "number"; inp.min = "0"; inp.placeholder = "0";
    inp.style.cssText = "width:70px;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
    catInputs[cat] = inp;
    mkFld(FOOTFALL_CATS_SHORT[ci], inp);
  });

  var weatherSel = document.createElement("select"); weatherSel.style.cssText = "padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
  var optBlank = document.createElement("option"); optBlank.value=""; optBlank.textContent="\u2014"; weatherSel.appendChild(optBlank);
  FOOTFALL_WEATHER_OPTS.forEach(function(w){ var o=document.createElement("option"); o.value=w; o.textContent=w; weatherSel.appendChild(o); });
  mkFld("Weather", weatherSel);

  var tempInp = document.createElement("input"); tempInp.type = "number"; tempInp.placeholder = "\u00b0C";
  tempInp.style.cssText = "width:60px;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
  mkFld("Temp \u00b0C", tempInp);

  var saveEntryBtn = document.createElement("button"); saveEntryBtn.style.cssText = "padding:8px 18px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer;height:34px";
  saveEntryBtn.textContent = ffEditingId ? "Update entry" : "Save entry";
  formRow.appendChild(saveEntryBtn);

  if (ffEditingId) {
    var cancelEditBtn = document.createElement("button"); cancelEditBtn.style.cssText = "padding:8px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer;height:34px";
    cancelEditBtn.textContent = "Cancel";
    cancelEditBtn.addEventListener("click", function(){ ffEditingId = null; renderFootfallView(); });
    formRow.appendChild(cancelEditBtn);
  }

  c1.appendChild(formRow);
  var formHint = document.createElement("div"); formHint.style.cssText = "font-size:10px;color:var(--muted)"; formHint.textContent = "Picking a date that already has an entry will load it here for editing instead of creating a duplicate.";
  c1.appendChild(formHint);

  function loadEntryIntoForm(entry) {
    dateInp.value = entry.date;
    FOOTFALL_CATS.forEach(function(cat){ catInputs[cat].value = entry.counts && entry.counts[cat] ? entry.counts[cat] : ""; });
    weatherSel.value = entry.weather || "";
    tempInp.value = (entry.temp===undefined||entry.temp===null) ? "" : entry.temp;
  }

  if (ffEditingId) {
    var existing = footfallEntries.filter(function(e){ return e.id===ffEditingId; })[0];
    if (existing) loadEntryIntoForm(existing);
  }

  dateInp.addEventListener("change", function(){
    var match = footfallEntries.filter(function(e){ return e.date===dateInp.value; })[0];
    if (match) { ffEditingId = match.id; renderFootfallView(); }
  });

  saveEntryBtn.addEventListener("click", function(){
    var dateVal = dateInp.value;
    if (!dateVal) { toast("Pick a date first"); return; }
    var counts = {};
    FOOTFALL_CATS.forEach(function(cat){ counts[cat] = parseFloat(catInputs[cat].value)||0; });
    var id = ffEditingId || ("FF-"+dateVal);
    var existingIdx = footfallEntries.findIndex(function(e){ return e.id===id; });
    var entry = { id:id, date:dateVal, counts:counts, weather:weatherSel.value||"", temp: tempInp.value===""?null:parseFloat(tempInp.value) };
    if (existingIdx>-1) footfallEntries[existingIdx] = entry; else footfallEntries.push(entry);
    saveFootfallEntries();
    ffEditingId = null;
    toast("Footfall entry saved \u2713");
    renderFootfallView();
  });

  // ── Recent entries ──
  var c2 = mkCard("Recent entries");
  var sorted = footfallEntries.slice().sort(function(a,b){ return b.date.localeCompare(a.date); });
  if (!sorted.length) {
    var noEntries = document.createElement("div"); noEntries.style.cssText = "font-size:12px;color:var(--muted)"; noEntries.textContent = "No footfall logged yet \u2014 use the form above to add your first day.";
    c2.appendChild(noEntries);
  } else {
    var tblWrap = document.createElement("div"); tblWrap.style.cssText = "overflow-x:auto;max-height:340px;overflow-y:auto";
    var tbl = document.createElement("table"); tbl.style.cssText = "border-collapse:collapse;width:100%;font-size:11px";
    var thead = document.createElement("thead"); var htr = document.createElement("tr");
    ["Date","Day"].concat(FOOTFALL_CATS_SHORT).concat(["Total","Weather","Temp","",""]).forEach(function(h){
      var th = document.createElement("th"); th.style.cssText = "padding:6px 7px;text-align:left;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--muted);border-bottom:2px solid var(--border);white-space:nowrap;position:sticky;top:0;background:var(--surface)"; th.textContent = h; htr.appendChild(th);
    });
    thead.appendChild(htr); tbl.appendChild(thead);
    var tbody = document.createElement("tbody");
    sorted.forEach(function(entry){
      var tr = document.createElement("tr"); tr.style.cssText = "border-bottom:1px solid var(--border)";
      var total = FOOTFALL_CATS.reduce(function(s,cat){ return s+(entry.counts&&entry.counts[cat]?entry.counts[cat]:0); },0);
      var tdDate = document.createElement("td"); tdDate.style.cssText = "padding:5px 7px;white-space:nowrap"; tdDate.textContent = ffToUKDate(entry.date); tr.appendChild(tdDate);
      var tdDay = document.createElement("td"); tdDay.style.cssText = "padding:5px 7px"; tdDay.textContent = ffDayName(entry.date); tr.appendChild(tdDay);
      FOOTFALL_CATS.forEach(function(cat){ var td=document.createElement("td"); td.style.cssText="padding:5px 7px;text-align:center"; td.textContent = (entry.counts&&entry.counts[cat])?entry.counts[cat]:0; tr.appendChild(td); });
      var tdTot = document.createElement("td"); tdTot.style.cssText = "padding:5px 7px;font-weight:700;color:var(--navy)"; tdTot.textContent = total; tr.appendChild(tdTot);
      var tdW = document.createElement("td"); tdW.style.cssText = "padding:5px 7px"; tdW.textContent = entry.weather||"\u2014"; tr.appendChild(tdW);
      var tdT = document.createElement("td"); tdT.style.cssText = "padding:5px 7px"; tdT.textContent = (entry.temp===null||entry.temp===undefined)?"\u2014":entry.temp+"\u00b0"; tr.appendChild(tdT);
      var tdEdit = document.createElement("td"); tdEdit.className="no-print"; tdEdit.style.cssText = "padding:5px 4px";
      var editBtn = document.createElement("button"); editBtn.textContent="\u270E"; editBtn.style.cssText = "background:none;border:1px solid var(--border);border-radius:var(--rs);cursor:pointer;padding:3px 7px;color:var(--muted)";
      editBtn.addEventListener("click", (function(id){ return function(){ ffEditingId=id; renderFootfallView(); window.scrollTo(0,0); }; })(entry.id));
      tdEdit.appendChild(editBtn); tr.appendChild(tdEdit);
      var tdDel = document.createElement("td"); tdDel.className="no-print"; tdDel.style.cssText = "padding:5px 4px";
      var delBtn = document.createElement("button"); delBtn.textContent="\u00d7"; delBtn.style.cssText = "background:none;border:none;color:var(--muted);font-size:14px;cursor:pointer;padding:3px 6px";
      delBtn.addEventListener("click", (function(id){ return function(){ if(confirm("Delete this day's entry?")){ footfallEntries=footfallEntries.filter(function(e){return e.id!==id;}); sbDelete("footfall_entries", id); saveFootfallEntries(); renderFootfallView(); toast("Deleted"); } }; })(entry.id));
      tdDel.appendChild(delBtn); tr.appendChild(tdDel);
      tbody.appendChild(tr);
    });
    tbl.appendChild(tbody); tblWrap.appendChild(tbl); c2.appendChild(tblWrap);
  }

  // ── Analysis ──
  if (sorted.length) {
    var c3 = mkCard(null, "no-print");
    var rangeLbl = document.createElement("div"); rangeLbl.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:9px"; rangeLbl.textContent = "Analyze:";
    c3.appendChild(rangeLbl);
    var rangeRow = document.createElement("div"); rangeRow.style.cssText = "display:flex;gap:6px;flex-wrap:wrap";
    c3.appendChild(rangeRow);

    var ranges = [["All time",null],["This year",365],["Last 3 months",90],["This month",30]];
    ranges.forEach(function(r, ri){
      var btn = document.createElement("button"); btn.textContent = r[0];
      btn.style.cssText = "padding:5px 12px;border-radius:20px;border:2px solid "+(ri===0?"var(--navy)":"var(--border)")+";background:"+(ri===0?"var(--navy)":"var(--surface)")+";color:"+(ri===0?"#fff":"var(--muted)")+";font-size:11px;font-weight:700;cursor:pointer";
      btn.addEventListener("click", function(){
        Array.from(rangeRow.children).forEach(function(b){ b.style.background="var(--surface)"; b.style.color="var(--muted)"; b.style.borderColor="var(--border)"; });
        btn.style.background="var(--navy)"; btn.style.color="#fff"; btn.style.borderColor="var(--navy)";
        renderFootfallAnalysis(r[1]);
      });
      rangeRow.appendChild(btn);
    });

    var analysisResults = document.createElement("div"); analysisResults.id = "ffAnalysisResults";
    wrap.appendChild(analysisResults);

    function renderFootfallAnalysis(days) {
      analysisResults.innerHTML = "";
      var cutoff = days ? (function(){ var d=new Date(); d.setDate(d.getDate()-days); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0"); })() : null;
      var filtered = sorted.filter(function(e){ return !cutoff || e.date>=cutoff; }).slice().sort(function(a,b){ return a.date.localeCompare(b.date); });
      if (!filtered.length) {
        var none = document.createElement("div"); none.style.cssText="font-size:12px;color:var(--muted);padding:10px"; none.textContent="No entries in this range."; analysisResults.appendChild(none); return;
      }

      var catSeries = FOOTFALL_CATS.map(function(cat){ return filtered.map(function(e){ return (e.counts&&e.counts[cat])||0; }); });
      var catTotals = catSeries.map(function(s){ return s.reduce(function(a,b){return a+b;},0); });
      var grandTotal = catTotals.reduce(function(a,b){return a+b;},0);

      // Category share
      var r1 = document.createElement("div"); r1.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r1h = document.createElement("div"); r1h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r1h.textContent = "Category share \u2014 "+filtered.length+" day"+(filtered.length===1?"":"s")+", "+grandTotal.toLocaleString("en-GB")+" total";
      r1.appendChild(r1h);
      if (grandTotal>0) {
        var pieWrap = document.createElement("div"); pieWrap.style.cssText = "height:230px;position:relative";
        var pieCan = document.createElement("canvas"); pieCan.id = "ffLogPieCh"; pieWrap.appendChild(pieCan);
        r1.appendChild(pieWrap);
      }
      analysisResults.appendChild(r1);

      // Weekly trend (group by ISO week start)
      var weekMap = {};
      filtered.forEach(function(e){
        var d = new Date(e.date+"T00:00:00");
        var dow = (d.getDay()+6)%7; // Mon=0
        var monday = new Date(d); monday.setDate(d.getDate()-dow);
        var wk = monday.getFullYear()+"-"+String(monday.getMonth()+1).padStart(2,"0")+"-"+String(monday.getDate()).padStart(2,"0");
        var total = FOOTFALL_CATS.reduce(function(s,cat){ return s+((e.counts&&e.counts[cat])||0); },0);
        weekMap[wk] = (weekMap[wk]||0) + total;
      });
      var weekKeys = Object.keys(weekMap).sort();
      var r2 = document.createElement("div"); r2.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r2h = document.createElement("div"); r2h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r2h.textContent = "Weekly total footfall";
      r2.appendChild(r2h);
      var wTrendWrap = document.createElement("div"); wTrendWrap.style.cssText = "height:190px;position:relative";
      var wTrendCan = document.createElement("canvas"); wTrendCan.id = "ffLogWeekCh"; wTrendWrap.appendChild(wTrendCan);
      r2.appendChild(wTrendWrap);
      analysisResults.appendChild(r2);

      // Monthly trend
      var monthMap = {};
      filtered.forEach(function(e){
        var mk = e.date.slice(0,7);
        var total = FOOTFALL_CATS.reduce(function(s,cat){ return s+((e.counts&&e.counts[cat])||0); },0);
        monthMap[mk] = (monthMap[mk]||0) + total;
      });
      var monthKeys = Object.keys(monthMap).sort();
      var monthLabelsShort = monthKeys.map(function(mk){ var p=mk.split("-"); return ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][parseInt(p[1])-1]+" "+p[0].slice(2); });
      var r3 = document.createElement("div"); r3.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r3h = document.createElement("div"); r3h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r3h.textContent = "Monthly total footfall";
      r3.appendChild(r3h);
      var mTrendWrap = document.createElement("div"); mTrendWrap.style.cssText = "height:190px;position:relative";
      var mTrendCan = document.createElement("canvas"); mTrendCan.id = "ffLogMonthCh"; mTrendWrap.appendChild(mTrendCan);
      r3.appendChild(mTrendWrap);
      analysisResults.appendChild(r3);

      // Weekday pattern
      var wdTotals = [0,0,0,0,0,0,0]; var wdCounts = [0,0,0,0,0,0,0];
      filtered.forEach(function(e){
        var d = new Date(e.date+"T00:00:00"); var dow=(d.getDay()+6)%7;
        var total = FOOTFALL_CATS.reduce(function(s,cat){ return s+((e.counts&&e.counts[cat])||0); },0);
        wdTotals[dow]+=total; wdCounts[dow]++;
      });
      var wdLabels = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
      var wdAverages = wdTotals.map(function(t,i){ return wdCounts[i]>0 ? Math.round((t/wdCounts[i])*10)/10 : 0; });
      var r4 = document.createElement("div"); r4.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r4h = document.createElement("div"); r4h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r4h.textContent = "Average footfall by day of the week";
      r4.appendChild(r4h);
      var wdWrap = document.createElement("div"); wdWrap.style.cssText = "height:190px;position:relative";
      var wdCan = document.createElement("canvas"); wdCan.id = "ffLogWeekdayCh"; wdWrap.appendChild(wdCan);
      r4.appendChild(wdWrap);
      analysisResults.appendChild(r4);

      // Per-category weekday breakdown table
      var catWdTotals = FOOTFALL_CATS.map(function(){ return [0,0,0,0,0,0,0]; });
      var catWdCounts = [0,0,0,0,0,0,0];
      filtered.forEach(function(e){
        var d = new Date(e.date+"T00:00:00"); var dow=(d.getDay()+6)%7;
        catWdCounts[dow]++;
        FOOTFALL_CATS.forEach(function(cat,ci){ catWdTotals[ci][dow] += (e.counts&&e.counts[cat])||0; });
      });
      var r4b = document.createElement("div"); r4b.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px;overflow-x:auto";
      var r4bh = document.createElement("div"); r4bh.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r4bh.textContent = "Average footfall by day \u2014 per category";
      r4b.appendChild(r4bh);
      var wdTbl = document.createElement("table"); wdTbl.style.cssText = "border-collapse:collapse;width:100%;font-size:11px";
      var wdThead = document.createElement("thead"); var wdHtr = document.createElement("tr");
      ["Category"].concat(wdLabels).concat(["Busiest day"]).forEach(function(h){
        var th = document.createElement("th"); th.style.cssText = "padding:6px 8px;text-align:"+(h==="Category"?"left":"center")+";font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--muted);border-bottom:2px solid var(--border);white-space:nowrap"; th.textContent = h; wdHtr.appendChild(th);
      });
      wdThead.appendChild(wdHtr); wdTbl.appendChild(wdThead);
      var wdTbody = document.createElement("tbody");
      FOOTFALL_CATS.forEach(function(cat,ci){
        var tr = document.createElement("tr"); tr.style.cssText = "border-bottom:1px solid var(--border)";
        var tdName = document.createElement("td"); tdName.style.cssText = "padding:5px 8px;font-weight:700"; tdName.textContent = FOOTFALL_CATS_SHORT[ci]; tr.appendChild(tdName);
        var rowAvgs = wdLabels.map(function(_,di){ return catWdCounts[di]>0 ? Math.round((catWdTotals[ci][di]/catWdCounts[di])*10)/10 : 0; });
        var maxAvg = Math.max.apply(null, rowAvgs);
        rowAvgs.forEach(function(v){
          var td = document.createElement("td"); td.style.cssText = "padding:5px 8px;text-align:center"+(v===maxAvg && maxAvg>0 ? ";font-weight:700;color:var(--navy);background:var(--alt)" : "");
          td.textContent = v; tr.appendChild(td);
        });
        var tdBusy = document.createElement("td"); tdBusy.style.cssText = "padding:5px 8px;text-align:center;font-weight:700";
        tdBusy.textContent = maxAvg>0 ? wdLabels[rowAvgs.indexOf(maxAvg)] : "\u2014";
        tr.appendChild(tdBusy);
        wdTbody.appendChild(tr);
      });
      wdTbl.appendChild(wdTbody); r4b.appendChild(wdTbl);
      analysisResults.appendChild(r4b);

      // Patterns spotted (correlation)
      var r5 = document.createElement("div"); r5.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r5h = document.createElement("div"); r5h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r5h.textContent = "Patterns between categories";
      r5.appendChild(r5h);
      if (filtered.length < 3) {
        var need = document.createElement("div"); need.style.cssText="font-size:12px;color:var(--muted)"; need.textContent="Add at least 3 days in this range to see which categories move together."; r5.appendChild(need);
      } else {
        var pairs = [];
        for (var a=0;a<FOOTFALL_CATS.length;a++) for (var b=a+1;b<FOOTFALL_CATS.length;b++) {
          var rr = pearsonCorr(catSeries[a], catSeries[b]);
          if (rr!==null) pairs.push({a:FOOTFALL_CATS[a], b:FOOTFALL_CATS[b], r:rr});
        }
        pairs.sort(function(x,y){ return Math.abs(y.r)-Math.abs(x.r); });
        var top = pairs.slice(0,5);
        if (!top.length) {
          var flat = document.createElement("div"); flat.style.cssText="font-size:12px;color:var(--muted)"; flat.textContent="Not enough variation yet to spot a pattern."; r5.appendChild(flat);
        } else {
          top.forEach(function(p){
            var strength = Math.abs(p.r);
            var word = strength>=0.7?"strongly":strength>=0.4?"moderately":"weakly";
            var dir = p.r>=0?"rise and fall together":"move in opposite directions";
            var rowEl = document.createElement("div"); rowEl.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)";
            var left = document.createElement("div"); left.style.cssText="font-size:12px;color:var(--text);max-width:70%"; left.innerHTML = "<strong>"+p.a+"</strong> and <strong>"+p.b+"</strong> "+word+" "+dir;
            var right = document.createElement("div"); right.style.cssText = "font-size:12px;font-weight:700;color:"+(p.r>=0?"var(--gtxt)":"#b23a2e"); right.textContent = "r="+p.r.toFixed(2);
            rowEl.appendChild(left); rowEl.appendChild(right); r5.appendChild(rowEl);
          });
        }
      }
      analysisResults.appendChild(r5);

      // Full correlation matrix (heat-map style)
      if (filtered.length >= 3) {
        var r5b = document.createElement("div"); r5b.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px;overflow-x:auto";
        var r5bh = document.createElement("div"); r5bh.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r5bh.textContent = "Full correlation matrix";
        r5b.appendChild(r5bh);
        var mHint = document.createElement("div"); mHint.style.cssText = "font-size:10px;color:var(--muted);margin-bottom:10px"; mHint.textContent = "Blue = rise and fall together. Orange = move in opposite directions. Deeper colour = stronger relationship.";
        r5b.appendChild(mHint);
        var mTbl = document.createElement("table"); mTbl.style.cssText = "border-collapse:collapse;font-size:10px";
        var mThead = document.createElement("tr");
        var blankTh = document.createElement("th"); blankTh.style.cssText = "padding:5px"; mThead.appendChild(blankTh);
        FOOTFALL_CATS_SHORT.forEach(function(s){ var th=document.createElement("th"); th.style.cssText="padding:5px 7px;font-size:9px;font-weight:700;color:var(--muted);white-space:nowrap;writing-mode:vertical-rl;text-orientation:mixed;max-height:90px"; th.textContent=s; mThead.appendChild(th); });
        mTbl.appendChild(mThead);
        FOOTFALL_CATS.forEach(function(catA, ia){
          var tr = document.createElement("tr");
          var rowTh = document.createElement("th"); rowTh.style.cssText = "padding:5px 8px;font-size:9px;font-weight:700;color:var(--muted);text-align:left;white-space:nowrap"; rowTh.textContent = FOOTFALL_CATS_SHORT[ia];
          tr.appendChild(rowTh);
          FOOTFALL_CATS.forEach(function(catB, ib){
            var td = document.createElement("td"); td.style.cssText = "padding:6px 9px;text-align:center;font-weight:700";
            var rVal = ia===ib ? 1 : pearsonCorr(catSeries[ia], catSeries[ib]);
            if (rVal===null) { td.textContent = "\u2014"; td.style.color = "var(--muted)"; }
            else {
              td.textContent = rVal.toFixed(2);
              var alpha = Math.min(1, Math.abs(rVal)) * 0.75;
              td.style.background = rVal>=0 ? "rgba(31,119,180,"+alpha+")" : "rgba(213,94,0,"+alpha+")";
              td.style.color = Math.abs(rVal)>0.5 ? "#fff" : "var(--text)";
            }
            tr.appendChild(td);
          });
          mTbl.appendChild(tr);
        });
        r5b.appendChild(mTbl);
        analysisResults.appendChild(r5b);
      }

      // Weather pattern
      var withWeather = filtered.filter(function(e){ return e.weather; });
      var r6 = document.createElement("div"); r6.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px";
      var r6h = document.createElement("div"); r6h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r6h.textContent = "Footfall vs weather";
      r6.appendChild(r6h);
      if (!withWeather.length) {
        var noWx = document.createElement("div"); noWx.style.cssText="font-size:12px;color:var(--muted)"; noWx.textContent="No weather logged yet for this range \u2014 add weather when logging a day to see this."; r6.appendChild(noWx);
      } else {
        var wxMap = {};
        withWeather.forEach(function(e){
          var total = FOOTFALL_CATS.reduce(function(s,cat){ return s+((e.counts&&e.counts[cat])||0); },0);
          if (!wxMap[e.weather]) wxMap[e.weather] = {sum:0,n:0};
          wxMap[e.weather].sum += total; wxMap[e.weather].n++;
        });
        var wxLabels = Object.keys(wxMap);
        var wxAvgs = wxLabels.map(function(w){ return Math.round((wxMap[w].sum/wxMap[w].n)*10)/10; });
        var wxWrap = document.createElement("div"); wxWrap.style.cssText = "height:190px;position:relative";
        var wxCan = document.createElement("canvas"); wxCan.id = "ffLogWeatherCh"; wxWrap.appendChild(wxCan);
        r6.appendChild(wxWrap);
        var withTemp = filtered.filter(function(e){ return e.temp!==null && e.temp!==undefined; });
        if (withTemp.length>=3) {
          var temps = withTemp.map(function(e){ return e.temp; });
          var totals2 = withTemp.map(function(e){ return FOOTFALL_CATS.reduce(function(s,cat){ return s+((e.counts&&e.counts[cat])||0); },0); });
          var tCorr = pearsonCorr(temps, totals2);
          var tDiv = document.createElement("div"); tDiv.style.cssText = "font-size:12px;color:var(--text);margin-top:10px;padding-top:10px;border-top:1px solid var(--border)";
          tDiv.innerHTML = "Temperature correlation: <strong>"+(tCorr===null?"n/a":tCorr.toFixed(2))+"</strong> \u2014 "+(tCorr===null?"not enough variation yet.":(tCorr>=0?"footfall tends to rise on warmer days.":"footfall tends to rise on colder days."));
          r6.appendChild(tDiv);
        }
        setTimeout(function(){ mkFootfallWeatherChart("ffLogWeatherCh", wxLabels, wxAvgs); }, 30);
      }
      analysisResults.appendChild(r6);

      // Best & worst day per category
      var r7 = document.createElement("div"); r7.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:14px;overflow-x:auto";
      var r7h = document.createElement("div"); r7h.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid var(--border)"; r7h.textContent = "Best & worst day per category";
      r7.appendChild(r7h);
      var bwTbl = document.createElement("table"); bwTbl.style.cssText = "border-collapse:collapse;width:100%;font-size:11px";
      var bwThead = document.createElement("tr");
      ["Category","Best day","Best total","Worst day","Worst total"].forEach(function(h){
        var th = document.createElement("th"); th.style.cssText = "padding:6px 8px;text-align:"+(h==="Category"?"left":"center")+";font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--muted);border-bottom:2px solid var(--border);white-space:nowrap"; th.textContent = h; bwThead.appendChild(th);
      });
      bwTbl.appendChild(bwThead);
      FOOTFALL_CATS.forEach(function(cat,ci){
        var series = catSeries[ci];
        var maxV = Math.max.apply(null, series); var minV = Math.min.apply(null, series);
        var maxIdx = series.indexOf(maxV); var minIdx = series.indexOf(minV);
        var tr = document.createElement("tr"); tr.style.cssText = "border-bottom:1px solid var(--border)";
        var tdName = document.createElement("td"); tdName.style.cssText = "padding:5px 8px;font-weight:700"; tdName.textContent = FOOTFALL_CATS_SHORT[ci]; tr.appendChild(tdName);
        if (maxV<=0) {
          var tdNone = document.createElement("td"); tdNone.colSpan=4; tdNone.style.cssText="padding:5px 8px;text-align:center;color:var(--muted)"; tdNone.textContent="No data yet"; tr.appendChild(tdNone);
        } else {
          var tdBD = document.createElement("td"); tdBD.style.cssText="padding:5px 8px;text-align:center"; tdBD.textContent = ffToUKDate(filtered[maxIdx].date); tr.appendChild(tdBD);
          var tdBT = document.createElement("td"); tdBT.style.cssText="padding:5px 8px;text-align:center;font-weight:700;color:var(--gtxt)"; tdBT.textContent = maxV; tr.appendChild(tdBT);
          var tdWD = document.createElement("td"); tdWD.style.cssText="padding:5px 8px;text-align:center"; tdWD.textContent = ffToUKDate(filtered[minIdx].date); tr.appendChild(tdWD);
          var tdWT = document.createElement("td"); tdWT.style.cssText="padding:5px 8px;text-align:center;font-weight:700;color:#b23a2e"; tdWT.textContent = minV; tr.appendChild(tdWT);
        }
        bwTbl.appendChild(tr);
      });
      r7.appendChild(bwTbl);
      analysisResults.appendChild(r7);

      setTimeout(function(){
        if (grandTotal>0) mkFootfallPieChart("ffLogPieCh", FOOTFALL_CATS, catTotals);
        mkFootfallTrendChart("ffLogWeekCh", weekKeys.map(function(k){ return ffToUKDate(k); }), weekKeys.map(function(k){ return weekMap[k]; }));
        mkFootfallTrendChart("ffLogMonthCh", monthLabelsShort, monthKeys.map(function(k){ return monthMap[k]; }));
        mkFootfallTrendChart("ffLogWeekdayCh", wdLabels, wdAverages);
      }, 30);
    }

    renderFootfallAnalysis(null);
  }

  fv.appendChild(wrap);
}

function mkFootfallWeatherChart(id, labels, values) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var cfg = {
    type: "bar",
    data: { labels: labels, datasets: [{ label: "Avg footfall", data: values, backgroundColor: "#0072B2", borderRadius: 5 }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}

function loadTasks() {
  try { var r = localStorage.getItem(TASKS_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
function saveTasks() {
  try { localStorage.setItem(TASKS_STORE, JSON.stringify(tasks)); } catch(e) {}
  sbSaveAll("tasks", tasks, "id");
}

var taskFilter = "Active";

function showTasks() {
  activeId = null; renderList(); showView("tasks"); renderTasksView();
}

function renderTasksView() {
  var tv = document.getElementById("tasksView");
  tv.innerHTML = "";

  var hdr = document.createElement("div"); hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:6px";
  var title = document.createElement("h2"); title.style.cssText = "font-size:18px;font-weight:700"; title.textContent = "To-Do";
  var addBtn = document.createElement("button"); addBtn.style.cssText = "padding:8px 16px;background:#3498db;border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; addBtn.textContent = "+ Add task";
  addBtn.addEventListener("click", showTaskForm);
  var taskPrintBtn = document.createElement("button"); taskPrintBtn.className = "no-print"; taskPrintBtn.style.cssText = "padding:8px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; taskPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print all visible";
  taskPrintBtn.addEventListener("click", function(){ window.print(); });
  hdr.appendChild(title); hdr.appendChild(taskPrintBtn); hdr.appendChild(addBtn); tv.appendChild(hdr);

  var sub = document.createElement("div"); sub.style.cssText = "font-size:12px;color:var(--muted);margin-bottom:14px"; sub.textContent = "Shop tasks and client-linked tasks in one place.";
  tv.appendChild(sub);

  var filterRow = document.createElement("div"); filterRow.style.cssText = "display:flex;gap:6px;margin-bottom:16px";
  ["Active","Done","All"].forEach(function(f){
    var btn = document.createElement("button");
    var count = f==="All" ? tasks.length : tasks.filter(function(t){ return (t.done?"Done":"Active")===f; }).length;
    btn.textContent = f + " (" + count + ")";
    btn.style.cssText = "padding:5px 13px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid "+(taskFilter===f?"#3498db":"var(--border)")+";background:"+(taskFilter===f?"#3498db":"var(--surface)")+";color:"+(taskFilter===f?"#fff":"var(--muted)");
    btn.addEventListener("click", function(){ taskFilter = f; renderTasksView(); });
    filterRow.appendChild(btn);
  });
  tv.appendChild(filterRow);

  var visible = tasks.filter(function(t){
    if (taskFilter === "All") return true;
    return (t.done?"Done":"Active") === taskFilter;
  });

  if (!visible.length) {
    var empty = document.createElement("div"); empty.style.cssText = "text-align:center;padding:40px 20px;color:var(--muted);font-size:13px"; empty.textContent = taskFilter==="Done" ? "Nothing completed yet." : "Nothing here.";
    tv.appendChild(empty);
    return;
  }

  visible.slice().sort(function(a,b){
    if (!!a.done !== !!b.done) return a.done ? 1 : -1;
    return (b.created||0) - (a.created||0);
  }).forEach(function(t){
    var card = document.createElement("div"); card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px;margin-bottom:8px;display:flex;align-items:flex-start;gap:10px"+(t.done?";opacity:.6":"");
    var chk = document.createElement("button"); chk.style.cssText = "width:22px;height:22px;border-radius:50%;border:2px solid "+(t.done?"#1a5c1a":"#3498db")+";background:"+(t.done?"#1a5c1a":"transparent")+";color:#fff;font-size:12px;cursor:pointer;flex-shrink:0;display:flex;align-items:center;justify-content:center;padding:0"; chk.textContent = t.done ? "\u2713" : "";
    chk.addEventListener("click", function(){
      t.done = !t.done;
      t.completedDate = t.done ? fd2date() : "";
      saveTasks();
      renderTasksView();
      renderDash();
      toast(t.done ? "Marked done \u2713" : "Reopened");
    });
    var left = document.createElement("div"); left.style.flex = "1";
    var topRow = document.createElement("div"); topRow.style.cssText = "display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:2px";
    var textEl = document.createElement("span"); textEl.style.cssText = "font-size:14px;font-weight:600"+(t.done?";text-decoration:line-through":""); textEl.textContent = t.text;
    topRow.appendChild(textEl);
    if (t.clientId) {
      var cTag = document.createElement("span"); cTag.style.cssText = "font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;background:var(--lbg);color:var(--ltxt);cursor:pointer"; cTag.textContent = t.clientName||"Client";
      cTag.addEventListener("click", function(){ openC(t.clientId); });
      topRow.appendChild(cTag);
    } else if (t.repId) {
      var rTag = document.createElement("span"); rTag.style.cssText = "font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;background:#f0e6f7;color:#9b59b6;cursor:pointer"; rTag.textContent = "\uD83E\uDD1D "+(t.repName||"Rep");
      rTag.addEventListener("click", function(){ showReps(); });
      topRow.appendChild(rTag);
    } else {
      var sTag = document.createElement("span"); sTag.style.cssText = "font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;background:var(--alt);color:var(--muted)"; sTag.textContent = "Shop";
      topRow.appendChild(sTag);
    }
    left.appendChild(topRow);
    var meta = document.createElement("div"); meta.style.cssText = "font-size:10px;color:var(--muted)"; meta.textContent = t.done ? "Done "+(t.completedDate||"") : "Added "+(t.createdDate||"");
    left.appendChild(meta);

    var delBtn = document.createElement("button"); delBtn.style.cssText = "padding:4px 9px;background:var(--rbg);border:1px solid var(--rtxt);border-radius:var(--rs);color:var(--rtxt);font-size:10px;font-weight:700;cursor:pointer;flex-shrink:0"; delBtn.textContent = "Delete";
    delBtn.addEventListener("click", function(){
      if (confirm("Delete this task?")) {
        tasks = tasks.filter(function(x){ return x.id!==t.id; });
        sbDelete("tasks", t.id);
        saveTasks();
        renderTasksView();
        renderDash();
        toast("Deleted \u2713");
      }
    });
    var taskCardPrintBtn = document.createElement("button"); taskCardPrintBtn.className = "no-print"; taskCardPrintBtn.style.cssText = "padding:4px 9px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:10px;font-weight:700;cursor:pointer;flex-shrink:0"; taskCardPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print";
    taskCardPrintBtn.addEventListener("click", (function(cardEl){ return function(){ isolatePrintEl(cardEl, null); }; })(card));
    card.appendChild(chk); card.appendChild(left); card.appendChild(taskCardPrintBtn); card.appendChild(delBtn);
    tv.appendChild(card);
  });
}

function fd2date() {
  var d = new Date();
  return String(d.getDate()).padStart(2,"0")+"/"+String(d.getMonth()+1).padStart(2,"0")+"/"+d.getFullYear();
}

function showTaskForm() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px";

  var bh = document.createElement("div"); bh.style.cssText = "background:#3498db;padding:14px 18px";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:15px;font-weight:700;color:#fff"; bht.textContent = "\u2705 Add task";
  bh.appendChild(bht); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:12px";

  function mkFd3(lbl, inp) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp); return w; }

  var textInp = document.createElement("input"); textInp.id="task_text"; textInp.placeholder="What needs doing?"; textInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd3("Task *", textInp));

  var typeLbl = document.createElement("label"); typeLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:5px"; typeLbl.textContent = "Type";
  var typeWrap = document.createElement("div"); typeWrap.style.cssText = "display:flex;gap:6px";
  var btnShop = document.createElement("button"); btnShop.type="button"; btnShop.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;border-radius:var(--rs);background:#3498db;color:#fff"; btnShop.textContent = "\uD83C\uDFEA Shop";
  var btnClient3 = document.createElement("button"); btnClient3.type="button"; btnClient3.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;border-radius:var(--rs);background:var(--surface);color:var(--muted);border:2px solid var(--border)"; btnClient3.textContent = "\uD83D\uDC64 Client";
  var btnRep = document.createElement("button"); btnRep.type="button"; btnRep.style.cssText = "flex:1;padding:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;border-radius:var(--rs);background:var(--surface);color:var(--muted);border:2px solid var(--border)"; btnRep.textContent = "\uD83E\uDD1D Rep/ASM";
  typeWrap.appendChild(btnShop); typeWrap.appendChild(btnClient3); typeWrap.appendChild(btnRep);
  var typeWrapOuter = document.createElement("div"); typeWrapOuter.appendChild(typeLbl); typeWrapOuter.appendChild(typeWrap);
  bd.appendChild(typeWrapOuter);

  var clientWrap = document.createElement("div"); clientWrap.style.display = "none";
  var clientLbl = document.createElement("label"); clientLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; clientLbl.textContent = "Client";
  var clientSel = document.createElement("select"); clientSel.id="task_client"; clientSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  var blankOpt3 = document.createElement("option"); blankOpt3.value=""; blankOpt3.textContent="-- Select client --"; clientSel.appendChild(blankOpt3);
  clients.slice().sort(function(a,b){ return (a.name||"").localeCompare(b.name||""); }).forEach(function(c){
    var o = document.createElement("option"); o.value=c.id; o.textContent=c.name; clientSel.appendChild(o);
  });
  clientWrap.appendChild(clientLbl); clientWrap.appendChild(clientSel);
  bd.appendChild(clientWrap);

  var repWrap = document.createElement("div"); repWrap.style.display = "none";
  var repLbl = document.createElement("label"); repLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; repLbl.textContent = "Rep/ASM";
  var repSel = document.createElement("select"); repSel.id="task_rep"; repSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  var blankOpt4 = document.createElement("option"); blankOpt4.value=""; blankOpt4.textContent="-- Select rep --"; repSel.appendChild(blankOpt4);
  reps.slice().sort(function(a,b){ return (a.name||"").localeCompare(b.name||""); }).forEach(function(r){
    var o = document.createElement("option"); o.value=r.id; o.textContent=r.name; repSel.appendChild(o);
  });
  repWrap.appendChild(repLbl); repWrap.appendChild(repSel);
  bd.appendChild(repWrap);

  var currentTaskType = "shop";
  function setTaskType(t) {
    currentTaskType = t;
    btnShop.style.background = t==="shop"?"#3498db":"var(--surface)"; btnShop.style.color = t==="shop"?"#fff":"var(--muted)"; btnShop.style.border = t==="shop"?"none":"1px solid var(--border)";
    btnClient3.style.background = t==="client"?"#3498db":"var(--surface)"; btnClient3.style.color = t==="client"?"#fff":"var(--muted)"; btnClient3.style.border = t==="client"?"none":"1px solid var(--border)";
    btnRep.style.background = t==="rep"?"#3498db":"var(--surface)"; btnRep.style.color = t==="rep"?"#fff":"var(--muted)"; btnRep.style.border = t==="rep"?"none":"1px solid var(--border)";
    clientWrap.style.display = t==="client" ? "block" : "none";
    repWrap.style.display = t==="rep" ? "block" : "none";
  }
  btnShop.addEventListener("click", function(){ setTaskType("shop"); });
  btnClient3.addEventListener("click", function(){ setTaskType("client"); });
  btnRep.addEventListener("click", function(){ setTaskType("rep"); });

  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:8px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:8px 18px;background:#3498db;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Save task";
  saveB.addEventListener("click", function(){
    var text = textInp.value.trim();
    if (!text) { toast("Please enter a task"); return; }
    var clientId = "", clientName = "", repId = "", repName = "";
    if (currentTaskType === "client") {
      clientId = clientSel.value;
      if (!clientId) { toast("Please select a client"); return; }
      var matchedClient = clients.find(function(c){ return c.id===clientId; });
      clientName = matchedClient ? matchedClient.name : "";
    } else if (currentTaskType === "rep") {
      repId = repSel.value;
      if (!repId) { toast("Please select a rep"); return; }
      var matchedRep = reps.find(function(r){ return r.id===repId; });
      repName = matchedRep ? matchedRep.name : "";
    }
    tasks.push({
      id: "TASK-"+Date.now(),
      text: text,
      clientId: clientId,
      clientName: clientName,
      repId: repId,
      repName: repName,
      done: false,
      created: Date.now(),
      createdDate: fd2date()
    });
    saveTasks();
    document.body.removeChild(overlay);
    renderTasksView();
    renderDash();
    toast("Task added \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ textInp.focus(); }, 100);
}

// ── ENQUIRIES (things asked for that we don't stock) ──────────────
var ENQ_STORE = "spcrm_enquiries_v1";
var enquiries = [];

function loadEnquiries() {
  try { var r = localStorage.getItem(ENQ_STORE); if (r) return JSON.parse(r); } catch(e) {}
  return [];
}
function saveEnquiries() {
  try { localStorage.setItem(ENQ_STORE, JSON.stringify(enquiries)); } catch(e) {}
  sbSaveAll("enquiries", enquiries, "id");
}

function showEnquiries() {
  activeId = null; renderList(); showView("enquiries"); renderEnquiriesView();
}

function normaliseEnqText(s) {
  return (s||"").toLowerCase().trim().replace(/[^a-z0-9 ]/g,"").replace(/\s+/g," ");
}

var enqFilter = "Active";

function renderEnquiriesView() {
  var ev = document.getElementById("enquiriesView");
  ev.innerHTML = "";

  var hdr = document.createElement("div"); hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:6px";
  var title = document.createElement("h2"); title.style.cssText = "font-size:18px;font-weight:700"; title.textContent = "Enquiries";
  var addBtn = document.createElement("button"); addBtn.style.cssText = "padding:8px 16px;background:#9b59b6;border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; addBtn.textContent = "+ Log enquiry";
  addBtn.addEventListener("click", showEnquiryForm);
  var enqPrintBtn = document.createElement("button"); enqPrintBtn.className = "no-print"; enqPrintBtn.style.cssText = "padding:8px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; enqPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print all visible";
  enqPrintBtn.addEventListener("click", function(){ window.print(); });
  hdr.appendChild(title); hdr.appendChild(enqPrintBtn); hdr.appendChild(addBtn); ev.appendChild(hdr);

  var sub = document.createElement("div"); sub.style.cssText = "font-size:12px;color:var(--muted);margin-bottom:14px"; sub.textContent = "Things people have asked for that we don't currently stock.";
  ev.appendChild(sub);

  // Filter tabs
  var filterRow = document.createElement("div"); filterRow.style.cssText = "display:flex;gap:6px;margin-bottom:16px";
  ["Active","Resolved","All"].forEach(function(f){
    var btn = document.createElement("button");
    var count = f==="All" ? enquiries.length : enquiries.filter(function(en){ return (en.status||"Active")===f; }).length;
    btn.textContent = f + " (" + count + ")";
    btn.style.cssText = "padding:5px 13px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid "+(enqFilter===f?"#9b59b6":"var(--border)")+";background:"+(enqFilter===f?"#9b59b6":"var(--surface)")+";color:"+(enqFilter===f?"#fff":"var(--muted)");
    btn.addEventListener("click", function(){ enqFilter = f; renderEnquiriesView(); });
    filterRow.appendChild(btn);
  });
  ev.appendChild(filterRow);

  if (!enquiries.length) {
    var empty = document.createElement("div"); empty.style.cssText = "text-align:center;padding:40px 20px;color:var(--muted);font-size:13px"; empty.textContent = "No enquiries logged yet.";
    ev.appendChild(empty);
    return;
  }

  // Group ACTIVE-ONLY enquiries by normalised "what they want" to spot live repeats
  // (resolved ones shouldn't keep flagging as "multiple people asked" once sorted)
  var groups = {};
  enquiries.filter(function(en){ return (en.status||"Active")==="Active"; }).forEach(function(en){
    var key = normaliseEnqText(en.want);
    if (!groups[key]) groups[key] = [];
    groups[key].push(en);
  });

  // Repeated requests panel (2+ people asking for the same thing, still active)
  var repeatedKeys = Object.keys(groups).filter(function(k){ return groups[k].length >= 2; });
  if (repeatedKeys.length && (enqFilter==="Active"||enqFilter==="All")) {
    var repPanel = document.createElement("div");
    repPanel.style.cssText = "background:#fff4e0;border:2px solid #f0c060;border-radius:var(--r);padding:14px 16px;margin-bottom:18px";
    var repTitle = document.createElement("div"); repTitle.style.cssText = "font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#8a5a00;margin-bottom:9px"; repTitle.textContent = "\u26A0 Multiple people have asked for this";
    repPanel.appendChild(repTitle);
    repeatedKeys.sort(function(a,b){ return groups[b].length - groups[a].length; }).forEach(function(k){
      var grp = groups[k];
      var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid rgba(0,0,0,.06)";
      var left = document.createElement("div");
      var want = document.createElement("div"); want.style.cssText = "font-weight:700;font-size:13px"; want.textContent = grp[0].want;
      var names = document.createElement("div"); names.style.cssText = "font-size:11px;color:#8a5a00;margin-top:2px"; names.textContent = grp.map(function(g){ return g.name; }).join(", ");
      left.appendChild(want); left.appendChild(names);
      var badge = document.createElement("span"); badge.style.cssText = "background:#e8a020;color:#fff;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;flex-shrink:0"; badge.textContent = grp.length + " people";
      row.appendChild(left); row.appendChild(badge);
      repPanel.appendChild(row);
    });
    ev.appendChild(repPanel);
  }

  // Full list, newest first, filtered by tab
  var visibleEnquiries = enquiries.filter(function(en){
    if (enqFilter === "All") return true;
    return (en.status||"Active") === enqFilter;
  });

  var listTitle = document.createElement("div"); listTitle.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:8px"; listTitle.textContent = enqFilter + " enquiries";
  ev.appendChild(listTitle);

  if (!visibleEnquiries.length) {
    var emptyF = document.createElement("div"); emptyF.style.cssText = "text-align:center;padding:24px 20px;color:var(--muted);font-size:12px"; emptyF.textContent = "Nothing here.";
    ev.appendChild(emptyF);
    return;
  }

  var catColors = {"Tool":"#305CDE","Underlay":"#2ecc71","Other":"#7f8c8d"};
  visibleEnquiries.slice().reverse().forEach(function(en){
    var isResolved = (en.status||"Active")==="Resolved";
    var card = document.createElement("div"); card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:flex-start;gap:10px"+(isResolved?";opacity:.65":"");
    var left = document.createElement("div"); left.style.flex = "1";
    var topRow = document.createElement("div"); topRow.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap";
    var catBadge = document.createElement("span"); catBadge.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:2px 8px;border-radius:20px;background:"+(catColors[en.category]||"#7f8c8d")+";color:#fff"; catBadge.textContent = en.category||"Other";
    topRow.appendChild(catBadge);
    if (isResolved) {
      var resBadge = document.createElement("span"); resBadge.style.cssText = "font-size:9px;font-weight:700;color:#1a5c1a;background:#d0f0d0;padding:2px 8px;border-radius:20px"; resBadge.textContent = "\u2713 Resolved";
      topRow.appendChild(resBadge);
    } else {
      var isRepeat = groups[normaliseEnqText(en.want)] && groups[normaliseEnqText(en.want)].length >= 2;
      if (isRepeat) {
        var repBadge = document.createElement("span"); repBadge.style.cssText = "font-size:9px;font-weight:700;color:#8a5a00;background:#fff4e0;padding:2px 8px;border-radius:20px;border:2px solid #f0c060"; repBadge.textContent = "\u26A0 also asked by others";
        topRow.appendChild(repBadge);
      }
    }
    left.appendChild(topRow);
    var want = document.createElement("div"); want.style.cssText = "font-weight:700;font-size:14px;margin-bottom:2px"; want.textContent = en.want;
    left.appendChild(want);
    var meta = document.createElement("div"); meta.style.cssText = "font-size:11px;color:var(--muted)"; meta.textContent = en.name + (en.contact?" \u00b7 "+en.contact:"") + " \u00b7 "+en.date;
    left.appendChild(meta);
    if (en.notes) {
      var notes = document.createElement("div"); notes.style.cssText = "font-size:11px;color:var(--text);margin-top:5px;font-style:italic"; notes.textContent = en.notes;
      left.appendChild(notes);
    }
    if (isResolved && en.resolvedDate) {
      var resolvedMeta = document.createElement("div"); resolvedMeta.style.cssText = "font-size:10px;color:#1a5c1a;margin-top:4px"; resolvedMeta.textContent = "Resolved "+en.resolvedDate;
      left.appendChild(resolvedMeta);
    }

    var btnCol = document.createElement("div"); btnCol.style.cssText = "display:flex;flex-direction:column;gap:5px;flex-shrink:0";
    if (!isResolved) {
      var resolveBtn = document.createElement("button"); resolveBtn.style.cssText = "padding:4px 9px;background:#d0f0d0;border:2px solid #1a5c1a;border-radius:var(--rs);color:#1a5c1a;font-size:10px;font-weight:700;cursor:pointer"; resolveBtn.textContent = "\u2713 Resolved";
      resolveBtn.addEventListener("click", (function(id){ return function(){
        var en2 = enquiries.find(function(x){ return x.id===id; });
        if (en2) {
          var today = new Date();
          en2.status = "Resolved";
          en2.resolvedDate = String(today.getDate()).padStart(2,"0")+"/"+String(today.getMonth()+1).padStart(2,"0")+"/"+today.getFullYear();
          saveEnquiries();
          renderEnquiriesView();
          toast("Marked resolved \u2713");
        }
      };})(en.id));
      btnCol.appendChild(resolveBtn);
    } else {
      var reopenBtn = document.createElement("button"); reopenBtn.style.cssText = "padding:4px 9px;background:var(--surface);border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:10px;font-weight:700;cursor:pointer"; reopenBtn.textContent = "Reopen";
      reopenBtn.addEventListener("click", (function(id){ return function(){
        var en2 = enquiries.find(function(x){ return x.id===id; });
        if (en2) { en2.status = "Active"; delete en2.resolvedDate; saveEnquiries(); renderEnquiriesView(); toast("Reopened"); }
      };})(en.id));
      btnCol.appendChild(reopenBtn);
    }
    var delBtn = document.createElement("button"); delBtn.style.cssText = "padding:4px 9px;background:var(--rbg);border:1px solid var(--rtxt);border-radius:var(--rs);color:var(--rtxt);font-size:10px;font-weight:700;cursor:pointer"; delBtn.textContent = "Delete";
    delBtn.addEventListener("click", (function(id){ return function(){
      if(confirm("Delete this enquiry?")){
        enquiries = enquiries.filter(function(x){ return x.id!==id; });
        sbDelete("enquiries", id);
        saveEnquiries();
        renderEnquiriesView();
        toast("Deleted \u2713");
      }
    };})(en.id));
    var enqCardPrintBtn = document.createElement("button"); enqCardPrintBtn.className = "no-print"; enqCardPrintBtn.style.cssText = "padding:4px 9px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:10px;font-weight:700;cursor:pointer"; enqCardPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print";
    enqCardPrintBtn.addEventListener("click", (function(cardEl){ return function(){ isolatePrintEl(cardEl, null); }; })(card));
    btnCol.appendChild(enqCardPrintBtn);
    btnCol.appendChild(delBtn);

    card.appendChild(left); card.appendChild(btnCol);
    ev.appendChild(card);
  });
}

function showEnquiryForm() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:420px;max-height:90vh;overflow-y:auto";

  var bh = document.createElement("div"); bh.style.cssText = "background:#9b59b6;padding:14px 18px";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:15px;font-weight:700;color:#fff"; bht.textContent = "\uD83D\uDCAC Log an enquiry";
  bh.appendChild(bht); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:12px";

  function mkFd(lbl, inp) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp); return w; }

  var nameInp = document.createElement("input"); nameInp.id="enq_name"; nameInp.placeholder="Who asked"; nameInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("Name *", nameInp));

  var contactInp = document.createElement("input"); contactInp.id="enq_contact"; contactInp.placeholder="Phone / email (optional)"; contactInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("Contact", contactInp));

  var catSel = document.createElement("select"); catSel.id="enq_cat"; catSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  ["Tool","Underlay","Other"].forEach(function(c){ var o=document.createElement("option"); o.value=c; o.textContent=c; catSel.appendChild(o); });
  bd.appendChild(mkFd("Category", catSel));

  var wantInp = document.createElement("input"); wantInp.id="enq_want"; wantInp.placeholder="e.g. 12mm rubber crumb underlay"; wantInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("What they want *", wantInp));

  var notesInp = document.createElement("textarea"); notesInp.id="enq_notes"; notesInp.placeholder="Any extra detail..."; notesInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none;min-height:60px;resize:vertical";
  bd.appendChild(mkFd("Notes", notesInp));

  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:8px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:8px 18px;background:#9b59b6;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Save enquiry";
  saveB.addEventListener("click", function(){
    var name = nameInp.value.trim();
    var want = wantInp.value.trim();
    if (!name || !want) { toast("Please enter a name and what they want"); return; }
    var today = new Date();
    enquiries.push({
      id: "ENQ-"+Date.now(),
      status: "Active",
      name: name,
      contact: contactInp.value.trim(),
      category: catSel.value,
      want: want,
      notes: notesInp.value.trim(),
      date: String(today.getDate()).padStart(2,"0")+"/"+String(today.getMonth()+1).padStart(2,"0")+"/"+today.getFullYear()
    });
    saveEnquiries();
    document.body.removeChild(overlay);
    renderEnquiriesView();
    toast("Enquiry logged \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ nameInp.focus(); }, 100);
}

// ── SOURCING (special order / manufacturer price-chase sheet) ─────
var sourcingFilter = "Open";
var sourcingClientFilter = null; // set to a client id to pre-filter the list
var sourcingRepFilter = null; // set to a rep id to pre-filter the list (used when no client filter is set)
var SOURCING_STATUSES = ["Chasing Price","Priced","Quoted to Client","Ordered","Received","Cancelled"];
var SOURCING_STATUS_COLORS = {"Chasing Price":"#e67e22","Priced":"#f0c060","Quoted to Client":"#305CDE","Ordered":"#9b59b6","Received":"#2ecc71","Cancelled":"#7f8c8d"};

function showSourcing(clientId, repId) {
  sourcingClientFilter = clientId || null;
  sourcingRepFilter = (!clientId && repId) ? repId : null;
  sourcingFilter = "Open";
  activeId = null; renderList(); showView("sourcing"); renderSourcingView();
}

function sourcingMatchesRep(s, repObj) {
  if (!repObj) return false;
  if (s.repId) return s.repId === repObj.id;
  return !!(s.asmRep && s.asmRep.toLowerCase().indexOf(repObj.name.toLowerCase()) > -1);
}

function findClientLogIdxByRef(clientId, ref) {
  var c = clients.find(function(x){ return x.id===clientId; });
  if (!c || !c.log || !ref) return -1;
  for (var i=0;i<c.log.length;i++) {
    if (c.log[i].quote && c.log[i].quote.ref && c.log[i].quote.ref.trim().toLowerCase()===String(ref).trim().toLowerCase()) return i;
  }
  return -1;
}
function jumpToClientQuote(clientId, ref) {
  openC(clientId);
  setTimeout(function(){
    var idx = findClientLogIdxByRef(clientId, ref);
    if (idx > -1) { showQuoteEditForm(clientId, idx); } else { toast("Quote ref not found on this client \u2014 showing client instead"); }
  }, 200);
}

// Temporarily hides everything in the Sourcing view except the given element(s)
// so Print produces just that one enquiry (or one linked group), then restores
// the normal view once the print dialog closes.
function escHtml(s) {
  return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// Builds a standalone printable document in the hidden sandbox, prints it,
// then restores the normal app view once the print dialog closes.
function printSandboxDoc(bodyHtml) {
  var ps = document.getElementById("printSandbox");
  ps.innerHTML = bodyHtml;
  document.body.classList.add("print-sandbox-mode");
  function restore() {
    document.body.classList.remove("print-sandbox-mode");
    ps.innerHTML = "";
    window.removeEventListener("afterprint", restore);
  }
  window.addEventListener("afterprint", restore);
  setTimeout(restore, 60000);
  setTimeout(function(){ window.print(); }, 30);
}

function printWebsiteSlip(site) {
  var html = "<h1 style='font-size:20px;margin-bottom:4px'>" + escHtml(site.name) + "</h1>" +
    "<div style='font-size:14px;color:#333;margin-bottom:14px'>" + escHtml(site.url) + "</div>";
  if (site.category) html += "<div style='font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.4px;margin-bottom:10px'>" + escHtml(site.category) + "</div>";
  if (site.description) html += "<div style='font-size:13px;color:#222;margin-bottom:10px'>" + escHtml(site.description) + "</div>";
  if (site.notes) html += "<div style='font-size:13px;color:#222;border-top:1px solid #ccc;padding-top:10px;margin-top:10px'><strong>Notes:</strong><br>" + escHtml(site.notes) + "</div>";
  printSandboxDoc(html);
}

function printClientOverview() {
  document.body.classList.add("print-overview-mode");
  function restore() {
    document.body.classList.remove("print-overview-mode");
    window.removeEventListener("afterprint", restore);
  }
  window.addEventListener("afterprint", restore);
  setTimeout(restore, 60000);
  setTimeout(function(){ window.print(); }, 30);
}

// Prints the content of a modal overlay on its own, hiding the rest of the
// app and relaxing the overlay's fixed/scroll positioning so it flows onto
// the printed page properly, then restores everything once done.
function printBodyOverlay(overlayEl) {
  var restoreList = [];
  Array.from(document.body.children).forEach(function(el){
    if (el !== overlayEl) { restoreList.push({el:el, prev:el.style.display}); el.style.display = "none"; }
  });
  var prevOverlayCss = overlayEl.style.cssText;
  overlayEl.style.cssText = "position:static;background:#fff;padding:0;margin:0;display:block;";
  var boxEl = overlayEl.firstElementChild;
  var prevBoxCss = boxEl ? boxEl.style.cssText : null;
  if (boxEl) boxEl.style.cssText = "max-width:100%;max-height:none;overflow:visible;background:#fff;";
  function restore() {
    restoreList.forEach(function(r){ r.el.style.display = r.prev; });
    overlayEl.style.cssText = prevOverlayCss;
    if (boxEl) boxEl.style.cssText = prevBoxCss;
    window.removeEventListener("afterprint", restore);
  }
  window.addEventListener("afterprint", restore);
  setTimeout(restore, 60000);
  setTimeout(function(){ window.print(); }, 30);
}

function printSalesSummary() {
  document.body.classList.add("print-sales-summary-mode");
  function restore() {
    document.body.classList.remove("print-sales-summary-mode");
    window.removeEventListener("afterprint", restore);
  }
  window.addEventListener("afterprint", restore);
  setTimeout(restore, 60000);
  setTimeout(function(){ window.print(); }, 30);
}

function isolatePrintEl(topEl, onlyChildEl) {
  var container = topEl.parentElement;
  if (!container) return;
  var restoreList = [];
  Array.from(container.children).forEach(function(el){
    if (el !== topEl) { restoreList.push({el:el, prev:el.style.display}); el.style.display = "none"; }
  });
  if (onlyChildEl) {
    Array.from(topEl.children).forEach(function(child){
      if (child !== onlyChildEl) { restoreList.push({el:child, prev:child.style.display}); child.style.display = "none"; }
    });
  }
  function restore() {
    restoreList.forEach(function(r){ r.el.style.display = r.prev; });
    window.removeEventListener("afterprint", restore);
  }
  window.addEventListener("afterprint", restore);
  setTimeout(restore, 60000); // safety net in case afterprint never fires
  setTimeout(function(){ window.print(); }, 30);
}

function renderSourcingView() {
  var sv = document.getElementById("sourcingView");
  sv.innerHTML = "";

  var hdr = document.createElement("div"); hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;flex-wrap:wrap;gap:8px";
  var title = document.createElement("h2"); title.style.cssText = "font-size:18px;font-weight:700"; title.textContent = "\uD83C\uDFED Sourcing";
  var addBtn = document.createElement("button"); addBtn.style.cssText = "padding:8px 16px;background:#e67e22;border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; addBtn.textContent = "+ New special order enquiry";
  addBtn.addEventListener("click", function(){ showSourcingForm(null, sourcingClientFilter, sourcingRepFilter); });
  var srcPrintBtn = document.createElement("button"); srcPrintBtn.className = "no-print"; srcPrintBtn.style.cssText = "padding:8px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer"; srcPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print all visible";
  srcPrintBtn.addEventListener("click", function(){ window.print(); });
  hdr.appendChild(title); hdr.appendChild(srcPrintBtn); hdr.appendChild(addBtn); sv.appendChild(hdr);

  var sub = document.createElement("div"); sub.style.cssText = "font-size:12px;color:var(--muted);margin-bottom:12px"; sub.textContent = "Chase sheet for manufacturer/supplier prices \u2014 keeps your cost price and margin separate from what the client sees on their quote.";
  sv.appendChild(sub);

  var repFilterObj = sourcingRepFilter ? reps.find(function(x){ return x.id===sourcingRepFilter; }) : null;

  if (sourcingClientFilter) {
    var fc = clients.find(function(x){ return x.id===sourcingClientFilter; });
    var banner = document.createElement("div"); banner.style.cssText = "display:flex;align-items:center;justify-content:space-between;background:#fff4e8;border:2px solid #e6a15c;border-radius:var(--rs);padding:8px 12px;margin-bottom:14px;font-size:12px;color:#a5590f";
    var bt = document.createElement("span"); bt.textContent = "Showing special order enquiries for " + (fc ? fc.name : "this client");
    var clearB = document.createElement("button"); clearB.style.cssText = "padding:3px 10px;background:none;border:1px solid #e6a15c;border-radius:20px;color:#a5590f;font-size:10px;font-weight:700;cursor:pointer"; clearB.textContent = "Show all";
    clearB.addEventListener("click", function(){ sourcingClientFilter = null; renderSourcingView(); });
    banner.appendChild(bt); banner.appendChild(clearB); sv.appendChild(banner);
  } else if (sourcingRepFilter) {
    var banner2 = document.createElement("div"); banner2.style.cssText = "display:flex;align-items:center;justify-content:space-between;background:#fff4e8;border:2px solid #e6a15c;border-radius:var(--rs);padding:8px 12px;margin-bottom:14px;font-size:12px;color:#a5590f";
    var bt2 = document.createElement("span"); bt2.textContent = "Showing special order enquiries chased with " + (repFilterObj ? repFilterObj.name : "this rep");
    var clearB2 = document.createElement("button"); clearB2.style.cssText = "padding:3px 10px;background:none;border:1px solid #e6a15c;border-radius:20px;color:#a5590f;font-size:10px;font-weight:700;cursor:pointer"; clearB2.textContent = "Show all";
    clearB2.addEventListener("click", function(){ sourcingRepFilter = null; renderSourcingView(); });
    banner2.appendChild(bt2); banner2.appendChild(clearB2); sv.appendChild(banner2);
  }

  // Filter tabs
  var filterRow = document.createElement("div"); filterRow.style.cssText = "display:flex;gap:6px;margin-bottom:16px;flex-wrap:wrap";
  var baseList = sourcing;
  if (sourcingClientFilter) baseList = baseList.filter(function(s){ return s.clientId===sourcingClientFilter; });
  else if (sourcingRepFilter) baseList = baseList.filter(function(s){ return sourcingMatchesRep(s, repFilterObj); });
  ["Open","All"].concat(SOURCING_STATUSES).forEach(function(f){
    var count;
    if (f==="All") count = baseList.length;
    else if (f==="Open") count = baseList.filter(function(s){ return s.status!=="Received" && s.status!=="Cancelled"; }).length;
    else count = baseList.filter(function(s){ return s.status===f; }).length;
    if (f!=="Open" && f!=="All" && count===0) return;
    var btn = document.createElement("button");
    btn.textContent = f + " (" + count + ")";
    btn.style.cssText = "padding:5px 13px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid "+(sourcingFilter===f?"#e67e22":"var(--border)")+";background:"+(sourcingFilter===f?"#e67e22":"var(--surface)")+";color:"+(sourcingFilter===f?"#fff":"var(--muted)");
    btn.addEventListener("click", function(){ sourcingFilter = f; renderSourcingView(); });
    filterRow.appendChild(btn);
  });
  sv.appendChild(filterRow);

  var visible = baseList.filter(function(s){
    if (sourcingFilter === "All") return true;
    if (sourcingFilter === "Open") return s.status!=="Received" && s.status!=="Cancelled";
    return s.status === sourcingFilter;
  });

  if (!visible.length) {
    var empty = document.createElement("div"); empty.style.cssText = "text-align:center;padding:40px 20px;color:var(--muted);font-size:13px"; empty.textContent = sourcing.length ? "Nothing here." : "No special order enquiries logged yet.";
    sv.appendChild(empty);
    return;
  }

  function buildSourcingCard(s) {
    var card = document.createElement("div"); card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:13px 15px;margin-bottom:10px";
    var topRow = document.createElement("div"); topRow.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px;flex-wrap:wrap";
    var topLeft = document.createElement("div"); topLeft.style.cssText = "display:flex;align-items:center;gap:8px;flex-wrap:wrap";
    var statBadge = document.createElement("span"); statBadge.style.cssText = "font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:2px 8px;border-radius:20px;background:"+(SOURCING_STATUS_COLORS[s.status]||"#7f8c8d")+";color:#fff"; statBadge.textContent = s.status||"Chasing Price";
    topLeft.appendChild(statBadge);
    if (s.quoteRef) {
      var refBadge = document.createElement("span"); refBadge.style.cssText = "font-size:13px;font-weight:800;padding:3px 10px;border-radius:20px;background:#fff4e8;border:2px solid #e6a15c;color:#a5590f"; refBadge.textContent = "\uD83D\uDD17 " + s.quoteRef;
      topLeft.appendChild(refBadge);
    }
    topRow.appendChild(topLeft);
    var btnCol = document.createElement("div"); btnCol.style.cssText = "display:flex;gap:5px;flex-shrink:0";
    var editBtn = document.createElement("button"); editBtn.style.cssText = "padding:4px 9px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:10px;font-weight:700;cursor:pointer"; editBtn.textContent = "\u270E Edit";
    editBtn.addEventListener("click", (function(id){ return function(){ showSourcingForm(id); }; })(s.id));
    var delBtn = document.createElement("button"); delBtn.style.cssText = "padding:4px 9px;background:var(--rbg);border:1px solid var(--rtxt);border-radius:var(--rs);color:var(--rtxt);font-size:10px;font-weight:700;cursor:pointer"; delBtn.textContent = "Delete";
    delBtn.addEventListener("click", (function(id){ return function(){
      if (confirm("Delete this special order enquiry?")) {
        sourcing = sourcing.filter(function(x){ return x.id!==id; });
        saveSourcing(); renderSourcingView(); toast("Deleted \u2713");
      }
    }; })(s.id));
    btnCol.appendChild(editBtn);
    var cardPrintBtn = document.createElement("button"); cardPrintBtn.className = "no-print"; cardPrintBtn.style.cssText = "padding:4px 9px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:10px;font-weight:700;cursor:pointer"; cardPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print";
    cardPrintBtn.addEventListener("click", function(){
      var parent = card.parentElement;
      if (parent && parent.classList.contains("group-wrap")) { isolatePrintEl(parent, card); }
      else { isolatePrintEl(card, null); }
    });
    btnCol.appendChild(cardPrintBtn);
    btnCol.appendChild(delBtn);
    topRow.appendChild(btnCol);
    card.appendChild(topRow);

    var clientLine = document.createElement("div"); clientLine.style.cssText = "font-weight:700;font-size:14px;margin-bottom:2px;display:flex;align-items:center;gap:8px";
    var clientNameSpan = document.createElement("span"); clientNameSpan.textContent = s.client || "\u2014";
    clientLine.appendChild(clientNameSpan);
    if (s.clientId) {
      var viewClientBtn = document.createElement("button"); viewClientBtn.style.cssText = "padding:2px 8px;background:none;border:1px solid var(--navy);border-radius:20px;color:var(--navy);font-size:9px;font-weight:700;cursor:pointer"; viewClientBtn.textContent = "View client";
      viewClientBtn.addEventListener("click", (function(cid){ return function(){ openC(cid); }; })(s.clientId));
      clientLine.appendChild(viewClientBtn);
      if (s.quoteRef) {
        var idxCheck = findClientLogIdxByRef(s.clientId, s.quoteRef);
        if (idxCheck > -1) {
          var jumpBtn = document.createElement("button"); jumpBtn.style.cssText = "padding:2px 8px;background:#e67e22;border:none;border-radius:20px;color:#fff;font-size:9px;font-weight:700;cursor:pointer"; jumpBtn.textContent = "\u2713 View client quote";
          jumpBtn.addEventListener("click", (function(cid,ref){ return function(){ jumpToClientQuote(cid,ref); }; })(s.clientId, s.quoteRef));
          clientLine.appendChild(jumpBtn);
        }
      }
    }
    card.appendChild(clientLine);

    var colourDisplay = s.colour ? (s.colour + (s.colourNo ? " (" + s.colourNo + ")" : "")) : (s.colourNo || "");
    var prodBits = [s.product, s.productName, colourDisplay, s.qty].filter(function(x){ return x; });
    if (prodBits.length) { var prodLine = document.createElement("div"); prodLine.style.cssText = "font-size:12px;color:var(--text);margin-bottom:3px"; prodLine.textContent = prodBits.join(" \u00b7 "); card.appendChild(prodLine); }

    if (s.company || s.asmRep) {
      var compLine = document.createElement("div"); compLine.style.cssText = "font-size:11px;color:var(--muted);margin-bottom:6px";
      compLine.textContent = "Chasing: " + (s.company||"\u2014") + (s.asmRep ? " \u00b7 ASM/Rep: "+s.asmRep : "");
      card.appendChild(compLine);
    }

    var hasPricing = s.priceEx || s.priceInc || s.sellEx || s.sellInc;
    if (hasPricing) {
      var priceGrid = document.createElement("div"); priceGrid.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:6px;background:#f7f8fa;border-radius:var(--rs);padding:8px 10px;margin-bottom:6px;font-size:11px";
      function pf(lbl,val){ var d=document.createElement("div"); var l=document.createElement("div"); l.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.3px"; l.textContent=lbl; var v=document.createElement("div"); v.style.cssText="font-weight:700;color:var(--text)"; v.textContent=val?("\u00a3"+val):"\u2014"; d.appendChild(l); d.appendChild(v); return d; }
      priceGrid.appendChild(pf("Our (nett) ex VAT", s.priceEx));
      priceGrid.appendChild(pf("Our (nett) inc VAT", s.priceInc));
      priceGrid.appendChild(pf("Customer price ex VAT", s.sellEx));
      priceGrid.appendChild(pf("Customer price inc VAT", s.sellInc));
      card.appendChild(priceGrid);
      if (s.margin) { var marginLine = document.createElement("div"); marginLine.style.cssText = "font-size:11px;font-weight:700;color:#a5590f;margin-bottom:4px"; marginLine.textContent = "Margin: " + s.margin + "%"; card.appendChild(marginLine); }
    }

    if (s.timeline) { var tlLine = document.createElement("div"); tlLine.style.cssText = "font-size:11px;color:var(--muted);margin-bottom:4px"; tlLine.textContent = "\u23F1 " + s.timeline; card.appendChild(tlLine); }
    if (s.notes) { var notesLine = document.createElement("div"); notesLine.style.cssText = "font-size:11px;color:var(--text);font-style:italic;margin-top:2px"; notesLine.textContent = s.notes; card.appendChild(notesLine); }

    return card;
  }

  // Group enquiries that share the same "linked client quote ref" so multiple
  // special orders for one job sit together under a single job header, instead
  // of being scattered through the list.
  var newestFirst = visible.slice().reverse();
  var refCounts = {};
  visible.forEach(function(s){
    if (s.quoteRef && s.quoteRef.trim()) {
      var k = s.quoteRef.trim().toLowerCase();
      refCounts[k] = (refCounts[k]||0) + 1;
    }
  });
  var renderedRefs = {};
  newestFirst.forEach(function(s){
    var refKey = (s.quoteRef && s.quoteRef.trim()) ? s.quoteRef.trim().toLowerCase() : null;
    if (refKey && refCounts[refKey] > 1) {
      if (renderedRefs[refKey]) return;
      renderedRefs[refKey] = true;
      var groupItems = newestFirst.filter(function(x){ return x.quoteRef && x.quoteRef.trim().toLowerCase()===refKey; });
      var groupWrap = document.createElement("div"); groupWrap.className = "group-wrap"; groupWrap.style.cssText = "border:2px solid #e6a15c;background:#fffaf3;border-radius:var(--r);padding:12px;margin-bottom:14px";
      var groupHdr = document.createElement("div"); groupHdr.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap";
      var groupRefBadge = document.createElement("span"); groupRefBadge.style.cssText = "font-size:14px;font-weight:800;padding:4px 12px;border-radius:20px;background:#e67e22;color:#fff"; groupRefBadge.textContent = "\uD83D\uDD17 " + s.quoteRef.trim();
      var groupLbl = document.createElement("span"); groupLbl.style.cssText = "font-size:11px;font-weight:700;color:#a5590f"; groupLbl.textContent = groupItems.length + " linked special order enquiries for this job";
      var groupPrintBtn = document.createElement("button"); groupPrintBtn.className = "no-print"; groupPrintBtn.style.cssText = "padding:3px 10px;background:none;border:1px solid #e67e22;border-radius:20px;color:#a5590f;font-size:9px;font-weight:700;cursor:pointer;margin-left:auto"; groupPrintBtn.textContent = "\uD83D\uDDA8\uFE0F Print whole group";
      groupPrintBtn.addEventListener("click", (function(gw){ return function(){ isolatePrintEl(gw, null); }; })(groupWrap));
      groupHdr.appendChild(groupRefBadge); groupHdr.appendChild(groupLbl); groupHdr.appendChild(groupPrintBtn);
      groupWrap.appendChild(groupHdr);
      groupItems.forEach(function(gi){ groupWrap.appendChild(buildSourcingCard(gi)); });
      sv.appendChild(groupWrap);
    } else {
      sv.appendChild(buildSourcingCard(s));
    }
  });
}

function showSourcingForm(existingId, prefillClientId, prefillRepId) {
  var existing = existingId ? sourcing.find(function(x){ return x.id===existingId; }) : null;
  var prefillClient = null;
  if (!existing && prefillClientId) prefillClient = clients.find(function(x){ return x.id===prefillClientId; });
  var prefillRep = null;
  if (!existing && prefillRepId) prefillRep = reps.find(function(x){ return x.id===prefillRepId; });

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:460px;max-height:92vh;overflow-y:auto";

  var bh = document.createElement("div"); bh.style.cssText = "background:#e67e22;padding:14px 18px";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:15px;font-weight:700;color:#fff"; bht.textContent = existing ? "\u270E Edit special order enquiry" : "\uD83C\uDFED New special order enquiry";
  bh.appendChild(bht); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:12px";
  function mkFd(lbl, inp) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp); return w; }
  var inpCss = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";

  // Client (with autocomplete against existing clients). If opened directly from a
  // client's card, lock it so the record can't accidentally end up linked to the wrong client.
  var clientInp = document.createElement("input"); clientInp.id="src_client"; clientInp.setAttribute("list","src_client_list"); clientInp.style.cssText=inpCss;
  clientInp.value = existing ? (existing.client||"") : (prefillClient ? prefillClient.name : "");
  clientInp.placeholder = "Client name";
  var clientList = document.createElement("datalist"); clientList.id="src_client_list";
  clients.forEach(function(c){ var o=document.createElement("option"); o.value=c.name; clientList.appendChild(o); });
  var clientFd = mkFd("Client", clientInp);
  if (prefillClient && !existing) {
    clientInp.readOnly = true;
    clientInp.style.background = "#f2f2f2";
    clientInp.style.color = "var(--muted)";
    var unlockRow = document.createElement("div"); unlockRow.style.cssText = "font-size:10px;color:var(--muted);margin-top:3px";
    var unlockBtn = document.createElement("button"); unlockBtn.type="button"; unlockBtn.style.cssText = "background:none;border:none;color:var(--navy);font-size:10px;font-weight:700;cursor:pointer;text-decoration:underline;padding:0";
    unlockBtn.textContent = "Wrong client? Change it";
    unlockBtn.addEventListener("click", function(){ clientInp.readOnly=false; clientInp.style.background=""; clientInp.style.color=""; unlockRow.style.display="none"; clientInp.focus(); });
    unlockRow.appendChild(document.createTextNode("\uD83D\uDD12 Auto-filled from this client's card \u2014 "));
    unlockRow.appendChild(unlockBtn);
    clientFd.appendChild(unlockRow);
  }
  bd.appendChild(clientFd); bd.appendChild(clientList);

  var productInp = document.createElement("input"); productInp.id="src_product"; productInp.setAttribute("list","src_product_list"); productInp.style.cssText=inpCss; productInp.value = existing ? (existing.product||"") : "";
  var productList = document.createElement("datalist"); productList.id="src_product_list";
  PRODUCTS.forEach(function(p){ var o=document.createElement("option"); o.value=p; productList.appendChild(o); });
  bd.appendChild(mkFd("Product", productInp)); bd.appendChild(productList);

  var productNameInp = document.createElement("input"); productNameInp.id="src_productname"; productNameInp.placeholder="e.g. Krono Supernatural Wide Plank"; productNameInp.style.cssText=inpCss; productNameInp.value = existing ? (existing.productName||"") : "";
  bd.appendChild(mkFd("Product name", productNameInp));

  var colourInp = document.createElement("input"); colourInp.id="src_colour"; colourInp.style.cssText=inpCss; colourInp.value = existing ? (existing.colour||"") : "";
  var colourNoInp = document.createElement("input"); colourNoInp.id="src_colour_no"; colourNoInp.placeholder="e.g. 8842"; colourNoInp.style.cssText=inpCss; colourNoInp.value = existing ? (existing.colourNo||"") : "";
  var colourRow = document.createElement("div"); colourRow.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:8px";
  colourRow.appendChild(mkFd("Colour", colourInp)); colourRow.appendChild(mkFd("Colour number", colourNoInp));
  bd.appendChild(colourRow);

  var qtyInp = document.createElement("input"); qtyInp.id="src_qty"; qtyInp.placeholder="e.g. 45m\u00b2 / 3 boxes"; qtyInp.style.cssText=inpCss; qtyInp.value = existing ? (existing.qty||"") : "";
  bd.appendChild(mkFd("Quantity needed", qtyInp));

  var companyInp = document.createElement("input"); companyInp.id="src_company"; companyInp.setAttribute("list","src_company_list"); companyInp.style.cssText=inpCss; companyInp.value = existing ? (existing.company||"") : "";
  var companyList = document.createElement("datalist"); companyList.id="src_company_list";
  MANUFACTURERS.forEach(function(m){ var o=document.createElement("option"); o.value=m; companyList.appendChild(o); });
  bd.appendChild(mkFd("Company chasing (manufacturer/supplier)", companyInp)); bd.appendChild(companyList);

  var asmInp = document.createElement("input"); asmInp.id="src_asm"; asmInp.setAttribute("list","src_asm_list"); asmInp.placeholder="Name of ASM/rep at that company"; asmInp.style.cssText=inpCss; asmInp.value = existing ? (existing.asmRep||"") : (prefillRep ? prefillRep.name : "");
  var asmList = document.createElement("datalist"); asmList.id="src_asm_list";
  reps.forEach(function(r){ var o=document.createElement("option"); o.value=r.name+(r.manufacturer?" ("+r.manufacturer+")":""); asmList.appendChild(o); });
  var asmFd = mkFd("ASM / Rep", asmInp);
  if (prefillRep && !existing) {
    asmInp.readOnly = true;
    asmInp.style.background = "#f2f2f2";
    asmInp.style.color = "var(--muted)";
    var asmUnlockRow = document.createElement("div"); asmUnlockRow.style.cssText = "font-size:10px;color:var(--muted);margin-top:3px";
    var asmUnlockBtn = document.createElement("button"); asmUnlockBtn.type="button"; asmUnlockBtn.style.cssText = "background:none;border:none;color:var(--navy);font-size:10px;font-weight:700;cursor:pointer;text-decoration:underline;padding:0";
    asmUnlockBtn.textContent = "Wrong rep? Change it";
    asmUnlockBtn.addEventListener("click", function(){ asmInp.readOnly=false; asmInp.style.background=""; asmInp.style.color=""; asmUnlockRow.style.display="none"; asmInp.focus(); });
    asmUnlockRow.appendChild(document.createTextNode("\uD83D\uDD12 Auto-filled from this rep's card \u2014 "));
    asmUnlockRow.appendChild(asmUnlockBtn);
    asmFd.appendChild(asmUnlockRow);
  }
  bd.appendChild(asmFd); bd.appendChild(asmList);

  // Pricing / margin calculator — type the nett (our) price and a margin %, and the
  // customer sell price (ex + inc VAT) calculates itself. Works the other way too:
  // typing a sell price back-calculates the margin. Every box stays editable so you
  // can still round numbers by hand.
  var priceExInp = document.createElement("input"); priceExInp.id="src_price_ex"; priceExInp.type="number"; priceExInp.step="0.01"; priceExInp.style.cssText=inpCss; priceExInp.value = existing ? (existing.priceEx||"") : "";
  var priceIncInp = document.createElement("input"); priceIncInp.id="src_price_inc"; priceIncInp.type="number"; priceIncInp.step="0.01"; priceIncInp.style.cssText=inpCss; priceIncInp.value = existing ? (existing.priceInc||"") : "";
  var priceRow = document.createElement("div"); priceRow.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:8px";
  priceRow.appendChild(mkFd("Our (nett) price ex VAT", priceExInp)); priceRow.appendChild(mkFd("Our (nett) price inc VAT", priceIncInp));
  bd.appendChild(priceRow);

  var marginInp = document.createElement("input"); marginInp.id="src_margin"; marginInp.type="number"; marginInp.step="0.1"; marginInp.placeholder="e.g. 40"; marginInp.style.cssText=inpCss; marginInp.value = existing ? (existing.margin||"") : "";
  var marginWrap = mkFd("Margin % (on customer sell price)", marginInp);
  marginWrap.style.cssText = "background:#fff4e8;border:2px solid #e6a15c;border-radius:var(--rs);padding:8px 10px";
  bd.appendChild(marginWrap);

  var sellExInp = document.createElement("input"); sellExInp.id="src_sell_ex"; sellExInp.type="number"; sellExInp.step="0.01"; sellExInp.style.cssText=inpCss; sellExInp.value = existing ? (existing.sellEx||"") : "";
  var sellIncInp = document.createElement("input"); sellIncInp.id="src_sell_inc"; sellIncInp.type="number"; sellIncInp.step="0.01"; sellIncInp.style.cssText=inpCss; sellIncInp.value = existing ? (existing.sellInc||"") : "";
  var sellRow = document.createElement("div"); sellRow.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:8px";
  sellRow.appendChild(mkFd("Customer price ex VAT", sellExInp)); sellRow.appendChild(mkFd("Customer price inc VAT", sellIncInp));
  bd.appendChild(sellRow);

  function recalcSellFromMargin() {
    var nettEx = parseFloat(priceExInp.value);
    var m = parseFloat(marginInp.value);
    if (!isNaN(nettEx) && !isNaN(m) && m >= 0 && m < 100) {
      var sellEx = nettEx / (1 - m / 100);
      sellExInp.value = sellEx.toFixed(2);
      sellIncInp.value = (sellEx * 1.2).toFixed(2);
    }
  }
  function recalcMarginFromSell() {
    var nettEx = parseFloat(priceExInp.value);
    var sellEx = parseFloat(sellExInp.value);
    if (!isNaN(nettEx) && !isNaN(sellEx) && sellEx > 0) {
      marginInp.value = (((sellEx - nettEx) / sellEx) * 100).toFixed(1);
    }
  }
  priceExInp.addEventListener("input", function(){
    var v = parseFloat(this.value);
    if (!isNaN(v)) priceIncInp.value = (v * 1.2).toFixed(2);
    if (marginInp.value.trim() !== "") { recalcSellFromMargin(); } else { recalcMarginFromSell(); }
  });
  marginInp.addEventListener("input", recalcSellFromMargin);
  sellExInp.addEventListener("input", function(){
    var v = parseFloat(this.value);
    if (!isNaN(v)) sellIncInp.value = (v * 1.2).toFixed(2);
    recalcMarginFromSell();
  });
  sellIncInp.addEventListener("input", function(){
    var v = parseFloat(this.value);
    if (!isNaN(v)) sellExInp.value = (v / 1.2).toFixed(2);
    recalcMarginFromSell();
  });

  var timelineInp = document.createElement("input"); timelineInp.id="src_timeline"; timelineInp.placeholder="e.g. 5-7 working days"; timelineInp.style.cssText=inpCss; timelineInp.value = existing ? (existing.timeline||"") : "";
  bd.appendChild(mkFd("Timeline / how long to get", timelineInp));

  var statusSel = document.createElement("select"); statusSel.id="src_status"; statusSel.style.cssText=inpCss;
  SOURCING_STATUSES.forEach(function(s){ var o=document.createElement("option"); o.value=s; o.textContent=s; if(existing?existing.status===s:s==="Chasing Price") o.selected=true; statusSel.appendChild(o); });
  bd.appendChild(mkFd("Status", statusSel));

  var refInp = document.createElement("input"); refInp.id="src_quoteref"; refInp.placeholder="Match this to the ref on the client's quote to link them"; refInp.style.cssText=inpCss; refInp.value = existing ? (existing.quoteRef||"") : "";
  bd.appendChild(mkFd("Linked client quote ref", refInp));

  var notesInp = document.createElement("textarea"); notesInp.id="src_notes"; notesInp.style.cssText=inpCss+";min-height:60px;resize:vertical"; notesInp.value = existing ? (existing.notes||"") : "";
  bd.appendChild(mkFd("Notes (internal only \u2014 not shown to client)", notesInp));

  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:8px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:8px 18px;background:#e67e22;border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = existing ? "Save changes" : "Save";
  saveB.addEventListener("click", function(){
    var clientName = clientInp.value.trim();
    var product = productInp.value.trim();
    if (!clientName && !product) { toast("Please enter at least a client or product"); return; }
    var matchedClient = clients.find(function(c){ return c.name.trim().toLowerCase()===clientName.toLowerCase(); });
    var today = new Date();
    var rec = existing || { id: "SRC-"+Date.now(), createdDate: String(today.getDate()).padStart(2,"0")+"/"+String(today.getMonth()+1).padStart(2,"0")+"/"+today.getFullYear() };
    rec.client = clientName;
    rec.clientId = matchedClient ? matchedClient.id : (existing ? existing.clientId : null);
    rec.product = product;
    rec.productName = productNameInp.value.trim();
    rec.colour = colourInp.value.trim();
    rec.colourNo = colourNoInp.value.trim();
    rec.qty = qtyInp.value.trim();
    rec.company = companyInp.value.trim();
    var asmText = asmInp.value.trim();
    var matchedRep = reps.find(function(r){
      var full = r.name + (r.manufacturer ? " (" + r.manufacturer + ")" : "");
      return full.toLowerCase()===asmText.toLowerCase() || r.name.toLowerCase()===asmText.toLowerCase();
    });
    rec.asmRep = asmText;
    rec.repId = matchedRep ? matchedRep.id : (existing ? existing.repId : null);
    rec.priceEx = priceExInp.value.trim();
    rec.priceInc = priceIncInp.value.trim();
    rec.margin = marginInp.value.trim();
    rec.sellEx = sellExInp.value.trim();
    rec.sellInc = sellIncInp.value.trim();
    rec.timeline = timelineInp.value.trim();
    rec.status = statusSel.value;
    rec.quoteRef = refInp.value.trim();
    rec.notes = notesInp.value.trim();
    if (!existing) sourcing.push(rec);
    saveSourcing();
    document.body.removeChild(overlay);
    renderSourcingView();
    toast(existing ? "Special order enquiry updated \u2713" : "Special order enquiry saved \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ clientInp.focus(); }, 100);
}

function renderDocsView() {
  var dv2 = document.getElementById("docsView");
  dv2.innerHTML = "";

  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Docs & Specs";
  var addBtn = document.createElement("button");
  addBtn.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:20px;color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  addBtn.textContent = "+ Add document";
  addBtn.addEventListener("click", function(){ showAddDoc(); });
  hdr.appendChild(title); hdr.appendChild(addBtn); dv2.appendChild(hdr);

  // Search box
  var docSearchTerm = "";
  var docSearchBox = document.createElement("div");
  docSearchBox.style.cssText = "display:flex;align-items:center;gap:8px;background:var(--surface);border:2px solid var(--navy);border-radius:var(--rs);padding:9px 12px;margin-bottom:14px;max-width:360px;box-shadow:0 1px 4px rgba(0,0,0,.06)";
  var docSI = document.createElement("span"); docSI.textContent = "🔍"; docSI.style.cssText = "font-size:14px";
  var docSInput = document.createElement("input"); docSInput.type = "text"; docSInput.placeholder = "Search documents...";
  docSInput.style.cssText = "background:none;border:none;outline:none;font-size:13px;color:var(--text);flex:1;min-width:0";
  docSInput.addEventListener("input", function(){ docSearchTerm = this.value; renderDocs(); });
  docSearchBox.appendChild(docSI); docSearchBox.appendChild(docSInput); dv2.appendChild(docSearchBox);

  // Category filter
  var cats = ["All"];
  docs.forEach(function(d){ if(d.category && cats.indexOf(d.category)<0) cats.push(d.category); });
  var activeCat = "All";
  var listWrap = document.createElement("div"); listWrap.id = "docListWrap";

  if (cats.length > 1) {
    var catRow = document.createElement("div"); catRow.style.cssText = "display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px";
    cats.forEach(function(cat) {
      var btn = document.createElement("button");
      btn.style.cssText = "padding:4px 12px;border-radius:20px;border:2px solid var(--border);font-size:11px;font-weight:700;cursor:pointer;"+(cat==="All"?"background:var(--navy);color:#fff;border-color:var(--navy)":"background:var(--surface);color:var(--muted)");
      btn.textContent = cat;
      btn.addEventListener("click", function(){
        catRow.querySelectorAll("button").forEach(function(b){b.style.background="var(--surface)";b.style.color="var(--muted)";b.style.borderColor="var(--border)";});
        btn.style.background="var(--navy)";btn.style.color="#fff";btn.style.borderColor="var(--navy)";
        activeCat=cat; renderDocs();
      });
      catRow.appendChild(btn);
    });
    dv2.appendChild(catRow);
  }

  dv2.appendChild(listWrap);

  var docIcons = {
    "Fitting Instructions":"\uD83D\uDCCB",
    "Product Spec":"\uD83D\uDCC4",
    "Parts List":"\uD83D\uDD27",
    "Price List":"\uD83D\uDCB0",
    "Safety Data":"\u26A0\uFE0F",
    "Brochure":"\uD83D\uDCD6",
    "Warranty":"\u2705",
    "Other":"\uD83D\uDCC2"
  };

  function renderDocs() {
    listWrap.innerHTML = "";
    var filtered = activeCat==="All" ? docs : docs.filter(function(d){ return d.category===activeCat; });
    var q = (docSearchTerm||"").toLowerCase();
    if (q) {
      filtered = filtered.filter(function(d){
        return [d.name, d.supplier, d.category, d.description].some(function(v){ return (v||"").toLowerCase().indexOf(q) > -1; });
      });
    }

    if (!filtered.length) {
      var em = document.createElement("div"); em.className = "empty-state";
      em.innerHTML = q
        ? "<div>🔍</div><div class='es-title'>No documents found</div><div class='es-sub'>Try a different search term</div>"
        : "<div>📄</div><div class='es-title'>No documents added yet</div><div class='es-sub'>Add links to fitting instructions, product specs, price lists, brochures — upload to Google Drive first then paste the link here</div>";
      listWrap.appendChild(em); return;
    }

    // Group by category
    var groups = {};
    filtered.forEach(function(d){
      var cat = d.category || "Other";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(d);
    });

    Object.keys(groups).sort().forEach(function(cat) {
      if (activeCat === "All" && Object.keys(groups).length > 1) {
        var catHdr = document.createElement("div");
        catHdr.style.cssText = "font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:8px;margin-top:14px;padding-bottom:5px;border-bottom:2px solid var(--navy)";
        catHdr.textContent = (docIcons[cat]||"\uD83D\uDCC2")+" "+cat; listWrap.appendChild(catHdr);
      }

      var grid = document.createElement("div");
      grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;margin-bottom:10px";

      groups[cat].forEach(function(d) {
        var realIdx = docs.indexOf(d);
        var card = document.createElement("div");
        card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--r);padding:14px;display:flex;flex-direction:column;gap:8px";

        var top = document.createElement("div"); top.style.cssText = "display:flex;align-items:flex-start;gap:10px";
        var icon2 = document.createElement("div");
        icon2.style.cssText = "width:40px;height:40px;border-radius:8px;background:#eef1f8;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0";
        icon2.textContent = docIcons[d.category]||"\uD83D\uDCC2";
        var info = document.createElement("div"); info.style.flex = "1";
        var nm = document.createElement("div"); nm.style.cssText = "font-weight:700;font-size:13px;margin-bottom:3px"; nm.textContent = d.name;
        var supplier = document.createElement("div"); supplier.style.cssText = "font-size:10px;color:var(--muted)";
        supplier.textContent = (d.supplier||"")+(d.supplier&&d.category?" · ":"")+(d.category||"");
        info.appendChild(nm); info.appendChild(supplier);
        top.appendChild(icon2); top.appendChild(info); card.appendChild(top);

        if (d.description) {
          var desc = document.createElement("div"); desc.style.cssText = "font-size:11px;color:var(--muted);line-height:1.5"; desc.textContent = d.description;
          card.appendChild(desc);
        }

        var btns = document.createElement("div"); btns.style.cssText = "display:flex;gap:6px;margin-top:4px";
        var openBtn = document.createElement("button");
        openBtn.style.cssText = "flex:1;padding:6px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer";
        openBtn.textContent = "\uD83D\uDCC4 Open doc";
        openBtn.addEventListener("click", (function(url2){ return function(){ window.open(url2,"_blank"); }; })(d.url));
        var editBtn3 = document.createElement("button");
        editBtn3.style.cssText = "padding:6px 10px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;cursor:pointer;color:var(--muted)";
        editBtn3.textContent = "\u270E";
        editBtn3.addEventListener("click", (function(idx2){ return function(){ showAddDoc(idx2); }; })(realIdx));
        var delBtn3 = document.createElement("button");
        delBtn3.style.cssText = "padding:6px 10px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;cursor:pointer;color:var(--rtxt)";
        delBtn3.textContent = "\u00d7";
        delBtn3.addEventListener("click", (function(idx2){ return async function(){ if(confirm("Remove this document?")){ var docToDelete=docs[idx2]; docs.splice(idx2,1); if(docToDelete&&docToDelete.id){ await sbDelete("docs", docToDelete.id); } saveDocs(); renderDocsView(); toast("Removed"); } }; })(realIdx));
        btns.appendChild(openBtn); btns.appendChild(editBtn3); btns.appendChild(delBtn3);
        card.appendChild(btns); grid.appendChild(card);
      });
      listWrap.appendChild(grid);
    });
  }
  renderDocs();

  var bk = document.createElement("button"); bk.className = "bkl"; bk.textContent = "\u2190 Back to dashboard"; bk.addEventListener("click", showDash); dv2.appendChild(bk);
}

function showAddDoc(editIdx) {
  var d = editIdx !== undefined ? docs[editIdx] : null;
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:460px;border-top:3px solid var(--navy)";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = d ? "Edit document" : "Add document";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";
  function mkFd2(lbl,inp2){var w2=document.createElement("div");var l=document.createElement("label");l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px";l.textContent=lbl;w2.appendChild(l);w2.appendChild(inp2);return w2;}
  function mkId(id2,val,ph){var i=document.createElement("input");i.id=id2;i.value=val||"";i.placeholder=ph||"";i.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";return i;}

  var hint = document.createElement("div"); hint.style.cssText = "font-size:11px;color:var(--muted);background:var(--alt);border-radius:var(--rs);padding:8px 10px";
  hint.textContent = "Upload your file to Google Drive, Dropbox or OneDrive first, then paste the shareable link below.";
  bd.appendChild(hint);

  // Category dropdown
  var catSel2 = document.createElement("select"); catSel2.id = "d_cat";
  catSel2.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var defaultDocCats=["Fitting Instructions","Product Spec","Parts List","Price List","Safety Data","Brochure","Warranty","Other"];
  var allDocCats=defaultDocCats.concat(DOC_CATS.filter(function(c){return defaultDocCats.indexOf(c)<0;}));
  allDocCats.forEach(function(c){
    var opt=document.createElement("option");opt.value=c;opt.textContent=c;if(d&&d.category===c)opt.selected=true;catSel2.appendChild(opt);
  });

  // Supplier dropdown from manufacturers
  var supSel = document.createElement("select"); supSel.id = "d_sup";
  supSel.style.cssText = "width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var defOpt2 = document.createElement("option"); defOpt2.value=""; defOpt2.textContent="-- Select supplier --"; supSel.appendChild(defOpt2);
  MANUFACTURERS.forEach(function(m){var opt=document.createElement("option");opt.value=m;opt.textContent=m;if(d&&d.supplier===m)opt.selected=true;supSel.appendChild(opt);});

  var descTa = document.createElement("textarea"); descTa.id="d_desc"; descTa.value=d?d.description||"":""; descTa.placeholder="e.g. Full fitting guide for Korlok range, includes subfloor prep"; descTa.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none;resize:vertical;min-height:55px";

  bd.appendChild(mkFd2("Document title *", mkId("d_name", d?d.name:"", "e.g. Karndean Korlok Fitting Instructions")));
  bd.appendChild(mkFd2("Category", catSel2));
  bd.appendChild(mkFd2("Supplier / manufacturer", supSel));
  bd.appendChild(mkFd2("Link (Google Drive / Dropbox etc) *", mkId("d_url", d?d.url:"", "Paste shareable link here")));
  bd.appendChild(mkFd2("Description / notes", descTa));
  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = d?"Save changes":"Add document";
  saveB.addEventListener("click", function(){
    var name2=document.getElementById("d_name").value.trim();
    var url3=document.getElementById("d_url").value.trim();
    if(!name2||!url3){toast("Please add a title and link");return;}
    var data={name:name2,url:url3,category:document.getElementById("d_cat").value,supplier:document.getElementById("d_sup").value,description:document.getElementById("d_desc").value.trim()};
    if(d&&editIdx!==undefined){data.id=d.id||("DOC-"+Date.now());docs[editIdx]=data;}else{data.id="DOC-"+Date.now()+"-"+Math.floor(Math.random()*10000);docs.push(data);}
    saveDocs();document.body.removeChild(overlay);renderDocsView();
    toast((d?"Document updated":"Document added")+"\u2713");
  });
  foot.appendChild(cancelB);foot.appendChild(saveB);
  box.appendChild(foot);overlay.appendChild(box);document.body.appendChild(overlay);
}


// ── CHANGE PASSWORD ───────────────────────────────────────────────
var PW_STORE = "spcrm_pw_v1";
var API_KEY_STORE = "spcrm_api_key_v1"; // deliberately local-only — never synced to the cloud (secret key)
function getApiKey(){ try{ return localStorage.getItem(API_KEY_STORE)||""; }catch(e){ return ""; } }
function setApiKey(k){ try{ localStorage.setItem(API_KEY_STORE,k); }catch(e){} }

function getCurrentPassword() {
  try { var p = localStorage.getItem(PW_STORE); if (p) return p; } catch(e) {}
  return "WaffleWoo2026"; // default
}
function savePassword(pw){
  try { localStorage.setItem(PW_STORE, pw); } catch(e) {}
  sbUpsert("settings","admin_pw",{key:"admin_pw",value:pw});
}
async function syncPasswordFromCloud(){
  try{
    var rows=await sbGet("settings");
    if(rows){
      var row=rows.find(function(r){return r&&r.key==="admin_pw";});
      if(row&&row.value){
        try{localStorage.setItem(PW_STORE,row.value);}catch(e){}
      }
    }
  }catch(e){ console.warn("password cloud sync failed", e); }
}
syncPasswordFromCloud();

function showChangePassword() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:380px;border-top:3px solid var(--navy)";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "\uD83D\uDD12 Change Password";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  function mkPwF(lbl, inp2) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp2); return w; }
  function mkPwI(id2, ph) {
    var wrap = document.createElement("div"); wrap.style.cssText = "position:relative";
    var i = document.createElement("input"); i.id=id2; i.type="password"; i.placeholder=ph||"";
    i.autocomplete="new-password"; i.autocorrect="off"; i.autocapitalize="none";
    i.style.cssText="width:100%;padding:8px 40px 8px 10px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;color:var(--text);outline:none";
    var eye = document.createElement("button"); eye.type="button"; eye.textContent="\uD83D\uDC41";
    eye.style.cssText="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:15px;padding:0;line-height:1";
    eye.addEventListener("click",function(){i.type=i.type==="password"?"text":"password";eye.textContent=i.type==="password"?"\uD83D\uDC41":"\uD83D\uDE48";});
    wrap.appendChild(i); wrap.appendChild(eye); return wrap;
  }

  var note = document.createElement("div"); note.style.cssText = "font-size:11px;color:var(--muted);background:var(--alt);border-radius:var(--rs);padding:8px 10px"; note.textContent = "Your new password syncs across all your devices. Make it something memorable but not obvious!";
  bd.appendChild(note);
  bd.appendChild(mkPwF("Current password", mkPwI("pw_current", "Enter current password")));
  bd.appendChild(mkPwF("New password *", mkPwI("pw_new", "Enter new password")));
  bd.appendChild(mkPwF("Confirm new password *", mkPwI("pw_confirm", "Repeat new password")));
  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Change password";
  saveB.addEventListener("click", function(){
    var current = document.getElementById("pw_current").value;
    var newPw = document.getElementById("pw_new").value;
    var confirm2 = document.getElementById("pw_confirm").value;
    if (current !== getCurrentPassword()) { toast("Current password is incorrect"); return; }
    if (!newPw || newPw.length < 6) { toast("New password must be at least 6 characters"); return; }
    if (newPw !== confirm2) { toast("Passwords don\'t match"); return; }
    try { savePassword(newPw); } catch(e) {}
    document.body.removeChild(overlay);
    toast("Password changed \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ document.getElementById("pw_current").focus(); }, 100);
}


// ── AUTO PRIORITY ─────────────────────────────────────────────────
function parseUKDate(s){
  if(!s) return null;
  var p=String(s).split("/");
  if(p.length!==3) return null;
  var d=new Date(parseInt(p[2]),parseInt(p[1])-1,parseInt(p[0]));
  return isNaN(d.getTime())?null:d;
}
function calcAnnualSpend(c){
  var cutoff=new Date(); cutoff.setFullYear(cutoff.getFullYear()-1);
  var t=0;
  (c.log||[]).forEach(function(l){
    if(l.quote&&l.quote.status==="Collected"){
      var useDate=l.quote.collectedDate||l.date;
      var dt=parseUKDate(useDate);
      if(!dt||dt>=cutoff){ t+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0); }
    }
  });
  return t;
}
function calcAutoPriority(c) {
  var score = 0;

  // Total paid sales (up to 40 points)
  var totalSales = 0;
  (c.log||[]).forEach(function(l){
    if(l.quote&&l.quote.status==="Collected")
      totalSales += (parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
  });
  if(totalSales >= 10000) score += 40;
  else if(totalSales >= 5000) score += 30;
  else if(totalSales >= 2000) score += 20;
  else if(totalSales >= 500) score += 10;
  else if(totalSales > 0) score += 5;

  // Open quote value (up to 20 points)
  var openVal = 0;
  (c.log||[]).forEach(function(l){
    if(l.quote&&(l.quote.status==="Quote"||l.quote.status==="Confirmed"))
      openVal += (parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
  });
  if(openVal >= 5000) score += 20;
  else if(openVal >= 2000) score += 15;
  else if(openVal >= 500) score += 10;
  else if(openVal > 0) score += 5;

  // Number of interactions (up to 20 points)
  var logs = (c.log||[]).length;
  if(logs >= 20) score += 20;
  else if(logs >= 10) score += 15;
  else if(logs >= 5) score += 10;
  else if(logs >= 2) score += 5;
  else if(logs >= 1) score += 2;

  // Recency - how recently contacted (up to 20 points)
  if(c.lastContact) {
    var s = c.lastContact;
    if(s.indexOf("/")>-1){var p=s.split("/");s=p[2]+"-"+p[1]+"-"+p[0];}
    var dt = new Date(s);
    if(!isNaN(dt.getTime())) {
      var days = (new Date()-dt)/86400000;
      if(days <= 7) score += 20;
      else if(days <= 14) score += 15;
      else if(days <= 30) score += 10;
      else if(days <= 60) score += 5;
    }
  }

  // Convert score to stars
  if(score >= 70) return "\u2605\u2605\u2605\u2605\u2605";
  if(score >= 50) return "\u2605\u2605\u2605\u2605";
  if(score >= 30) return "\u2605\u2605\u2605";
  if(score >= 15) return "\u2605\u2605";
  if(score >= 5)  return "\u2605";
  return "";
}

function autoRateAllClients() {
  var updated = 0;
  clients.forEach(function(c){
    if(c.status==="Active"||c.status==="Prospect") {
      var auto = calcAutoPriority(c);
      if(!c.manualPriority) { // only auto-rate if not manually overridden
        c.priority = auto;
        updated++;
      }
    }
  });
  saveC();
  renderList();
  if(activeId) renderDet();
  toast("Auto-rated "+updated+" clients \u2713");
}


// ── BUSINESS CARD SCANNER ─────────────────────────────────────────
function scanBusinessCard() {
  var apiKey = getApiKey();

  // If no API key, show setup prompt
  if (!apiKey) {
    var overlay = document.createElement("div");
    overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:300;display:flex;align-items:center;justify-content:center;padding:16px";
    var box = document.createElement("div");
    box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:400px;border-top:3px solid var(--navy);padding:24px";
    box.innerHTML = "<div style=\"font-size:22px;margin-bottom:10px;text-align:center\">\uD83D\uDCF7</div>" +
      "<h3 style=\"font-size:14px;font-weight:700;margin-bottom:8px;text-align:center\">Business Card Scanner</h3>" +
      "<p style=\"font-size:12px;color:var(--muted);margin-bottom:16px;text-align:center;line-height:1.5\">To use this feature you need a Claude API key from Anthropic. Each scan costs about 1-2p.</p>" +
      "<div style=\"margin-bottom:10px\"><label style=\"display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px\">Anthropic API Key</label>" +
      "<input id=\"api_key_inp\" type=\"password\" placeholder=\"sk-ant-...\" style=\"width:100%;padding:8px 10px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit\"></div>" +
      "<p style=\"font-size:10px;color:var(--muted);margin-bottom:14px\">Get your key at <strong>console.anthropic.com</strong> → API Keys. Add a small amount of credit (£5 lasts hundreds of scans).</p>";
    var btns = document.createElement("div"); btns.style.cssText = "display:flex;gap:8px";
    var cancelB = document.createElement("button"); cancelB.style.cssText = "flex:1;padding:8px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;cursor:pointer;color:var(--muted)"; cancelB.textContent = "Not yet";
    cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
    var saveKeyB = document.createElement("button"); saveKeyB.style.cssText = "flex:1;padding:8px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveKeyB.textContent = "Save & scan";
    saveKeyB.addEventListener("click", function(){
      var key = document.getElementById("api_key_inp").value.trim();
      if(!key||!key.startsWith("sk-")){ toast("Please enter a valid API key (starts with sk-)"); return; }
      setApiKey(key);
      document.body.removeChild(overlay);
      toast("API key saved \u2713");
      setTimeout(scanBusinessCard, 300);
    });
    btns.appendChild(cancelB); btns.appendChild(saveKeyB);
    box.appendChild(btns);
    overlay.appendChild(box); document.body.appendChild(overlay);
    return;
  }

  // Have API key - open camera
  var inp = document.createElement("input");
  inp.type = "file"; inp.accept = "image/*"; inp.capture = "environment";
  inp.addEventListener("change", async function(){
    if(!this.files||!this.files[0]) return;
    var file = this.files[0];
    toast("\uD83D\uDCF7 Reading card...");

    // Convert to base64
    var reader = new FileReader();
    reader.onload = async function(ev2){
      var img2 = new Image();
      img2.onload = async function(){
        var canvas2 = document.createElement("canvas");
        var maxS = 800; var w2=img2.width; var h2=img2.height;
        if(w2>maxS||h2>maxS){if(w2>h2){h2=Math.round(h2*maxS/w2);w2=maxS;}else{w2=Math.round(w2*maxS/h2);h2=maxS;}}
        canvas2.width=w2;canvas2.height=h2;
        canvas2.getContext("2d").drawImage(img2,0,0,w2,h2);
        var b64=canvas2.toDataURL("image/jpeg",0.6).split(",")[1];
        toast("\uD83D\uDCF7 Sending to AI...");
        try{
          var resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:"claude-haiku-4-5-20251001",max_tokens:500,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:"image/jpeg",data:b64}},{type:"text",text:"Business card image. Return ONLY valid JSON no markdown. Fields: name,company,tel,mobile,email,website,notes(job title). Empty string if not found."}]}]})});
          if(!resp.ok){var et=await resp.text();var em="";try{var ej=JSON.parse(et);em=ej.error?ej.error.message.substring(0,60):et.substring(0,60);}catch(e2){em=et.substring(0,60);}toast("\u26A0\uFE0F "+resp.status+": "+em);return;}
          var d=await resp.json();
          if(!d.content||!d.content[0]){toast("\u26A0\uFE0F No response");return;}
          var txt=d.content[0].text.trim().replace(/```json|```/g,"").trim();
          try{
            var p=JSON.parse(txt);
            if(p.name&&document.getElementById("r_name"))document.getElementById("r_name").value=p.name;
            if(p.company&&document.getElementById("r_company"))document.getElementById("r_company").value=p.company;
            if(p.tel&&document.getElementById("r_tel"))document.getElementById("r_tel").value=p.tel;
            if(p.mobile&&document.getElementById("r_mob"))document.getElementById("r_mob").value=p.mobile;
            if(p.email&&document.getElementById("r_email"))document.getElementById("r_email").value=p.email;
            if(p.website&&document.getElementById("r_web"))document.getElementById("r_web").value=p.website;
            if(p.notes&&document.getElementById("r_notes"))document.getElementById("r_notes").value=p.notes;
            toast("\u2713 Card scanned! Check details and save");
          }catch(pe){toast("\u26A0\uFE0F Parse error - try again");}
        }catch(err){toast("\u26A0\uFE0F "+err.name+": "+err.message.substring(0,50));console.error(err);}
      };
      img2.src=ev2.target.result;
    };
    reader.readAsDataURL(file);
  });
  inp.click();
}


// ── NOTES SEARCH ──────────────────────────────────────────────────
function showNotesSearch() {
  activeId = null; renderList(); showView("notesSearch"); renderNotesSearch();
}

function renderNotesSearch(query) {
  var nv = document.getElementById("notesSearchView");
  nv.innerHTML = "";

  var hdr = document.createElement("div");
  hdr.style.cssText = "display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:10px";
  var title = document.createElement("div"); title.className = "page-title"; title.textContent = "Search All Notes";
  hdr.appendChild(title); nv.appendChild(hdr);

  // Search box
  var srchWrap = document.createElement("div");
  srchWrap.style.cssText = "display:flex;align-items:center;gap:8px;background:var(--surface);border:2px solid var(--navy);border-radius:var(--rs);padding:9px 12px;margin-bottom:16px";
  var srchInp = document.createElement("input");
  srchInp.type = "text"; srchInp.id = "notesSrch";
  srchInp.placeholder = "Search across all client notes, interactions, quotes...";
  srchInp.value = query || "";
  srchInp.style.cssText = "background:none;border:none;outline:none;font-size:13px;color:var(--text);flex:1;min-width:0";
  srchInp.addEventListener("input", function(){ renderNotesSearch(this.value); });
  srchWrap.appendChild(srchInp); nv.appendChild(srchWrap);

  if (!query || query.trim().length < 2) {
    var hint = document.createElement("div"); hint.className = "empty-state";
    hint.innerHTML = "<div>\uD83D\uDD0D</div><div class='es-title'>Search your notes</div><div class='es-sub'>Type at least 2 characters to search across all client interaction logs, notes and quotes</div>";
    nv.appendChild(hint);
    setTimeout(function(){ var el=document.getElementById("notesSrch");if(el)el.focus(); }, 100);
    return;
  }

  var q = query.trim().toLowerCase();
  var results = [];

  clients.forEach(function(c) {
    // Search last interaction notes
    if (c.notes && c.notes.toLowerCase().indexOf(q) > -1) {
      results.push({ client: c, type: "Notes", text: c.notes, date: c.lastContact || "" });
    }
    // Search interaction log
    (c.log||[]).forEach(function(l) {
      if (l.note && l.note.toLowerCase().indexOf(q) > -1) {
        results.push({ client: c, type: l.type||"Log", text: l.note, date: l.date||"", quote: l.quote });
      }
      // Search quote products
      if (l.quote && l.quote.products && l.quote.products.toLowerCase().indexOf(q) > -1) {
        results.push({ client: c, type: "Quote", text: l.quote.products + " — " + (l.quote.status||""), date: l.date||"", quote: l.quote });
      }
    });
  });

  var countEl = document.createElement("div");
  countEl.style.cssText = "font-size:11px;color:var(--muted);margin-bottom:12px;font-weight:700";
  countEl.textContent = results.length + " result" + (results.length!==1?"s":"") + " for: " + query;
  nv.appendChild(countEl);

  if (!results.length) {
    var em = document.createElement("div"); em.className = "empty-state";
    em.innerHTML = "<div>\uD83D\uDD0D</div><div class='es-title'>No results found</div><div class='es-sub'>Try different keywords</div>";
    nv.appendChild(em);
  } else {
    results.forEach(function(r) {
      var card = document.createElement("div");
      card.style.cssText = "background:var(--surface);border:2px solid var(--border);border-radius:var(--rs);padding:11px 13px;margin-bottom:8px;cursor:pointer";
      card.addEventListener("click", (function(cid){ return function(){ openC(cid); }; })(r.client.id));

      var top = document.createElement("div"); top.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:6px";
      var av = document.createElement("div"); av.style.cssText = "width:28px;height:28px;border-radius:50%;background:var(--navy);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;flex-shrink:0"; av.textContent = ini(r.client.name);
      var cname = document.createElement("div"); cname.style.cssText = "font-weight:700;font-size:12px;flex:1"; cname.textContent = r.client.name;
      var typePill = document.createElement("span"); typePill.style.cssText = "font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;background:var(--lbg);color:var(--ltxt)"; typePill.textContent = r.type;
      var dateEl = document.createElement("span"); dateEl.style.cssText = "font-size:9px;color:var(--muted)"; dateEl.textContent = r.date;
      top.appendChild(av); top.appendChild(cname); top.appendChild(typePill); top.appendChild(dateEl);

      // Highlight matching text
      var textEl = document.createElement("div"); textEl.style.cssText = "font-size:11px;color:var(--text);line-height:1.5";
      var highlighted = r.text.replace(new RegExp("("+q.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+")", "gi"), "<mark style=\"background:#fff3a0;border-radius:2px;padding:0 2px\">$1</mark>");
      textEl.innerHTML = highlighted.length > 200 ? highlighted.substring(0, 200) + "..." : highlighted;

      card.appendChild(top); card.appendChild(textEl);
      if(r.quote) {
        var qv = document.createElement("div"); qv.style.cssText = "font-size:10px;color:var(--gtxt);font-weight:700;margin-top:4px"; qv.textContent = "\u00a3" + (parseFloat(String(r.quote.value||"0").replace(/[^0-9.]/g,""))||0).toLocaleString("en-GB") + " — " + (r.quote.status||"");
        card.appendChild(qv);
      }
      nv.appendChild(card);
    });
  }

  var bk = document.createElement("button"); bk.className = "bkl"; bk.textContent = "\u2190 Back to dashboard"; bk.addEventListener("click", showDash); nv.appendChild(bk);
  setTimeout(function(){ var el=document.getElementById("notesSrch");if(el){el.focus();el.setSelectionRange(el.value.length,el.value.length);} }, 100);
}


// ── MONTHLY REPORT ────────────────────────────────────────────────
function showMonthlyReport() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.7);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:680px;max-height:92vh;overflow-y:auto";

  // Header
  var rptHdr = document.createElement("div");
  rptHdr.style.cssText = "background:var(--navy);padding:16px 20px;border-radius:var(--r) var(--r) 0 0;display:flex;align-items:center;justify-content:space-between";
  var rptLeft = document.createElement("div");
  var rptTitle = document.createElement("div");rptTitle.style.cssText="font-size:15px;font-weight:700;color:#fff";rptTitle.textContent="📊 Reports Hub";
  var rptSub = document.createElement("div");rptSub.style.cssText="font-size:10px;color:rgba(255,255,255,.5);margin-top:2px";rptSub.textContent="CRM · "+new Date().toLocaleDateString("en-GB");
  rptLeft.appendChild(rptTitle);rptLeft.appendChild(rptSub);
  var closeX = document.createElement("button");closeX.style.cssText="background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer";closeX.textContent="×";
  closeX.addEventListener("click",function(){document.body.removeChild(overlay);});
  rptHdr.appendChild(rptLeft);rptHdr.appendChild(closeX);box.appendChild(rptHdr);

  // Tabs
  var tabs = ["📅 Monthly","💸 Lost Quotes","👥 Rep Activity","📈 Acquisition","🛒 Product Mix","💬 Enquiries"];
  var tabBar = document.createElement("div");tabBar.style.cssText="display:flex;gap:0;border-bottom:2px solid var(--border);background:var(--alt);overflow-x:auto";
  var body = document.createElement("div");body.style.cssText="padding:20px";

  function mkTab(label,idx){
    var t=document.createElement("button");
    t.style.cssText="padding:10px 14px;border:none;background:none;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;border-bottom:2px solid transparent;margin-bottom:-2px;color:var(--muted)";
    t.textContent=label;
    t.addEventListener("click",function(){
      tabBar.querySelectorAll("button").forEach(function(b){b.style.borderBottomColor="transparent";b.style.color="var(--muted)";});
      t.style.borderBottomColor="var(--navy)";t.style.color="var(--navy)";
      renderReport(idx);
    });
    return t;
  }
  tabs.forEach(function(lbl,i){tabBar.appendChild(mkTab(lbl,i));});
  box.appendChild(tabBar);box.appendChild(body);

  // Helper functions
  function rptSection(title2){var s=document.createElement("div");s.style.cssText="margin-bottom:20px";var t=document.createElement("div");t.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid var(--navy)";t.textContent=title2;s.appendChild(t);return s;}
  function rptKpi(lbl,val,col){var k=document.createElement("div");k.style.cssText="background:var(--alt);border-radius:var(--rs);padding:10px 12px;text-align:center";var v=document.createElement("div");v.style.cssText="font-size:20px;font-weight:700;color:"+(col||"var(--navy)");v.textContent=val;var l=document.createElement("div");l.style.cssText="font-size:10px;color:var(--muted);margin-top:2px";l.textContent=lbl;k.appendChild(v);k.appendChild(l);return k;}
  function rptRow(rank,name,val,col){var row=document.createElement("div");row.style.cssText="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border)";var r=document.createElement("span");r.style.cssText="width:20px;font-size:10px;font-weight:700;color:var(--muted);text-align:center";r.textContent=rank;var n=document.createElement("span");n.style.cssText="flex:1;font-size:12px";n.textContent=name;var v=document.createElement("span");v.style.cssText="font-weight:700;font-size:12px;color:"+(col||"var(--gtxt)");v.textContent=val;row.appendChild(r);row.appendChild(n);row.appendChild(v);return row;}

  function renderReport(idx) {
    body.innerHTML="";
    var now=new Date();var mn=now.getMonth();var yr=now.getFullYear();
    var mnames=["January","February","March","April","May","June","July","August","September","October","November","December"];

    if(idx===0) {
      // ── MONTHLY SNAPSHOT ──
      var monthSales=0,monthSalesCount=0,productMap={},monthInteractions=0,openQuotes=0,openQuoteVal=0;
      var newClients=clients.filter(function(c){if(!c.log||!c.log.length)return false;var fl=c.log[c.log.length-1];if(!fl.date)return false;var dp=fl.date.split("/");return dp.length===3&&parseInt(dp[1])-1===mn&&parseInt(dp[2])===yr;});
      clients.forEach(function(c){(c.log||[]).forEach(function(l){
        if(l.date){var dp=l.date.split("/");if(dp.length===3&&parseInt(dp[1])-1===mn&&parseInt(dp[2])===yr)monthInteractions++;}
        if(l.quote){
          if((l.quote.status==="Quote"||l.quote.status==="Confirmed")){openQuotes++;openQuoteVal+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);}
          if(l.quote.status==="Collected"){var useDate2=l.quote.collectedDate||l.date;if(useDate2){var dp=useDate2.split("/");if(dp.length===3&&parseInt(dp[1])-1===mn&&parseInt(dp[2])===yr){var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);monthSales+=v;monthSalesCount++;var cat=l.quote.category||"Other";productMap[cat]=(productMap[cat]||0)+v;}}}
        }
      });});
      var topClients=[];clients.forEach(function(c){var sp=0;(c.log||[]).forEach(function(l){if(l.quote&&l.quote.status==="Collected"){var useDate3=l.quote.collectedDate||l.date;if(useDate3){var dp=useDate3.split("/");if(dp.length===3&&parseInt(dp[1])-1===mn&&parseInt(dp[2])===yr)sp+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);}}});if(sp>0)topClients.push({name:c.name,spend:sp});});
      topClients.sort(function(a,b){return b.spend-a.spend;}).splice(5);

      var hdr=document.createElement("div");hdr.style.cssText="font-size:13px;font-weight:700;margin-bottom:14px";hdr.textContent=mnames[mn]+" "+yr+" Snapshot";body.appendChild(hdr);
      var ss=rptSection("Sales");var sg=document.createElement("div");sg.style.cssText="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:8px";
      sg.appendChild(rptKpi("Revenue","£"+monthSales.toLocaleString("en-GB"),"var(--gtxt)"));sg.appendChild(rptKpi("Transactions",monthSalesCount,"var(--navy)"));sg.appendChild(rptKpi("Avg Sale",monthSalesCount>0?"£"+Math.round(monthSales/monthSalesCount).toLocaleString("en-GB"):"—","var(--navy)"));ss.appendChild(sg);body.appendChild(ss);
      var ps=rptSection("Pipeline");var pg=document.createElement("div");pg.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:8px";pg.appendChild(rptKpi("Open Quotes",openQuotes,"var(--atxt)"));pg.appendChild(rptKpi("Pipeline Value","£"+openQuoteVal.toLocaleString("en-GB"),"var(--atxt)"));ps.appendChild(pg);body.appendChild(ps);
      var as2=rptSection("Activity");var ag=document.createElement("div");ag.style.cssText="display:grid;grid-template-columns:repeat(3,1fr);gap:8px";ag.appendChild(rptKpi("Total Clients",clients.length,"var(--navy)"));ag.appendChild(rptKpi("New This Month",newClients.length,"var(--gtxt)"));ag.appendChild(rptKpi("Interactions",monthInteractions,"var(--navy)"));as2.appendChild(ag);body.appendChild(as2);
      if(topClients.length){var cs=rptSection("Top Clients This Month");topClients.forEach(function(c,i){cs.appendChild(rptRow(i+1,c.name,"£"+c.spend.toLocaleString("en-GB")));});body.appendChild(cs);}
      if(Object.keys(productMap).length){var prs=rptSection("Top Products");Object.keys(productMap).sort(function(a,b){return productMap[b]-productMap[a];}).slice(0,5).forEach(function(p,i){prs.appendChild(rptRow(i+1,p,"£"+productMap[p].toLocaleString("en-GB")));});body.appendChild(prs);}

    } else if(idx===1) {
      // ── LOST QUOTES ──
      var lost=[];clients.forEach(function(c){(c.log||[]).forEach(function(l){if(l.quote&&l.quote.status==="Lost"){var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);lost.push({client:c.name,value:v,reason:l.quote.lostReason||"No reason given",date:l.date||"",products:l.quote.products||""});}});});
      lost.sort(function(a,b){return b.value-a.value;});
      var totalLost=lost.reduce(function(s,q){return s+q.value;},0);
      var reasonMap={};lost.forEach(function(q){var r=q.reason.split(" - ")[0];reasonMap[r]=(reasonMap[r]||0)+1;});

      var hdr=document.createElement("div");hdr.style.cssText="font-size:13px;font-weight:700;margin-bottom:14px";hdr.textContent="Lost Quote Analysis";body.appendChild(hdr);
      var ss=rptSection("Summary");var sg=document.createElement("div");sg.style.cssText="display:grid;grid-template-columns:repeat(3,1fr);gap:8px";sg.appendChild(rptKpi("Lost Quotes",lost.length,"var(--rtxt)"));sg.appendChild(rptKpi("Value Lost","£"+totalLost.toLocaleString("en-GB"),"var(--rtxt)"));sg.appendChild(rptKpi("Avg Lost",lost.length>0?"£"+Math.round(totalLost/lost.length).toLocaleString("en-GB"):"—","var(--rtxt)"));ss.appendChild(sg);body.appendChild(ss);
      if(Object.keys(reasonMap).length){var rs=rptSection("Why We Lost");Object.keys(reasonMap).sort(function(a,b){return reasonMap[b]-reasonMap[a];}).forEach(function(r,i){rs.appendChild(rptRow(i+1,r,reasonMap[r]+" quotes","var(--rtxt)"));});body.appendChild(rs);}
      if(lost.length){var qs=rptSection("Lost Quotes (by value)");lost.slice(0,10).forEach(function(q,i){var row=document.createElement("div");row.style.cssText="padding:7px 0;border-bottom:1px solid var(--border)";var top=document.createElement("div");top.style.cssText="display:flex;justify-content:space-between;align-items:center";var nm=document.createElement("span");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent=q.client;var v=document.createElement("span");v.style.cssText="font-weight:700;font-size:12px;color:var(--rtxt)";v.textContent="£"+q.value.toLocaleString("en-GB");top.appendChild(nm);top.appendChild(v);var bot=document.createElement("div");bot.style.cssText="font-size:10px;color:var(--muted);margin-top:2px";bot.textContent=q.reason+(q.products?" · "+q.products:"");row.appendChild(top);row.appendChild(bot);qs.appendChild(row);});body.appendChild(qs);}
      else{var e=document.createElement("div");e.style.cssText="text-align:center;padding:30px;color:var(--muted);font-size:13px";e.textContent="No lost quotes yet — great work! 🎉";body.appendChild(e);}

    } else if(idx===2) {
      // ── REP ACTIVITY ──
      var hdr=document.createElement("div");hdr.style.cssText="font-size:13px;font-weight:700;margin-bottom:14px";hdr.textContent="Rep / ASM Activity Report";body.appendChild(hdr);
      var ss=rptSection("Rep Summary");
      if(!reps||!reps.length){var e=document.createElement("div");e.style.cssText="text-align:center;padding:20px;color:var(--muted)";e.textContent="No reps added yet";ss.appendChild(e);}
      else{
        var today=new Date();today.setHours(0,0,0,0);
        var repData=reps.filter(function(r){ return !r.excludeFromTracking; }).map(function(r){
          var effectiveContact = r.lastInteractionDate || r.lastContact;
          // If both exist, use whichever is more recent
          if (r.lastInteractionDate && r.lastContact) {
            var p1=r.lastInteractionDate.indexOf("/")>-1?(function(){var p=r.lastInteractionDate.split("/");return new Date(p[2]+"-"+p[1]+"-"+p[0]);})():new Date(r.lastInteractionDate);
            var p2=r.lastContact.indexOf("/")>-1?(function(){var p=r.lastContact.split("/");return new Date(p[2]+"-"+p[1]+"-"+p[0]);})():new Date(r.lastContact);
            effectiveContact = p1>p2 ? r.lastInteractionDate : r.lastContact;
          }
          var daysSince=9999;if(effectiveContact){var d=new Date(effectiveContact.indexOf("/")>-1?(function(){var p=effectiveContact.split("/");return p[2]+"-"+p[1]+"-"+p[0];})():effectiveContact);if(!isNaN(d.getTime()))daysSince=Math.round((today-d)/86400000);}
          var sampleCount=samples?samples.filter(function(s){return s.repId===r.id;}).length:0;
          return {name:r.name,manufacturer:r.manufacturer||"Other",daysSince:daysSince,nextVisit:r.nextVisit||"",sampleCount:sampleCount,log:(r.log||[]).length};
        });
        repData.sort(function(a,b){return a.daysSince-b.daysSince;});
        repData.forEach(function(r){
          var row=document.createElement("div");row.style.cssText="padding:8px 0;border-bottom:1px solid var(--border)";
          var top=document.createElement("div");top.style.cssText="display:flex;justify-content:space-between;align-items:center";
          var nm=document.createElement("span");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent=r.name;
          var badge=document.createElement("span");
          var dCol=r.daysSince<14?"var(--gtxt)":r.daysSince<30?"var(--atxt)":"var(--rtxt)";
          badge.style.cssText="font-size:10px;font-weight:700;color:"+dCol;
          badge.textContent=r.daysSince===9999?"Never contacted":r.daysSince+"d ago";
          top.appendChild(nm);top.appendChild(badge);
          var bot=document.createElement("div");bot.style.cssText="font-size:10px;color:var(--muted);margin-top:2px";
          bot.textContent=r.manufacturer+(r.nextVisit?" · Next: "+r.nextVisit:"")+(r.sampleCount?" · "+r.sampleCount+" samples":"");
          row.appendChild(top);row.appendChild(bot);ss.appendChild(row);
        });
        var overdue=repData.filter(function(r){return r.daysSince>30;}).length;
        var due=repData.filter(function(r){return r.daysSince>=14&&r.daysSince<=30;}).length;
        var good=repData.filter(function(r){return r.daysSince<14;}).length;
        var sg=document.createElement("div");sg.style.cssText="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px";
        sg.appendChild(rptKpi("Good (<14d)",good,"var(--gtxt)"));sg.appendChild(rptKpi("Due (14-30d)",due,"var(--atxt)"));sg.appendChild(rptKpi("Overdue (30d+)",overdue,"var(--rtxt)"));
        ss.insertBefore(sg,ss.children[1]);
      }
      body.appendChild(ss);

    } else if(idx===3) {
      // ── CLIENT ACQUISITION ──
      var hdr=document.createElement("div");hdr.style.cssText="font-size:13px;font-weight:700;margin-bottom:14px";hdr.textContent="Client Acquisition Report";body.appendChild(hdr);
      var sourceMap={};var monthMap={};var mnames2=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      clients.forEach(function(c){
        var src=c.source||"Unknown";sourceMap[src]=(sourceMap[src]||0)+1;
        // Use dateOpened if available, else first log date
        var openDate=c.dateOpened||(c.log&&c.log.length?c.log[c.log.length-1].date:"");
        if(openDate){var dp=openDate.split("/");if(dp.length===3){var key=mnames2[parseInt(dp[1])-1]+" "+dp[2];monthMap[key]=(monthMap[key]||0)+1;}}
      });
      var ss=rptSection("By Source");
      var total=clients.length;
      Object.keys(sourceMap).sort(function(a,b){return sourceMap[b]-sourceMap[a];}).forEach(function(s,i){
        var row=document.createElement("div");row.style.cssText="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border)";
        var r=document.createElement("span");r.style.cssText="width:20px;font-size:10px;font-weight:700;color:var(--muted)";r.textContent=i+1;
        var nm=document.createElement("span");nm.style.cssText="flex:1;font-size:12px";nm.textContent=s||"Unknown";
        var pct=document.createElement("span");pct.style.cssText="font-size:10px;color:var(--muted);margin-right:8px";pct.textContent=Math.round(sourceMap[s]/total*100)+"%";
        var v=document.createElement("span");v.style.cssText="font-weight:700;font-size:12px;color:var(--navy)";v.textContent=sourceMap[s];
        row.appendChild(r);row.appendChild(nm);row.appendChild(pct);row.appendChild(v);ss.appendChild(row);
      });
      body.appendChild(ss);
      var sg=document.createElement("div");sg.style.cssText="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px";
      sg.appendChild(rptKpi("Total",total,"var(--navy)"));sg.appendChild(rptKpi("Active",clients.filter(function(c){return c.status==="Active";}).length,"var(--gtxt)"));sg.appendChild(rptKpi("Prospect",clients.filter(function(c){return c.status==="Prospect";}).length,"var(--atxt)"));
      body.insertBefore(sg,body.children[1]);
      var ms=rptSection("New Clients by Month (last 6)");
      var sortedMonths=Object.keys(monthMap).slice(-6);
      sortedMonths.forEach(function(m,i){ms.appendChild(rptRow(i+1,m,monthMap[m]+" clients","var(--navy)"));});
      body.appendChild(ms);

    } else if(idx===4) {
      // ── PRODUCT MIX ──
      var hdr=document.createElement("div");hdr.style.cssText="font-size:13px;font-weight:700;margin-bottom:14px";hdr.textContent="Product Mix Report";body.appendChild(hdr);
      var catRev={};var catCount={};var catPipeline={};
      clients.forEach(function(c){(c.log||[]).forEach(function(l){
        if(l.quote){
          var cat=l.quote.category||l.quote.products||"Other";if(!cat)cat="Other";
          var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);
          if(l.quote.status==="Collected"){catRev[cat]=(catRev[cat]||0)+v;catCount[cat]=(catCount[cat]||0)+1;}
          if(l.quote.status==="Quote"||l.quote.status==="Confirmed"){catPipeline[cat]=(catPipeline[cat]||0)+v;}
        }
      });});
      var totalRev=Object.values(catRev).reduce(function(s,v){return s+v;},0);
      var ss=rptSection("Revenue by Product");
      if(!Object.keys(catRev).length){var e=document.createElement("div");e.style.cssText="text-align:center;padding:20px;color:var(--muted)";e.textContent="No paid sales logged yet";ss.appendChild(e);}
      else{Object.keys(catRev).sort(function(a,b){return catRev[b]-catRev[a];}).forEach(function(c,i){
        var row=document.createElement("div");row.style.cssText="padding:7px 0;border-bottom:1px solid var(--border)";
        var top=document.createElement("div");top.style.cssText="display:flex;align-items:center;gap:8px";
        var r=document.createElement("span");r.style.cssText="width:20px;font-size:10px;font-weight:700;color:var(--muted)";r.textContent=i+1;
        var nm=document.createElement("span");nm.style.cssText="flex:1;font-size:12px;font-weight:700";nm.textContent=c;
        var pct=document.createElement("span");pct.style.cssText="font-size:10px;color:var(--muted)";pct.textContent=Math.round(catRev[c]/totalRev*100)+"%";
        var v=document.createElement("span");v.style.cssText="font-weight:700;font-size:12px;color:var(--gtxt)";v.textContent="£"+catRev[c].toLocaleString("en-GB");
        top.appendChild(r);top.appendChild(nm);top.appendChild(pct);top.appendChild(v);
        var bar=document.createElement("div");bar.style.cssText="height:4px;background:var(--border);border-radius:2px;margin-top:5px";
        var fill=document.createElement("div");fill.style.cssText="height:4px;background:var(--navy);border-radius:2px;width:"+Math.round(catRev[c]/totalRev*100)+"%";
        bar.appendChild(fill);row.appendChild(top);row.appendChild(bar);ss.appendChild(row);
      });}
      body.appendChild(ss);
      if(Object.keys(catPipeline).length){var ps=rptSection("Pipeline by Product");Object.keys(catPipeline).sort(function(a,b){return catPipeline[b]-catPipeline[a];}).forEach(function(c,i){ps.appendChild(rptRow(i+1,c,"£"+catPipeline[c].toLocaleString("en-GB"),"var(--atxt)"));});body.appendChild(ps);}
    } else if(idx===5) {
      // ── ENQUIRIES ──
      var hdr5=document.createElement("div");hdr5.style.cssText="font-size:13px;font-weight:700;margin-bottom:4px";hdr5.textContent="Enquiries Report";body.appendChild(hdr5);
      var sub5=document.createElement("div");sub5.style.cssText="font-size:11px;color:var(--muted);margin-bottom:16px";sub5.textContent="Things customers have asked for that we don't currently stock.";body.appendChild(sub5);

      var monthEnq = enquiries.filter(function(en){
        var dp = (en.date||"").split("/");
        if(dp.length!==3) return false;
        return parseInt(dp[1])-1===mn && parseInt(dp[2])===yr;
      });
      var activeMonthEnq = monthEnq.filter(function(en){ return (en.status||"Active")==="Active"; });
      var resolvedMonthEnq = monthEnq.filter(function(en){ return en.status==="Resolved"; });

      var es1=rptSection("This Month");
      es1.appendChild(rptRow(1,"Total enquiries logged",String(monthEnq.length),"var(--navy)"));
      es1.appendChild(rptRow(2,"Still active / unstocked",String(activeMonthEnq.length),"var(--atxt)"));
      es1.appendChild(rptRow(3,"Resolved / now stocked",String(resolvedMonthEnq.length),"var(--gtxt)"));
      body.appendChild(es1);

      // Top requested items - ALL TIME active enquiries grouped, not just this month,
      // since a repeat pattern is more meaningful over a longer window
      var allActiveGroups = {};
      enquiries.filter(function(en){ return (en.status||"Active")==="Active"; }).forEach(function(en){
        var key = normaliseEnqText(en.want);
        if(!allActiveGroups[key]) allActiveGroups[key] = {want:en.want, names:[], count:0};
        allActiveGroups[key].count++;
        allActiveGroups[key].names.push(en.name);
      });
      var topRequested = Object.values(allActiveGroups).filter(function(g){return g.count>=2;}).sort(function(a,b){return b.count-a.count;});

      var es2=rptSection("Top Requested Items (currently unstocked, all time)");
      if(!topRequested.length){
        var ee=document.createElement("div");ee.style.cssText="text-align:center;padding:20px;color:var(--muted);font-size:12px";ee.textContent="No repeated requests yet";es2.appendChild(ee);
      } else {
        topRequested.forEach(function(g,i){
          es2.appendChild(rptRow(i+1, g.want+" ("+g.names.join(", ")+")", g.count+" people", "#9b59b6"));
        });
      }
      body.appendChild(es2);

      // Breakdown by category, active only
      var catBreakdown = {};
      enquiries.filter(function(en){ return (en.status||"Active")==="Active"; }).forEach(function(en){
        var cat = en.category||"Other";
        catBreakdown[cat] = (catBreakdown[cat]||0)+1;
      });
      if(Object.keys(catBreakdown).length){
        var es3=rptSection("Active Enquiries by Category");
        Object.keys(catBreakdown).sort(function(a,b){return catBreakdown[b]-catBreakdown[a];}).forEach(function(c,i){
          es3.appendChild(rptRow(i+1,c,catBreakdown[c]+" enquiries","var(--navy)"));
        });
        body.appendChild(es3);
      }
    }
  }

  // Footer
  var foot=document.createElement("div");foot.style.cssText="padding:12px 20px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center";
  var closeB=document.createElement("button");closeB.style.cssText="padding:7px 14px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";closeB.textContent="Close";closeB.addEventListener("click",function(){document.body.removeChild(overlay);});
  var printB=document.createElement("button");printB.style.cssText="padding:7px 14px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";printB.textContent="🖨️ Print";printB.addEventListener("click",function(){window.print();});
  foot.appendChild(closeB);foot.appendChild(printB);box.appendChild(foot);
  overlay.appendChild(box);document.body.appendChild(overlay);

  // Activate first tab
  tabBar.children[0].style.borderBottomColor="var(--navy)";
  tabBar.children[0].style.color="var(--navy)";
  renderReport(0);
}


// ── LIST EDITOR (Admin: Manufacturers / Categories) ──────────────
function showListEditor(opts) {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:480px;max-height:88vh;overflow-y:auto;border-top:3px solid #e8a020";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:1";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:14px;font-weight:700;color:#fff"; bht.textContent = opts.icon+" "+opts.title;
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); showAdmin(); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  if (opts.note) {
    var note = document.createElement("div"); note.style.cssText = "font-size:11px;color:var(--muted);background:var(--alt);border-radius:var(--rs);padding:8px 12px;border-left:3px solid var(--navy)"; note.textContent = opts.note;
    bd.appendChild(note);
  }

  // Add new item row
  var addRow = document.createElement("div"); addRow.style.cssText = "display:flex;gap:8px";
  var newInp = document.createElement("input"); newInp.type = "text"; newInp.placeholder = opts.placeholder || "Add new...";
  newInp.style.cssText = "flex:1;padding:8px 10px;border:2px solid var(--navy);border-radius:var(--rs);font-size:12px;font-family:inherit;color:var(--text);outline:none";
  var addBtn2 = document.createElement("button"); addBtn2.style.cssText = "padding:8px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap"; addBtn2.textContent = "+ Add";
  function doAdd() {
    var val = newInp.value.trim();
    if (!val) { toast("Please enter a name"); return; }
    var list = opts.getList();
    if (list.some(function(v){ return v.toLowerCase() === val.toLowerCase(); })) { toast("Already in the list"); return; }
    list.push(val);
    opts.setList(list);
    newInp.value = "";
    renderItems();
    toast("\u2713 Added: "+val);
  }
  addBtn2.addEventListener("click", doAdd);
  newInp.addEventListener("keydown", function(e){ if(e.key==="Enter") doAdd(); });
  addRow.appendChild(newInp); addRow.appendChild(addBtn2); bd.appendChild(addRow);

  // List of current items
  var listWrap2 = document.createElement("div"); listWrap2.style.cssText = "display:flex;flex-direction:column;gap:6px";
  bd.appendChild(listWrap2);

  function renderItems() {
    listWrap2.innerHTML = "";
    var list = opts.getList();
    if (!list.length) {
      var em = document.createElement("div"); em.style.cssText = "text-align:center;padding:20px;color:var(--muted);font-size:12px"; em.textContent = "No items yet.";
      listWrap2.appendChild(em); return;
    }
    var sorted = list.slice().sort(function(a,b){ return a.localeCompare(b, undefined, {sensitivity:"base"}); });
    sorted.forEach(function(item) {
      var row = document.createElement("div"); row.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:var(--alt);border:2px solid var(--border);border-radius:var(--rs)";
      var lbl = document.createElement("span"); lbl.style.cssText = "font-size:12px;color:var(--text);font-weight:500"; lbl.textContent = item;
      var delB = document.createElement("button");
      delB.style.cssText = "padding:4px 10px;background:none;border:2px solid var(--border);border-radius:20px;font-size:11px;color:var(--muted);cursor:pointer;font-weight:700";
      delB.textContent = "\u00d7 Remove";
      delB.addEventListener("click", (function(v){return function(){
        if (!confirm("Remove \""+v+"\" from the list?")) return;
        var l = opts.getList();
        var idx = l.indexOf(v);
        if (idx > -1) { l.splice(idx,1); opts.setList(l); renderItems(); toast("Removed: "+v); }
      };})(item));
      row.appendChild(lbl); row.appendChild(delB); listWrap2.appendChild(row);
    });
  }
  renderItems();

  box.appendChild(bd);
  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:2px solid var(--border);display:flex;justify-content:flex-end";
  var doneB = document.createElement("button"); doneB.style.cssText = "padding:8px 20px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; doneB.textContent = "Done";
  doneB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  foot.appendChild(doneB); box.appendChild(foot);
  overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ newInp.focus(); }, 100);
}

// ── COLOUR THEME PICKER (Admin) ─────────────────────────────────
function showThemePicker(parentOverlay) {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:210;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:480px;max-height:88vh;overflow-y:auto;border-top:3px solid #e8a020";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:1";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:14px;font-weight:700;color:#fff"; bht.textContent = "\uD83C\uDFA8 Colour theme";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";

  var note = document.createElement("div");
  note.style.cssText = "font-size:11px;color:var(--muted);background:var(--alt);border-radius:var(--rs);padding:8px 12px;border-left:3px solid var(--navy);line-height:1.4";
  note.textContent = "Pick a colour scheme any time you fancy a change \u2014 it saves automatically and applies everywhere. The green/amber/red/blue status colours you use for badges stay exactly as they are, so nothing you rely on for colour-blind-safe reading is affected.";
  bd.appendChild(note);

  var grid = document.createElement("div");
  grid.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:10px";

  var current = loadThemeKey();

  function renderGrid() {
    grid.innerHTML = "";
    Object.keys(THEMES).forEach(function(key){
      var t = THEMES[key];
      var card = document.createElement("button");
      var isOn = (key === current);
      card.style.cssText = "text-align:left;cursor:pointer;padding:10px;border-radius:var(--rs);background:var(--surface);border:2px solid "+(isOn?"var(--navy)":"var(--border)")+";display:flex;flex-direction:column;gap:7px;font-family:inherit";
      var swatches = document.createElement("div");
      swatches.style.cssText = "display:flex;height:20px;border-radius:4px;overflow:hidden;border:1px solid var(--border)";
      [t.navy, t.accent, t.alt].forEach(function(c){
        var sw = document.createElement("div"); sw.style.cssText = "flex:1;background:"+c;
        swatches.appendChild(sw);
      });
      var lbl = document.createElement("div");
      lbl.style.cssText = "font-size:12px;font-weight:700;color:var(--text);display:flex;align-items:center;gap:5px";
      lbl.textContent = t.name+(isOn?"  \u2713":"");
      card.appendChild(swatches); card.appendChild(lbl);
      card.addEventListener("click", function(){
        applyThemeVars(key);
        saveThemeKey(key);
        current = key;
        renderGrid();
        toast("\u2713 "+t.name+" applied");
      });
      grid.appendChild(card);
    });
  }
  renderGrid();
  bd.appendChild(grid);

  box.appendChild(bd);
  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:2px solid var(--border);display:flex;justify-content:flex-end";
  var doneB = document.createElement("button"); doneB.style.cssText = "padding:8px 20px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; doneB.textContent = "Done";
  doneB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  foot.appendChild(doneB); box.appendChild(foot);
  overlay.appendChild(box); document.body.appendChild(overlay);
}

// ── ADMIN ─────────────────────────────────────────────────────────

function loadArchive() {
  try { var r = localStorage.getItem(ARCHIVE_STORE); if(r) return JSON.parse(r); } catch(e) {}
  return [];
}
function saveArchive() {
  try { localStorage.setItem(ARCHIVE_STORE, JSON.stringify(archivedClients)); } catch(e) {}
  sbSaveAll("archived_clients", archivedClients, "id");
}

function showAdmin() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:360px;border-top:3px solid #e8a020";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "\uD83D\uDD12 Admin Access";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:10px";
  var lbl = document.createElement("div"); lbl.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:3px"; lbl.textContent = "Re-enter your CRM password";
  bd.appendChild(lbl);

  var wrap = document.createElement("div"); wrap.style.cssText = "position:relative";
  var pwInp = document.createElement("input"); pwInp.id = "admin_pw_check"; pwInp.type = "password"; pwInp.placeholder = "Enter password";
  pwInp.autocomplete = "current-password"; pwInp.autocorrect = "off"; pwInp.autocapitalize = "none";
  pwInp.style.cssText = "width:100%;padding:8px 40px 8px 10px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;color:var(--text);outline:none";
  var eye = document.createElement("button"); eye.type = "button"; eye.textContent = "\uD83D\uDC41";
  eye.style.cssText = "position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:15px;padding:0;line-height:1";
  eye.addEventListener("click", function(){ pwInp.type = pwInp.type==="password" ? "text" : "password"; eye.textContent = pwInp.type==="password" ? "\uD83D\uDC41" : "\uD83D\uDE48"; });
  wrap.appendChild(pwInp); wrap.appendChild(eye);
  bd.appendChild(wrap);
  box.appendChild(bd);

  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 16px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var unlockB = document.createElement("button"); unlockB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; unlockB.textContent = "Unlock";
  function attemptUnlock(){
    var entered = pwInp.value;
    if (entered !== getCurrentPassword()) {
      toast("Incorrect password \u2014 Admin access denied");
      return;
    }
    document.body.removeChild(overlay);
    showAdminPanel();
  }
  unlockB.addEventListener("click", attemptUnlock);
  pwInp.addEventListener("keydown", function(e){ if(e.key==="Enter") attemptUnlock(); });
  foot.appendChild(cancelB); foot.appendChild(unlockB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ pwInp.focus(); }, 100);
}

function showAdminPanel() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:520px;max-height:92vh;overflow-y:auto;border-top:3px solid #e8a020";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #e8a020";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:14px;font-weight:700;color:#fff"; bht.textContent = "\u2699\uFE0F Admin";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:12px";

  function adminSection(icon, title2, desc, btnLabel, btnColor, clickFn) {
    var card = document.createElement("div");
    card.style.cssText = "background:var(--alt);border:2px solid var(--border);border-radius:var(--r);padding:14px 16px;display:flex;align-items:center;gap:12px";
    var ico = document.createElement("div"); ico.style.cssText = "font-size:24px;flex-shrink:0"; ico.textContent = icon;
    var info = document.createElement("div"); info.style.flex = "1";
    var t = document.createElement("div"); t.style.cssText = "font-weight:700;font-size:13px;margin-bottom:2px"; t.textContent = title2;
    var d = document.createElement("div"); d.style.cssText = "font-size:11px;color:var(--muted);line-height:1.4"; d.textContent = desc;
    info.appendChild(t); info.appendChild(d);
    var btn = document.createElement("button");
    btn.style.cssText = "padding:7px 14px;background:"+btnColor+";border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer;flex-shrink:0;white-space:nowrap";
    btn.textContent = btnLabel;
    btn.addEventListener("click", function(){ clickFn(overlay); });
    card.appendChild(ico); card.appendChild(info); card.appendChild(btn);
    return card;
  }

  // Data summary
  var summary = document.createElement("div");
  summary.style.cssText = "background:#eef1f8;border-radius:var(--rs);padding:12px 14px;display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center";
  var totalInts = 0; clients.forEach(function(c){ totalInts += (c.log||[]).length; });
  [
    {l:"Clients", v:clients.length},
    {l:"Reps", v:reps.length},
    {l:"Interactions", v:totalInts},
    {l:"Samples", v:samples.length},
    {l:"Quotes", v:clients.reduce(function(a,c){return a+(c.log||[]).filter(function(l){return l.quote;}).length;},0)},
    {l:"Archived", v:archivedClients.length}
  ].forEach(function(s){
    var item = document.createElement("div");
    var val = document.createElement("div"); val.style.cssText = "font-size:18px;font-weight:700;color:var(--navy)"; val.textContent = s.v;
    var lbl = document.createElement("div"); lbl.style.cssText = "font-size:10px;color:var(--muted)"; lbl.textContent = s.l;
    item.appendChild(val); item.appendChild(lbl); summary.appendChild(item);
  });
  bd.appendChild(summary);

  // Divider
  function divider(txt) { var d=document.createElement("div"); d.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);padding-top:4px"; d.textContent=txt; return d; }

  // MANAGE PRODUCTS & CATEGORIES
  bd.appendChild(divider("Sales Data"));
  bd.appendChild(adminSection("\uD83D\uDCE6", "Manage products & categories", "Add, rename or remove products, and the manufacturer/category lists under each.", "Manage", "var(--navy)", function(){
    showProductManager();
  }));

  // IMPORT SAVED SITES (one-time bookmark import)
  bd.appendChild(divider("Import / Export"));
  bd.appendChild(adminSection("\uD83D\uDD16", "Import saved sites", "Add 55 trade websites from your browser bookmarks export. Skips any URL already in your list — safe to click more than once.", "Import sites", "#2d6a0f", function(){
    var importData = [{"name": "FLOORMART", "url": "https://floormart.co.uk/spotnails-staplers-staples/", "description": "", "category": "OTHER SUPPLIERS", "icon": "🌐"}, {"name": "RS Bateman", "url": "https://www.rsbateman.co.uk/", "description": "", "category": "OTHER SUPPLIERS", "icon": "🌐"}, {"name": "RWS", "url": "https://www.carpetfittersshoponline.co.uk/", "description": "", "category": "OTHER SUPPLIERS", "icon": "🌐"}, {"name": "Underlay for Carpet, Laminate & Wooden Floors - Carpet Underlay", "url": "https://www.carpet-underlay-shop.co.uk/", "description": "", "category": "OTHER SUPPLIERS", "icon": "🌐"}, {"name": "Spotnails", "url": "https://spotnails.co.uk/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Roberts Flooring Tools & Accessories", "url": "https://robertstools.co.uk/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Janser | Flooring Tools and Machines | Professional Range", "url": "https://www.janseruk.com/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Sweeney Todd Blades – Tools for the flooring industry", "url": "https://sweeneytoddblades.com/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Toolbank B2B | Home", "url": "https://www.toolbankb2b.com/HomeLogin", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Tools -Genesis", "url": "https://www.genesis-gs.com/products/tools-1", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Orion Tools UK", "url": "https://www.oriontools.uk/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Aspli Safety Limited | Leeds | UK", "url": "https://www.aspli.com/", "description": "", "category": "Safety", "icon": "🌐"}, {"name": "The Floorstore | Facebook", "url": "https://www.facebook.com/floorstoretrade/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "B&Q", "url": "https://www.diy.com/?msockid=3fdcfd62845f6fc4255feb8b85ee6e1b", "description": "", "category": "DIY", "icon": "🌐"}, {"name": "Wickes DIY", "url": "https://www.wickes.co.uk/?msockid=3fdcfd62845f6fc4255feb8b85ee6e1b", "description": "", "category": "DIY", "icon": "🌐"}, {"name": "danfloor -", "url": "https://www.danfloor.co.uk/ranges/evolution-collection/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "DANFLOOR", "url": "https://www.danfloor.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Nordikka", "url": "https://www.nordikka.co.uk/original", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Best at Flooring", "url": "https://www.bestatflooring.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "14mm Honey Oak Brown Natural Oil Click | Best at Flooring", "url": "https://www.bestatflooring.co.uk/p/14mm-honey-oak-brown-natural-oil-engineered-click/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Altro | Flooring Manufacturers & Wall Cladding Suppliers | Altro UK", "url": "https://www.altro.com/uk", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Ardex UK | Quality Building Adhesives & Products", "url": "https://ardex.co.uk/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Artisan Luxury Flooring", "url": "https://artisanluxuryflooring.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "BIHUI", "url": "https://www.bihuitools.com/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Broadloom carpet & vinyl flooring | Associated Weavers", "url": "https://associated-weavers.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Burmatex | Elevate Your Space", "url": "https://www.burmatex.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Cormar Carpets: Award Winning Quality Carpet Manufacturer", "url": "https://www.cormarcarpets.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Dashboard ‹ Floorstore Trade", "url": "https://trade.floorstoreonline.co.uk/wp-admin/index.php", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Durham -Duplex", "url": "https://www.durham-duplex.co.uk/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "Explora Flooring | Discover Quality Flooring Today", "url": "https://www.exploraflooring.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "F. Ball | Flooring Adhesives and Floor Preparation Products", "url": "https://f-ball.com/en/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Heckmondwike FB | Commercial Carpets | Education | Apartments | Offices", "url": "https://heckmondwike-fb.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Home - Canva", "url": "https://www.canva.com/", "description": "", "category": "WEB/ EDIT", "icon": "🌐"}, {"name": "Home - ROBERTS®USA", "url": "https://www.robertsconsolidated.com/", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "How to Measure for Design Strips", "url": "https://storiesflooring.co.uk/pages/how-to-measure-for-strips", "description": "", "category": "TOOLS", "icon": "🌐"}, {"name": "HUGH MACKAY", "url": "https://www.hughmackay.co.uk/residential/hugh-mackay-carpets/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Kelmore", "url": "https://kelmore.co.uk/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Kerakoll | Products and Solutions for Construction", "url": "https://gb.kerakoll.com/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Leigh Spinners Ltd - Sport, Landscape & Floorcovering Manufacturer", "url": "https://www.leighspinners.com/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Likewise Floors", "url": "https://likewisefloors.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Loxwood Industrial Papers Ltd", "url": "https://loxwoodpaper.com/", "description": "", "category": "Misc Supplier", "icon": "🌐"}, {"name": "Luxury German Kitchens Barnsley | Square Kitchens - Barnsley", "url": "https://germankitchensatsquare.co.uk/", "description": "", "category": "Customer", "icon": "🌐"}, {"name": "Luxury Vinyl Flooring for your home | Amtico Flooring", "url": "https://www.amtico.com/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Mapei", "url": "https://www.mapei.com/ae/en/products-and-solutions/products/screeds-and-preparation-of-floor-substrates/admixtures-and-fibres-for-screeds", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Margin Calculator", "url": "https://www.omnicalculator.com/finance/margin", "description": "", "category": "WEB/ EDIT", "icon": "🌐"}, {"name": "Mercado On-line ordering", "url": "https://www.mercado.co.uk/message.aspx", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Polyflor | Polyflor", "url": "https://www.polyflor.com/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Quick-Step: Quality laminate, vinyl & wood floors", "url": "https://www.quick-step.co.uk/en-gb", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Sanders & Fink | home of stunning, sustainably sourced products", "url": "https://sandersandfink.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "STAUF - Adhesive technology since 1828 | STAUF", "url": "https://stauf.de/en/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "TARKETT", "url": "https://www.tarkett.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "TradeChoice Carpet & Flooring | Leading UK supplier of floorcoverings", "url": "https://www.tradechoice.com/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "UK Floor Supplies", "url": "https://ukfloorsupplies.co.uk/", "description": "", "category": "Flooring", "icon": "🌐"}, {"name": "Uzin, United Kingdom: UZIN. THE FLOOR BELONGS TO YOU. Expert solutions for screed preparation, flooring and parquet", "url": "https://uk.uzin.com/", "description": "", "category": "Screed & Adhesive", "icon": "🌐"}, {"name": "Victoria Carpets", "url": "https://www.victoriacarpets.com/", "description": "", "category": "Flooring", "icon": "🌐"}];
    var existingUrls = {}; websites.forEach(function(w){ existingUrls[w.url] = true; });
    var added = 0;
    importData.forEach(function(site, idx){
      if (!existingUrls[site.url]) {
        site.id = "WEB-" + Date.now() + "-" + idx;
        websites.push(site); existingUrls[site.url] = true; added++;
      }
    });
    saveWebsites();
    toast(added + " site" + (added!==1?"s":"") + " imported" + (added < importData.length ? " (" + (importData.length-added) + " already existed)" : ""));
  }));
  bd.appendChild(adminSection("\uD83D\uDCE5", "Export all websites", "Download every saved trade website as a CSV \u2014 name, URL, category, description.", "Export Websites", "var(--navy)", function(){
    exportWebsitesCSV();
  }));
  bd.appendChild(adminSection("\uD83D\uDCE5", "Export all clients", "Download a simple CSV of every client \u2014 name and phone number only.", "Export Clients", "var(--navy)", function(){
    exportClientsCSV();
  }));
  bd.appendChild(adminSection("\uD83D\uDCE5", "Export all Reps /Asm's", "Download a simple CSV of every rep \u2014 name, phone number and email.", "Export Reps", "var(--navy)", function(){
    exportRepsCSV();
  }));

  // DIARY (export / wipe by category)
  // MANUFACTURERS
  bd.appendChild(divider("Manage Manufacturers"));
  bd.appendChild(adminSection("\uD83C\uDFED", "Manufacturers list", "Add or remove manufacturers shown in the Rep/ASM form dropdown. Core defaults are always preserved — changes add or remove on top.", "Manage", "var(--navy)", function(){
    document.body.removeChild(overlay);
    showListEditor({
      title: "Manufacturers",
      icon: "\uD83C\uDFED",
      getList: function(){ return MANUFACTURERS; },
      setList: function(arr){ var copy=arr.slice(); MANUFACTURERS.length=0; copy.forEach(function(v){MANUFACTURERS.push(v);}); saveManufacturers(); },
      placeholder: "e.g. Kahrs",
      note: "Used in the Rep/ASM form — manufacturer dropdown."
    });
  }));

  // CLIENT CATEGORIES
  bd.appendChild(divider("Manage Categories"));
  bd.appendChild(adminSection("\uD83C\uDFF7", "Client source categories", "Add or remove the options shown in the 'Customer source' dropdown on the client form.", "Manage", "var(--navy)", function(){
    document.body.removeChild(overlay);
    showListEditor({
      title: "Client Source Categories",
      icon: "\uD83C\uDFF7",
      getList: function(){ return CLIENT_CATS; },
      setList: function(arr){ var copy=arr.slice(); CLIENT_CATS.length=0; copy.forEach(function(v){CLIENT_CATS.push(v);}); saveClientCats(); },
      placeholder: "e.g. New - Trade Show",
      note: "Used in the client form — Customer source dropdown."
    });
  }));
  bd.appendChild(adminSection("\uD83D\uDCC2", "Document categories", "Add or remove categories shown in the Documents page and the Add Document form — e.g. Moduleo Docs, Install Guides, Warranties.", "Manage", "var(--navy)", function(){
    document.body.removeChild(overlay);
    showListEditor({
      title: "Document Categories",
      icon: "\uD83D\uDCC2",
      getList: function(){ return DOC_CATS; },
      setList: function(arr){ var copy=arr.slice(); DOC_CATS.length=0; copy.forEach(function(v){DOC_CATS.push(v);}); saveDocCats(); },
      placeholder: "e.g. Moduleo Docs",
      note: "Used in the Documents page category filter and the Add Document form."
    });
  }));

  bd.appendChild(divider("Diary"));
  bd.appendChild(adminSection("\uD83D\uDCC5", "Export personal entries", "Download a CSV of personal diary entries and birthdays \u2014 your own backup, kept separate from work data.", "Export Personal", "#9333ea", function(){
    exportPersonalData();
  }));
  bd.appendChild(adminSection("\uD83D\uDCC2", "Import personal entries", "Bring back personal diary entries and birthdays/anniversaries from a previously exported CSV file.", "Choose file", "#9333ea", function(){
    var inp = document.createElement("input"); inp.type = "file"; inp.accept = ".csv";
    inp.addEventListener("change", function(){
      if (!this.files || !this.files[0]) return;
      importPersonalDataFile(this.files[0]);
    });
    inp.click();
  }));
  bd.appendChild(adminSection("\uD83E\uDDF9", "Wipe personal only", "Permanently delete personal-tagged diary entries and birthdays. Work entries are untouched. Export first if you want a copy.", "Wipe Personal", "#9333ea", function(){
    openWipeConfirm("personal");
  }));
  bd.appendChild(adminSection("\uD83E\uDDF9", "Wipe work only", "Permanently delete work-tagged diary entries and birthdays. Personal entries are untouched.", "Wipe Work", "var(--navy)", function(){
    openWipeConfirm("work");
  }));
  bd.appendChild(adminSection("\u26A0\uFE0F", "Wipe everything", "Permanently delete ALL diary entries and birthdays \u2014 work and personal alike. Cannot be undone.", "Wipe Everything", "#c0392b", function(){
    openWipeConfirm("all");
  }));

  // QUOTES
  bd.appendChild(divider("Quotes"));
  bd.appendChild(adminSection("\uD83D\uDDD1", "Wipe all quotes", "Permanently delete every quote from every client (Quote, Confirmed, Paid, Collected, Lost, Expired - all statuses). Plain interactions without a quote attached are untouched. Cannot be undone.", "Wipe All Quotes", "#c0392b", function(){
    openWipeQuotesConfirm();
  }));

  // BACKUP
  bd.appendChild(divider("Backup & Restore"));
  bd.appendChild(adminSection("\uD83D\uDCBE", "Backup to device", "Download all your data as a file — save to your device, USB drive or cloud storage", "Download backup", "var(--navy)", function(){
    var data = {
      version: "SPCRM-v1",
      exported: new Date().toISOString(),
      clients: clients, reps: reps, samples: samples,
      birthdays: birthdays, complaints: complaints,
      diaryEvents: diaryEvents, websites: websites,
      docs: docs, archivedClients: archivedClients,
      tasks: tasks, enquiries: enquiries, sourcing: sourcing
    };
    var blob = new Blob([JSON.stringify(data, null, 2)], {type:"application/json"});
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = "CRM-backup-"+new Date().toISOString().split("T")[0]+".json";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast("\u2713 Backup downloaded!");
  }));

  bd.appendChild(adminSection("\uD83D\uDCC2", "Restore from backup", "Import a previously downloaded backup file to restore your data", "Choose file", "#2ecc71", function(){
    var inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json";
    inp.addEventListener("change", function(){
      if(!this.files||!this.files[0]) return;
      var reader = new FileReader();
      reader.onload = function(e){
        try {
          var data = JSON.parse(e.target.result);
          if(!data.version||!data.version.startsWith("SPCRM")) { toast("\u26A0\uFE0F Invalid backup file"); return; }
          if(!confirm("This will replace ALL your current data with the backup. Are you sure?")) return;
          if(data.clients) { clients = data.clients; saveC(); }
          if(data.reps) { reps = data.reps; saveReps(); }
          if(data.samples) { samples = data.samples; saveSamples(); }
          if(data.birthdays) { birthdays = data.birthdays; saveBirthdays(); }
          if(data.complaints) { complaints = data.complaints; saveComplaints(); }
          if(data.diaryEvents) { diaryEvents = data.diaryEvents; saveDiary(); }
          if(data.websites) { websites = data.websites; saveWebsites(); }
          if(data.docs) { docs = data.docs; saveDocs(); }
          if(data.archivedClients) { archivedClients = data.archivedClients; saveArchive(); }
          if(data.tasks) { tasks = data.tasks; saveTasks(); }
          if(data.enquiries) { enquiries = data.enquiries; saveEnquiries(); }
          if(data.sourcing) { sourcing = data.sourcing; saveSourcing(); }
          renderList(); renderDash(); updateStats();
          toast("\u2713 Backup restored successfully!");
        } catch(err) { toast("\u26A0\uFE0F Error reading backup file"); }
      };
      reader.readAsText(this.files[0]);
    });
    inp.click();
  }));

  // ARCHIVE
  bd.appendChild(divider("Archive"));
  bd.appendChild(adminSection("\uD83D\uDDC4\uFE0F", "Archive inactive clients", "Move Lost or On Hold clients to archive — keeps your main list clean. Can restore anytime.", "Archive inactive", "#e67e22", function(){
    var toArchive = clients.filter(function(c){ return c.status==="Lost"||c.status==="Closed"; });
    if(!toArchive.length){ toast("No Lost or Closed clients to archive"); return; }
    if(!confirm("Archive "+toArchive.length+" Lost/Closed clients? They can be restored anytime.")) return;
    archivedClients = archivedClients.concat(toArchive);
    clients = clients.filter(function(c){ return c.status!=="Lost"&&c.status!=="Closed"; });
    saveC(); saveArchive(); renderList(); updateStats();
    toast("\u2713 "+toArchive.length+" clients archived");
  }));

  bd.appendChild(adminSection("\uD83D\uDD04", "View & restore archive", "See all archived clients and restore any of them back to your main list", "View archive ("+archivedClients.length+")", "#9b59b6", function(ov){
    document.body.removeChild(ov);
    showArchiveView();
  }));

  // SECURITY
  bd.appendChild(divider("Security & Settings"));
  bd.appendChild(adminSection("\u26A0\uFE0F", "Wipe all clients", "Permanently delete ALL clients from this device and Supabase. Cannot be undone.", "Wipe all clients", "#c0392b", function(ov){
    if(confirm("WARNING: This will permanently delete ALL "+clients.length+" clients from both this device and Supabase.\n\nThis CANNOT be undone.\n\nAre you absolutely sure?")){
      if(confirm("Last chance — delete all "+clients.length+" clients?")){
        clients=[];
        try{localStorage.setItem(STORE,JSON.stringify([]));localStorage.setItem(ARCHIVE_STORE,JSON.stringify([]));}catch(e){}
        fetch(SB_URL+"/rest/v1/clients?id=neq.NEVER",{method:"DELETE",headers:{"apikey":SB_KEY,"Authorization":"Bearer "+SB_KEY}})
          .then(function(){toast("All clients wiped \u2713");updateStats();renderList();showDash();document.body.removeChild(ov);})
          .catch(function(){toast("Wiped locally");updateStats();renderList();showDash();document.body.removeChild(ov);});
      }
    }
  }));
  bd.appendChild(divider("Personalisation"));
  bd.appendChild(adminSection("\uD83C\uDFA8", "Colour theme", "Change the CRM's colour scheme any time you get bored of the current look. Your status badges stay colour-blind-safe whichever theme you pick.", "Change theme", "var(--navy)", function(ov){
    showThemePicker(ov);
  }));

  bd.appendChild(adminSection("\uD83D\uDD12", "Change password", "Update your CRM login password", "Change", "var(--navy)", function(ov){
    document.body.removeChild(ov);
    showChangePassword();
  }));

  bd.appendChild(adminSection("\uD83D\uDCF7", "Business card scanner", "Add your Anthropic API key to enable AI business card scanning (console.anthropic.com)", getApiKey()?"Key saved \u2713":"Add API key", getApiKey()?"#2ecc71":"#e67e22", function(){
    var key = prompt("Enter your Anthropic API key (from console.anthropic.com):\n\nLeave blank to remove existing key.");
    if(key===null) return;
    if(key.trim()==="") { setApiKey(""); toast("API key removed"); return; }
    if(!key.trim().startsWith("sk-")) { toast("Invalid key — should start with sk-"); return; }
    setApiKey(key.trim()); toast("\u2713 API key saved");
  }));

  // Footer with close button
  var adminFoot = document.createElement("div");
  adminFoot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:var(--alt)";
  var closeAdminBtn = document.createElement("button");
  closeAdminBtn.style.cssText = "padding:8px 20px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  closeAdminBtn.textContent = "\u2190 Back to dashboard";
  closeAdminBtn.addEventListener("click", function(){ document.body.removeChild(overlay); showDash(); });
  var closeBtn2 = document.createElement("button");
  closeBtn2.style.cssText = "padding:8px 16px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer";
  closeBtn2.textContent = "\u00d7 Close";
  closeBtn2.addEventListener("click", function(){ document.body.removeChild(overlay); });
  adminFoot.appendChild(closeAdminBtn); adminFoot.appendChild(closeBtn2);
  box.appendChild(bd); box.appendChild(adminFoot);
  overlay.appendChild(box); document.body.appendChild(overlay);
}

function pmSmallBtn(txt, bg) {
  var b = document.createElement("button");
  b.textContent = txt;
  b.style.cssText = "padding:6px 11px;background:" + bg + ";border:none;border-radius:var(--rs);color:#fff;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0";
  return b;
}

function showProductManager() {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.65);z-index:300;display:flex;align-items:center;justify-content:center;padding:16px";

  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:560px;max-height:90vh;display:flex;flex-direction:column;border-top:3px solid var(--navy)";

  var bh = document.createElement("div");
  bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0";
  var bht = document.createElement("h2");
  bht.style.cssText = "font-size:14px;font-weight:700;color:#fff";
  bht.textContent = "Manage Products & Categories";
  var cx = document.createElement("button");
  cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer;line-height:1";
  cx.textContent = "\u00d7";
  cx.addEventListener("click", function () { document.body.removeChild(overlay); });
  bh.appendChild(bht);
  bh.appendChild(cx);
  box.appendChild(bh);

  var bd = document.createElement("div");
  bd.style.cssText = "padding:16px 18px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:10px";
  box.appendChild(bd);

  var pmExpanded = null;
  var pmRangeExpanded = null; // key: prodName + "::" + itemName, identifies which item's ranges panel is open

  function pmRenderList() {
    bd.innerHTML = "";

    var addWrap = document.createElement("div");
    addWrap.style.cssText = "background:var(--alt);border:2px solid var(--border);border-radius:var(--rs);padding:10px;display:flex;gap:6px;flex-shrink:0";
    var addInp = document.createElement("input");
    addInp.placeholder = "New product name, e.g. Skirting Board";
    addInp.style.cssText = "flex:1;padding:6px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
    var addBtn = pmSmallBtn("+ Add product", "var(--navy)");
    addBtn.addEventListener("click", function () {
      var v = addInp.value.trim();
      if (!v) { toast("Enter a product name"); return; }
      if (PRODUCTS.indexOf(v) > -1) { toast("That product already exists"); return; }
      PRODUCTS.push(v);
      sortProductsList(PRODUCTS);
      saveProducts();
      toast("Added");
      pmRenderList();
    });
    addInp.addEventListener("keydown", function (e) { if (e.key === "Enter") { addBtn.click(); } });
    addWrap.appendChild(addInp);
    addWrap.appendChild(addBtn);
    bd.appendChild(addWrap);

    for (var pi = 0; pi < PRODUCTS.length; pi++) {
      var prodName = PRODUCTS[pi];
      pmRenderProductCard(prodName);
    }
  }

  function pmRenderProductCard(prodName) {
    var hasSubcats = !!PRODUCT_SUBCATS[prodName];
    var card = document.createElement("div");
    card.style.cssText = "border:2px solid var(--border);border-radius:var(--rs);overflow:hidden;flex-shrink:0";

    var head = document.createElement("div");
    var headBg = (pmExpanded === prodName) ? "var(--alt)" : "#fff";
    head.style.cssText = "display:flex;align-items:center;gap:8px;padding:9px 11px;background:" + headBg + ";cursor:pointer";

    var chevDeg = (pmExpanded === prodName) ? "90" : "0";
    var chev = document.createElement("span");
    chev.style.cssText = "font-size:10px;color:var(--muted);transform:rotate(" + chevDeg + "deg);display:inline-block";
    chev.textContent = "\u25B8";

    var nameSpan = document.createElement("span");
    nameSpan.style.cssText = "font-size:13px;font-weight:700;flex:1";
    nameSpan.textContent = prodName;

    head.appendChild(chev);
    head.appendChild(nameSpan);

    if (hasSubcats) {
      var countTag = document.createElement("span");
      countTag.style.cssText = "font-size:10px;color:var(--muted);background:var(--alt);padding:2px 7px;border-radius:10px";
      countTag.textContent = PRODUCT_SUBCATS[prodName].length + " items";
      head.appendChild(countTag);
    }

    var delBtn = document.createElement("button");
    delBtn.textContent = "\uD83D\uDDD1";
    delBtn.title = "Remove this product";
    delBtn.style.cssText = "background:none;border:none;color:var(--rtxt);font-size:14px;cursor:pointer;padding:2px 4px;flex-shrink:0";
    delBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      var ok = confirm("Remove \"" + prodName + "\" from the product list?");
      if (!ok) { return; }
      PRODUCTS = PRODUCTS.filter(function (p) { return p !== prodName; });
      if (PRODUCT_SUBCATS[prodName]) { delete PRODUCT_SUBCATS[prodName]; saveProductSubcats(); }
      saveProducts();
      if (pmExpanded === prodName) { pmExpanded = null; }
      toast("Removed");
      pmRenderList();
    });
    head.appendChild(delBtn);

    head.addEventListener("click", function () {
      pmExpanded = (pmExpanded === prodName) ? null : prodName;
      pmRenderList();
    });
    card.appendChild(head);

    if (pmExpanded === prodName) {
      var sub = pmRenderSubcatPanel(prodName, hasSubcats);
      card.appendChild(sub);
    }

    bd.appendChild(card);
  }

  function pmRenderSubcatPanel(prodName, hasSubcats) {
    var sub = document.createElement("div");
    sub.style.cssText = "padding:10px 11px;border-top:1px solid var(--border);background:#fafbfd;display:flex;flex-direction:column;gap:6px";

    if (!hasSubcats) {
      var enableBtn = pmSmallBtn("+ Add a category list for this product", "var(--navy)");
      enableBtn.addEventListener("click", function () {
        PRODUCT_SUBCATS[prodName] = [];
        saveProductSubcats();
        pmRenderList();
      });
      sub.appendChild(enableBtn);
      return sub;
    }

    var items = PRODUCT_SUBCATS[prodName];
    for (var ii = 0; ii < items.length; ii++) {
      sub.appendChild(pmRenderItemRow(prodName, ii));
    }

    var addItemWrap = document.createElement("div");
    addItemWrap.style.cssText = "display:flex;gap:6px;margin-top:2px";
    var newNameInp = document.createElement("input");
    newNameInp.placeholder = "New item name";
    newNameInp.style.cssText = "flex:1;padding:6px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
    var addItemBtn = pmSmallBtn("+ Add", "#2d6a0f");
    addItemBtn.addEventListener("click", function () {
      var v = newNameInp.value.trim();
      if (!v) { toast("Enter a name"); return; }
      PRODUCT_SUBCATS[prodName].push({ name: v, note: "" });
      saveProductSubcats();
      pmRenderList();
    });
    newNameInp.addEventListener("keydown", function (e) { if (e.key === "Enter") { addItemBtn.click(); } });
    addItemWrap.appendChild(newNameInp);
    addItemWrap.appendChild(addItemBtn);
    sub.appendChild(addItemWrap);

    var removeListBtn = document.createElement("button");
    removeListBtn.textContent = "Remove category list entirely";
    removeListBtn.style.cssText = "background:none;border:none;color:var(--rtxt);font-size:10px;cursor:pointer;text-decoration:underline;align-self:flex-start;margin-top:4px;padding:0";
    removeListBtn.addEventListener("click", function () {
      var ok = confirm("Remove the whole category list for " + prodName + "?");
      if (!ok) { return; }
      delete PRODUCT_SUBCATS[prodName];
      saveProductSubcats();
      pmRenderList();
    });
    sub.appendChild(removeListBtn);

    return sub;
  }

  function pmRenderItemRow(prodName, idx) {
    var item = PRODUCT_SUBCATS[prodName][idx];
    var rangeKey = prodName + "::" + item.name;
    var hasRanges = !!(item.ranges && item.ranges.length);
    var isRangeOpen = (pmRangeExpanded === rangeKey);

    var container = document.createElement("div");
    container.style.cssText = "display:flex;flex-direction:column;gap:0;flex-shrink:0";

    var itemRow = document.createElement("div");
    itemRow.style.cssText = "display:flex;gap:6px;align-items:center;background:#fff;border:2px solid var(--border);border-radius:var(--rs);padding:5px 7px";

    var nameInp = document.createElement("input");
    nameInp.value = item.name;
    nameInp.placeholder = "Name";
    nameInp.style.cssText = "flex:1;border:none;outline:none;font-size:12px;font-family:inherit;min-width:0";

    var noteInp = document.createElement("input");
    noteInp.value = item.note || "";
    noteInp.placeholder = "Optional note";
    noteInp.style.cssText = "flex:1.4;border:none;outline:none;font-size:11px;font-family:inherit;color:var(--muted);min-width:0";

    function commitEdit() {
      item.name = nameInp.value.trim() || item.name;
      item.note = noteInp.value.trim();
      saveProductSubcats();
    }
    nameInp.addEventListener("blur", commitEdit);
    noteInp.addEventListener("blur", commitEdit);

    var rangeBtn = document.createElement("button");
    rangeBtn.type = "button";
    rangeBtn.textContent = hasRanges ? ("\u25B8 " + item.ranges.length) : "+ Ranges";
    rangeBtn.title = "Manage ranges for this item";
    rangeBtn.style.cssText = "background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:10px;cursor:pointer;flex-shrink:0;padding:3px 7px;white-space:nowrap";
    rangeBtn.addEventListener("click", function () {
      pmRangeExpanded = isRangeOpen ? null : rangeKey;
      pmRenderList();
    });

    var rmBtn = document.createElement("button");
    rmBtn.textContent = "\u00d7";
    rmBtn.style.cssText = "background:none;border:none;color:var(--rtxt);font-size:15px;cursor:pointer;flex-shrink:0;padding:0 3px";
    rmBtn.addEventListener("click", function () {
      PRODUCT_SUBCATS[prodName].splice(idx, 1);
      saveProductSubcats();
      pmRenderList();
    });

    itemRow.appendChild(nameInp);
    itemRow.appendChild(noteInp);
    itemRow.appendChild(rangeBtn);
    itemRow.appendChild(rmBtn);
    container.appendChild(itemRow);

    if (isRangeOpen) {
      container.appendChild(pmRenderRangePanel(prodName, idx));
    }

    return container;
  }

  function pmRenderRangePanel(prodName, idx) {
    var item = PRODUCT_SUBCATS[prodName][idx];
    if (!item.ranges) { item.ranges = []; }

    var panel = document.createElement("div");
    panel.style.cssText = "padding:7px 7px 7px 18px;border:2px solid var(--border);border-top:none;border-radius:0 0 var(--rs) var(--rs);background:#fafbfd;display:flex;flex-direction:column;gap:5px";

    var label = document.createElement("div");
    label.style.cssText = "font-size:10px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.4px";
    label.textContent = "Ranges for " + item.name;
    panel.appendChild(label);

    item.ranges.forEach(function (rangeName, rangeIdx) {
      var rRow = document.createElement("div");
      rRow.style.cssText = "display:flex;gap:6px;align-items:center;background:#fff;border:2px solid var(--border);border-radius:var(--rs);padding:4px 6px";
      var rInp = document.createElement("input");
      rInp.value = rangeName;
      rInp.style.cssText = "flex:1;border:none;outline:none;font-size:12px;font-family:inherit;min-width:0";
      rInp.addEventListener("blur", function () {
        var v = rInp.value.trim();
        if (v) { item.ranges[rangeIdx] = v; saveProductSubcats(); }
      });
      var rRm = document.createElement("button");
      rRm.textContent = "\u00d7";
      rRm.style.cssText = "background:none;border:none;color:var(--rtxt);font-size:14px;cursor:pointer;flex-shrink:0;padding:0 3px";
      rRm.addEventListener("click", function () {
        item.ranges.splice(rangeIdx, 1);
        saveProductSubcats();
        pmRenderList();
      });
      rRow.appendChild(rInp);
      rRow.appendChild(rRm);
      panel.appendChild(rRow);
    });

    var addRow = document.createElement("div");
    addRow.style.cssText = "display:flex;gap:6px";
    var addInp = document.createElement("input");
    addInp.placeholder = "New range name, e.g. Cumulus";
    addInp.style.cssText = "flex:1;padding:5px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:12px;font-family:inherit;outline:none";
    var addBtn = pmSmallBtn("+ Add range", "#2d6a0f");
    addBtn.addEventListener("click", function () {
      var v = addInp.value.trim();
      if (!v) { toast("Enter a range name"); return; }
      item.ranges.push(v);
      saveProductSubcats();
      pmRenderList();
    });
    addInp.addEventListener("keydown", function (e) { if (e.key === "Enter") { addBtn.click(); } });
    addRow.appendChild(addInp);
    addRow.appendChild(addBtn);
    panel.appendChild(addRow);

    return panel;
  }


  pmRenderList();

  var foot = document.createElement("div");
  foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;flex-shrink:0";
  var doneBtn = document.createElement("button");
  doneBtn.textContent = "Done";
  doneBtn.style.cssText = "padding:8px 18px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer";
  doneBtn.addEventListener("click", function () { document.body.removeChild(overlay); });
  foot.appendChild(doneBtn);
  box.appendChild(foot);

  overlay.appendChild(box);
  document.body.appendChild(overlay);
}

function showArchiveView() {
  archivedClients = loadArchive();
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:500px;max-height:90vh;overflow-y:auto;border-top:3px solid #9b59b6";
  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:13px 16px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:13px;font-weight:700;color:#fff"; bht.textContent = "\uD83D\uDDC4\uFE0F Archived Clients ("+archivedClients.length+")";
  var cx = document.createElement("button"); cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; cx.textContent = "\u00d7";
  cx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(cx); box.appendChild(bh);
  var bd = document.createElement("div"); bd.style.cssText = "padding:14px";
  if(!archivedClients.length){
    var em = document.createElement("div"); em.className = "empty-state";
    em.innerHTML = "<div>\uD83D\uDDC4\uFE0F</div><div class='es-title'>No archived clients</div><div class='es-sub'>Archive Lost or Closed clients from the Admin panel to keep your main list clean</div>";
    bd.appendChild(em);
  } else {
    archivedClients.forEach(function(c, i){
      var row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border)";
      var av = document.createElement("div"); av.style.cssText = "width:30px;height:30px;border-radius:50%;background:var(--muted);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;flex-shrink:0"; av.textContent = ini(c.name);
      var info = document.createElement("div"); info.style.flex = "1";
      var nm = document.createElement("div"); nm.style.cssText = "font-weight:700;font-size:12px"; nm.textContent = c.name;
      var sub = document.createElement("div"); sub.style.cssText = "font-size:10px;color:var(--muted)"; sub.textContent = c.binder+" \u00b7 "+c.status;
      info.appendChild(nm); info.appendChild(sub);
      var restoreBtn = document.createElement("button");
      restoreBtn.style.cssText = "padding:4px 10px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:var(--rs);font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700";
      restoreBtn.textContent = "\u2190 Restore";
      restoreBtn.addEventListener("click", (function(idx){ return function(){
        var restored = archivedClients.splice(idx, 1)[0];
        restored.status = "Prospect";
        clients.push(restored);
        saveC(); saveArchive();
        sbDelete("archived_clients", restored.id);
        renderList(); updateStats();
        document.body.removeChild(overlay);
        toast(restored.name+" restored \u2713");
      }; })(i));
      var delBtn = document.createElement("button");
      delBtn.style.cssText = "padding:4px 8px;background:none;border:2px solid var(--border);border-radius:var(--rs);font-size:10px;color:var(--muted);cursor:pointer";
      delBtn.textContent = "\u00d7";
      delBtn.addEventListener("click", (function(idx){ return function(){
        if(confirm("Permanently delete "+archivedClients[idx].name+"? This cannot be undone.")){
          var deletedId = archivedClients[idx].id;
          archivedClients.splice(idx,1); saveArchive();
          sbDelete("archived_clients", deletedId);
          document.body.removeChild(overlay); showArchiveView();
          toast("Permanently deleted");
        }
      }; })(i));
      row.appendChild(av); row.appendChild(info); row.appendChild(restoreBtn); row.appendChild(delBtn);
      bd.appendChild(row);
    });
  }
  box.appendChild(bd);
  overlay.appendChild(box); document.body.appendChild(overlay);
}


// ── CHART HELPERS ──────────────────────────────────────────────────
var chartInstances = {}; // canvas id -> Chart.js instance, so we can destroy before re-creating
function mkBarChart(id, data4) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var cfg = {
    type: "bar",
    data: {
      labels: ["Q1 Jan-Mar","Q2 Apr-Jun","Q3 Jul-Sep","Q4 Oct-Dec"],
      datasets: [{
        label: "Sales",
        data: data4,
        backgroundColor: ["#305CDE","#C0392B","#305CDE","#C0392B"],
        borderRadius: 5
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: {
          ticks: {
            callback: function(v) { return "£" + v.toLocaleString(); }
          }
        }
      }
    }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}
function mkDailyBarChart(id, dayValues, year, month) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var today = new Date();
  var isCurrentMonth = today.getFullYear()===year && today.getMonth()===month;
  var labels = dayValues.map(function(v,i){return String(i+1);});
  var colors = dayValues.map(function(v,i){
    if (isCurrentMonth && (i+1)===today.getDate()) return "#e8a020";
    return "#305CDE";
  });
  var cfg = {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Sales",
        data: dayValues,
        backgroundColor: colors,
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { ticks: { callback: function(v) { return "£" + v.toLocaleString(); } } },
        x: { ticks: { font: { size: 9 } } }
      }
    }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}

function mkPieChart(id, labels, values) {
  var ctx = document.getElementById(id);
  if (!ctx) return;
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
  var colors = ["#305CDE","#C0392B","#2ecc71","#f39c12","#9b59b6","#1abc9c","#e67e22","#34495e","#16a085","#8e44ad","#2980b9","#27ae60","#d35400","#e74c3c","#95a5a6"];
  var total = values.reduce(function(a,b){return a+b;},0);
  var cfg = {
    type: "doughnut",
    data: {
      labels: labels,
      datasets: [{
        data: values,
        backgroundColor: colors,
        borderWidth: 2,
        borderColor: "#fff"
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "right",
          labels: {
            font: { size: 10 },
            boxWidth: 10,
            generateLabels: function(chart) {
              var d = chart.data;
              var tot = d.datasets[0].data.reduce(function(a,b){return a+b;},0);
              return d.labels.map(function(lbl,i) {
                var v = d.datasets[0].data[i];
                var pct = tot > 0 ? ((v/tot)*100).toFixed(1) : 0;
                return { text: lbl+" ("+pct+"%)", fillStyle: d.datasets[0].backgroundColor[i], hidden: false, index: i };
              });
            }
          }
        }
      }
    }
  };
  chartInstances[id] = new Chart(ctx.getContext("2d"), cfg);
}

// Opens a full-size overlay version of a pie/doughnut chart so small legends/slices are easier to read.
function showChartModal(title, labels, values) {
  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.75);z-index:400;display:flex;align-items:center;justify-content:center;padding:20px";

  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:680px;max-height:90vh;display:flex;flex-direction:column;border-top:3px solid var(--navy);overflow:hidden";

  var bh = document.createElement("div");
  bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0";
  var bht = document.createElement("h2");
  bht.style.cssText = "font-size:14px;font-weight:700;color:#fff";
  bht.textContent = title;
  var cx = document.createElement("button");
  cx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:28px;height:28px;color:#fff;font-size:18px;cursor:pointer;line-height:1";
  cx.textContent = "\u00d7";
  function closeChartModal() {
    if (chartInstances["modalPieCh"]) { chartInstances["modalPieCh"].destroy(); delete chartInstances["modalPieCh"]; }
    document.body.removeChild(overlay);
  }
  cx.addEventListener("click", closeChartModal);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) closeChartModal(); });
  bh.appendChild(bht);
  bh.appendChild(cx);
  box.appendChild(bh);

  var bd = document.createElement("div");
  bd.style.cssText = "padding:22px;flex:1;overflow-y:auto";
  var wrap = document.createElement("div");
  wrap.style.cssText = "position:relative;height:min(60vh,460px)";
  var can = document.createElement("canvas");
  can.id = "modalPieCh";
  wrap.appendChild(can);
  bd.appendChild(wrap);
  box.appendChild(bd);

  overlay.appendChild(box);
  document.body.appendChild(overlay);
  setTimeout(function () { mkPieChart("modalPieCh", labels, values); }, 50);
}


// ── MOBILE ────────────────────────────────────────────────────────
function isMobile() { return window.innerWidth <= 768; }



function closeMobSidebar() {
  var sb = document.getElementById("sidebar");
  if (sb.classList.contains("mob-open")) {
    sb.classList.remove("mob-open");
    document.getElementById("sbBackdrop").classList.remove("show");
    var btn = document.getElementById("mobMenuBtn");
    if (btn) btn.textContent = "\u2261 Clients";
  }
}

// Close sidebar when a client is opened on mobile
var origOpenC = openC;
openC = function(id) {
  closeMobSidebar();
  origOpenC(id);
};

// Close sidebar when nav buttons clicked on mobile
var navFns = ["showReps","showSales","showSamples","showBirthdays","showComplaints","showDiary","showQuotes","showDash","showEnquiries","showSourcing","showTasks","showClients"];
navFns.forEach(function(fn) {
  var orig = window[fn];
  window[fn] = function() { closeMobSidebar(); orig(); };
});


// ── INIT ──────────────────────────────────────────────────────────
function init(){
  clients=loadClients();reps=loadReps();samples=loadSamples();birthdays=loadBirthdays();complaints=loadComplaints();
  websites=loadWebsites();
  archivedClients=loadArchive();
  docs=loadDocs();
  enquiries=loadEnquiries();
  sourcing=loadSourcing();
  tasks=loadTasks();
  footfallEntries=loadFootfallEntries();
  diaryEvents=loadDiary();
  activeFilter="All";activeId=null;editId=null;showLF=false;pendingDel=null;
  updateStats();renderList();showDash();
  // Load from Supabase (cloud sync)
  loadFromSupabase();
}
if(typeof Notification!=="undefined"&&Notification.permission==="default"){Notification.requestPermission();}
init();
