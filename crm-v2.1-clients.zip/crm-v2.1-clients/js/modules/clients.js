/* CRM 2.1 — Clients module
   Extracted from the legacy application without changing behaviour.
   Classic script is intentional: existing inline onclick handlers use these globals. */

function showClients(){activeId=null;renderList();showView("clients");renderClientsView();}

function openC(id){activeId=id;showLF=false;detLogTab="Interactions";renderList();showView("det");renderDet();}

function setF(btn){document.querySelectorAll(".fb").forEach(function(b){b.classList.remove("on");});btn.classList.add("on");activeFilter=btn.dataset.f;renderList();}

function renderList(){
  var q=document.getElementById("sq").value.toLowerCase();
  var fl=clients.filter(function(c){
    var mq=!q||[c.name,c.binder,c.mobile,c.contact,c.mobile2,c.contact2].some(function(v){return(v||"").toLowerCase().indexOf(q)>-1;});
    return mq&&(activeFilter==="All"||c.status===activeFilter);
  }).sort(function(a,b){ return (a.name||"").localeCompare(b.name||"", undefined, {sensitivity:"base"}); });
  var el=document.getElementById("clist");
  if(!fl.length){
    var archivedMatch=q?archivedClients.filter(function(c){return[c.name,c.binder,c.mobile,c.contact,c.mobile2,c.contact2].some(function(v){return(v||"").toLowerCase().indexOf(q)>-1;});}):[];
    if(archivedMatch.length){
      el.innerHTML="";
      var archNote=document.createElement("div");archNote.style.cssText="padding:10px 12px;background:#f5f0ff;border:2px solid #9b59b6;border-radius:var(--rs);margin:8px;font-size:11px;color:#6c3483;font-weight:700";archNote.textContent="\uD83D\uDDC4\uFE0F "+archivedMatch.length+" archived result"+(archivedMatch.length>1?"s":"")+" found:";el.appendChild(archNote);
      archivedMatch.forEach(function(c){
        var card=document.createElement("div");card.style.cssText="padding:10px 12px;border-bottom:1px solid var(--border);cursor:pointer;background:#faf5ff";
        card.addEventListener("click",(function(ac){return function(){
          if(confirm(ac.name+" is archived.\nRestore to your active client list?")){
            var ai=archivedClients.findIndex(function(x){return x.id===ac.id;});
            if(ai>-1){archivedClients.splice(ai,1);ac.status="Prospect";clients.push(ac);saveC();saveArchive();sbDelete("archived_clients",ac.id);updateStats();renderList();toast(ac.name+" restored \u2713");}
          }
        };})(c));
        var nm=document.createElement("div");nm.style.cssText="font-weight:700;font-size:12px";nm.textContent="\uD83D\uDDC4\uFE0F "+c.name+" (Archived)";
        var sub=document.createElement("div");sub.style.cssText="font-size:10px;color:#9b59b6";sub.textContent=c.binder+" \u00b7 Tap to reinstate";
        card.appendChild(nm);card.appendChild(sub);el.appendChild(card);
      });
    } else {
      el.innerHTML="<div style='padding:20px;text-align:center;color:var(--muted);font-size:11px'>No clients found</div>";
    }
    return;}
  el.innerHTML="";
  fl.forEach(function(c){
    var d=du(c.followup);var dl=d<0?"Overdue":d===0?"Today":d<=3?d+"d":fd(c.followup)||"";var dc=d<0?"fdue":d<=3?"famb":"fok";
    var item=document.createElement("div");item.className="ci"+(c.id===activeId?" on":"");
    var top=document.createElement("div");top.className="ci-top";
    var av=document.createElement("div");av.className="av";av.textContent=ini(c.name);
    var info=document.createElement("div");
    var nm=document.createElement("div");nm.className="ci-name";nm.textContent=c.name;
    var ref=document.createElement("div");ref.className="ci-ref";ref.textContent=c.binder+" \u00b7 "+(c.contact||"\u2014");
    info.appendChild(nm);info.appendChild(ref);top.appendChild(av);top.appendChild(info);
    var meta=document.createElement("div");meta.className="ci-meta";
    var pill=document.createElement("span");pill.className="pl "+scls(c.status);pill.textContent=c.status;
    var st=document.createElement("span");st.className="stars";st.textContent=c.priority||"";
    meta.appendChild(pill);meta.appendChild(st);
    if(dl){var ft=document.createElement("span");ft.className="ftag "+dc;ft.textContent=dl;meta.appendChild(ft);}
    item.appendChild(top);item.appendChild(meta);
    item.addEventListener("click",(function(id){return function(){openC(id);};})(c.id));
    el.appendChild(item);
  });
}

function renderClientsView(searchTerm){
  var cv=document.getElementById("clientsView");cv.innerHTML="";
  var hdr=document.createElement("div");hdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px";
  var title=document.createElement("div");title.className="page-title";title.textContent="Clients";
  var addBtn=document.createElement("button");addBtn.style.cssText="padding:7px 16px;background:var(--red);border:none;border-radius:20px;color:#1a1a1a;font-size:12px;font-weight:700;cursor:pointer";addBtn.textContent="+ Add client";addBtn.addEventListener("click",function(){showForm();});
  hdr.appendChild(title);hdr.appendChild(addBtn);cv.appendChild(hdr);

  var sw=document.createElement("div");sw.style.cssText="display:flex;align-items:center;gap:8px;background:var(--surface);border:2px solid var(--navy);border-radius:var(--rs);padding:9px 12px;margin-bottom:12px;max-width:360px;box-shadow:0 1px 4px rgba(0,0,0,.06)";
  var sIcon=document.createElement("span");sIcon.textContent="\uD83D\uDD0D";sIcon.style.cssText="font-size:14px";
  var si=document.createElement("input");si.type="text";si.id="clientsSearch";si.placeholder="Search name, ref, phone...";si.value=searchTerm||"";
  si.style.cssText="background:none;border:none;outline:none;font-size:13px;color:var(--text);flex:1;min-width:0";
  si.addEventListener("input",function(){renderClientsView(this.value);});
  sw.appendChild(sIcon);sw.appendChild(si);cv.appendChild(sw);
  if(searchTerm){setTimeout(function(){var el=document.getElementById("clientsSearch");if(el){el.focus();el.selectionStart=el.selectionEnd=el.value.length;}},10);}

  var q=(searchTerm||"").toLowerCase();
  var statuses=["All","Active","Prospect","On Hold","Lost"];
  var clientsActiveStatus=window._clientsViewStatus||"All";
  var fbar=document.createElement("div");fbar.style.cssText="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px";
  statuses.forEach(function(s){
    var b=document.createElement("button");
    b.className="fb"+(clientsActiveStatus===s?" on":"");
    b.textContent=s;
    b.addEventListener("click",function(){window._clientsViewStatus=s;renderClientsView(si.value);});
    fbar.appendChild(b);
  });
  cv.appendChild(fbar);

  var filtered=clients.filter(function(c){
    var mq=!q||[c.name,c.binder,c.mobile,c.contact,c.mobile2,c.contact2].some(function(v){return(v||"").toLowerCase().indexOf(q)>-1;});
    var ms=clientsActiveStatus==="All"||c.status===clientsActiveStatus;
    return mq&&ms;
  }).sort(function(a,b){return(a.name||"").localeCompare(b.name||"",undefined,{sensitivity:"base"});});

  if(!filtered.length){
    var em=document.createElement("div");em.className="empty-state";
    em.innerHTML="<div>&#128101;</div><div class='es-title'>"+(q?"No results found":"No clients yet")+"</div><div class='es-sub'>"+(q?"Try a different search term":"Add your first client to get started")+"</div>";
    cv.appendChild(em);
  } else {
    var byStatus={};
    filtered.forEach(function(c){var s=c.status||"Other";if(!byStatus[s])byStatus[s]=[];byStatus[s].push(c);});
    var order=["Active","Prospect","On Hold","Lost"];
    var keys=Object.keys(byStatus).sort(function(a,b){var ia=order.indexOf(a),ib=order.indexOf(b);return(ia<0?99:ia)-(ib<0?99:ib);});
    keys.forEach(function(st){
      var section=document.createElement("div");section.style.marginBottom="20px";
      var mhdr=document.createElement("div");mhdr.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:10px;padding-bottom:5px;border-bottom:2px solid var(--red3);display:flex;align-items:center;gap:7px";
      var dot=document.createElement("span");dot.style.cssText="width:7px;height:7px;border-radius:50%;background:var(--navy);display:inline-block";
      var mn=document.createElement("span");mn.textContent=st;
      var cnt=document.createElement("span");cnt.style.cssText="margin-left:auto;background:var(--alt);border:1px solid var(--border);border-radius:20px;padding:1px 7px;font-size:9px";cnt.textContent=byStatus[st].length+" client"+(byStatus[st].length>1?"s":"");
      mhdr.appendChild(dot);mhdr.appendChild(mn);mhdr.appendChild(cnt);section.appendChild(mhdr);
      var grid=document.createElement("div");grid.style.cssText="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px";
      byStatus[st].forEach(function(c){
        var d=du(c.followup);var dl=d<0?"Overdue":d===0?"Today":d<=3?d+"d":fd(c.followup)||"";var dc=d<0?"fdue":d<=3?"famb":"fok";
        var card=document.createElement("div");card.className="rep-card";card.style.cursor="pointer";
        card.addEventListener("click",(function(cid){return function(){openC(cid);};})(c.id));
        var top=document.createElement("div");top.className="rep-card-top";
        var av=document.createElement("div");av.className="rep-av";av.textContent=ini(c.name);
        var info=document.createElement("div");
        var nm=document.createElement("div");nm.className="rep-name";nm.textContent=c.name;
        var co=document.createElement("div");co.className="rep-co";co.textContent=c.binder+(c.contact?" \u00b7 "+c.contact:"");
        info.appendChild(nm);info.appendChild(co);top.appendChild(av);top.appendChild(info);card.appendChild(top);
        var body=document.createElement("div");body.className="rep-card-body";
        var meta=document.createElement("div");meta.style.cssText="display:flex;align-items:center;gap:6px;margin-bottom:6px";
        var pill=document.createElement("span");pill.className="pl "+scls(c.status);pill.textContent=c.status;meta.appendChild(pill);
        if(c.priority){var st2=document.createElement("span");st2.className="stars";st2.textContent=c.priority;meta.appendChild(st2);}
        if(dl){var ft=document.createElement("span");ft.className="ftag "+dc;ft.textContent=dl;meta.appendChild(ft);}
        body.appendChild(meta);
        if(c.mobile){var tr=document.createElement("div");tr.style.cssText="font-size:11px;margin-bottom:4px";tr.innerHTML='<span style="color:var(--muted);font-size:9px;font-weight:700;text-transform:uppercase;margin-right:5px">Mobile</span>'+c.mobile;body.appendChild(tr);}
        card.appendChild(body);grid.appendChild(card);
      });
      section.appendChild(grid);cv.appendChild(section);
    });
  }
}

function renderDet(){
  var c=null;for(var i=0;i<clients.length;i++){if(clients[i].id===activeId){c=clients[i];break;}}
  if(!c)return;
  var d=du(c.followup);
  var dv=document.getElementById("detView");dv.innerHTML="";
  var hdr=document.createElement("div");hdr.className="det-hdr";
  var dtop=document.createElement("div");dtop.className="det-top";
  var dav=document.createElement("div");dav.className="det-av";dav.textContent=ini(c.name);
  var dinfo=document.createElement("div");
  var dname=document.createElement("div");dname.className="det-name";dname.textContent=c.name;
  var dsub=document.createElement("div");dsub.className="det-sub";dsub.textContent=c.binder+" \u00b7 "+(c.contact||"\u2014")+" \u00b7 "+(c.address||"\u2014");
  dinfo.appendChild(dname);dinfo.appendChild(dsub);dtop.appendChild(dav);dtop.appendChild(dinfo);
  var dbtns=document.createElement("div");dbtns.className="det-btns";
  var eb=document.createElement("button");eb.className="dbtn";eb.textContent="\u270E Edit";eb.addEventListener("click",function(){showForm(c.id);});
  var archB2=document.createElement("button");archB2.className="dbtn";archB2.style.cssText+="background:rgba(155,89,182,.15);border-color:#9b59b6;color:#9b59b6";archB2.textContent="\uD83D\uDDC4\uFE0F Archive";archB2.addEventListener("click",function(){
    try {
      archivedClients.push(c);
      var archId=c.id;
      clients=clients.filter(function(x){return x.id!==archId;});
      saveArchive();
      saveC();
      sbDelete("clients",archId);
      activeId=null;
      renderList();
      updateStats();
      showDash();
      toast(c.name+" archived \u2713");
    } catch(err) {
      toast("Error: "+err.message);
      console.error("Archive error:", err);
    }
  });
  var db2=document.createElement("button");db2.className="dbtn danger";db2.textContent="\uD83D\uDDD1 Delete";db2.addEventListener("click",function(){askDel(c.id,c.name);});
  var printB2=document.createElement("button");printB2.className="dbtn no-print";printB2.textContent="\uD83D\uDDA8\uFE0F Print";printB2.addEventListener("click",function(){window.print();});
  var printOvB=document.createElement("button");printOvB.className="dbtn no-print";printOvB.textContent="\uD83D\uDDA8\uFE0F Print overview";printOvB.addEventListener("click",function(){printClientOverview();});
  dbtns.appendChild(printOvB);dbtns.appendChild(printB2);dbtns.appendChild(eb);dbtns.appendChild(archB2);dbtns.appendChild(db2);hdr.appendChild(dtop);hdr.appendChild(dbtns);dv.appendChild(hdr);
  var grid=document.createElement("div");grid.className="sec-grid";
  function addSec(extra,tagCls,tagTxt,fields,compact){
    var sec=document.createElement("div");sec.className="sec"+(extra?" "+extra:"");
    var tag=document.createElement("span");tag.className="stag "+tagCls;tag.textContent=tagTxt;sec.appendChild(tag);
    var fg=document.createElement("div");fg.className=compact?"fg fg-compact":"fg";
    fields.forEach(function(f){if(!f)return;var fi=document.createElement("div");fi.className="fi"+(f.wide?" s2":"");var lbl=document.createElement("label");lbl.textContent=f.label;if(f.labelColor)lbl.style.color=f.labelColor;var val=document.createElement("div");val.className="fv";if(f.html){val.innerHTML=f.html;}else{var rawVal=f.val||"\u2014";if(!f.wide&&rawVal.length>40){val.className="fv fv-trunc";val.textContent=rawVal.slice(0,40)+"\u2026";val.title=rawVal;}else{val.textContent=rawVal;}}fi.appendChild(lbl);fi.appendChild(val);fg.appendChild(fi);});
    sec.appendChild(fg);return sec;
  }
    var sourceColors = {"Existing Customer":"background:#e8edf6;color:#2348b0","Existing Customer (Dormant 12m+)":"background:#f0e6f6;color:#6b2d8b","New - Sinbad's Old Customer":"background:var(--gbg);color:var(--gtxt)","New - Walk In":"background:#e8f5e0;color:#2d6a0f","New - Referral":"background:#fff3e0;color:#854f0b","Fitter":"background:var(--lbg);color:var(--ltxt)"};
  var sourceHtml = c.source ? "<span style=\'font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;"+(sourceColors[c.source]||"background:var(--alt);color:var(--muted)")+"\'>"+c.source+"</span>" : "&mdash;";
  grid.appendChild(addSec("","t-id","Identity",[{label:"Binder ref",labelColor:"#2348b0",val:c.binder},{label:"Manager",labelColor:"#9b59b6",val:c.manager},{label:"Account name",labelColor:"#16324D",val:c.name,wide:true},{label:"Primary contact name",labelColor:"#2d6a0f",val:c.contact},{label:"Primary contact number",labelColor:"#0f7d5c",val:c.mobile},{label:"Secondary contact name",labelColor:"#2d6a0f",val:c.contact2},{label:"Secondary contact number",labelColor:"#0f7d5c",val:c.mobile2},{label:"Customer source",labelColor:"#c77800",html:sourceHtml},{label:"Area",labelColor:"#b8860b",val:c.address}],true));
  grid.appendChild(addSec("","t-in","Intelligence",[{label:"Product interest",labelColor:"#2348b0",val:c.product,wide:true},{label:"Est. annual spend",labelColor:"#2d6a0f",html:(function(){var auto=calcAnnualSpend(c);if(auto>0){return "<span style='color:var(--gtxt);font-weight:700'>\u00a3"+auto.toLocaleString("en-GB")+"</span> <span style='font-size:9px;color:var(--muted)'>(paid orders, last 12mo)</span>";}return c.spend?("\u00a3"+c.spend+" <span style='font-size:9px;color:var(--muted)'>(manual estimate)</span>"):"\u2014";})()},{label:"Priority",labelColor:"#e8a020",html:"<span style='color:#e8a020;font-size:13px'>"+(c.priority||"\u2014")+"</span>"},{label:"Avg order value",labelColor:"#16324D",html:(function(){var t=0,n=0;(c.log||[]).forEach(function(l){if(l.quote&&l.quote.status==="Collected"){t+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);n++;}});return n>0?"<span style='color:var(--gtxt);font-weight:700'>\u00a3"+(Math.round(t/n)).toLocaleString("en-GB")+"</span> <span style='font-size:9px;color:var(--muted)'>("+n+" sales)</span>":"\u2014";})()},{label:"Total paid sales",labelColor:"#0f7d5c",html:(function(){var t=0;(c.log||[]).forEach(function(l){if(l.quote&&l.quote.status==="Collected")t+=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);});return t>0?"<span style='color:var(--navy);font-weight:700'>\u00a3"+t.toLocaleString("en-GB")+"</span>":"\u2014";})()},{label:"Wont buy",labelColor:"#b23a2e",val:c.wontBuy,wide:true},{label:"Who else they buy from",labelColor:"#9b59b6",val:c.competitorNotes,wide:true}],true));
  var trackingSec=addSec("full","t-tr","Tracking",[{label:"Status",labelColor:"#2348b0",html:"<span class='pl "+scls(c.status)+"'>"+c.status+"</span>"},{label:"Interaction type",labelColor:"#9b59b6",val:c.interactionType},{label:"Last contacted",labelColor:"#2d6a0f",val:c.lastContact},{label:"Follow-up date",labelColor:"#c77800",html:"<span class='ftag "+(d<=0?"fdue":d<=3?"famb":"fok")+"'>"+(c.followup||"Not set")+"</span>"},{label:"Account opened",labelColor:"#16324D",val:c.dateOpened||"—"},{label:"Key dates",labelColor:"#b23a2e",val:c.keyDates,wide:true}],true);
  trackingSec.className+=" not-in-overview"; grid.appendChild(trackingSec);
  var notesSec=document.createElement("div");notesSec.className="sec full not-in-overview";
  var nt=document.createElement("span");nt.className="stag t-tr";nt.textContent="Last interaction notes";notesSec.appendChild(nt);
  var nb=document.createElement("div");nb.className="nbox";nb.textContent=c.notes||"No notes yet.";notesSec.appendChild(nb);
  grid.appendChild(notesSec);
  var logSec=document.createElement("div");logSec.className="sec full not-in-overview";
  var lt=document.createElement("span");lt.className="stag t-lg";lt.textContent="Interaction log";logSec.appendChild(lt);

  var quoteCount=(c.log||[]).filter(function(l){return !!l.quote;}).length;
  var interactionCount=(c.log||[]).filter(function(l){return !l.quote;}).length;
  var tabRow=document.createElement("div");tabRow.className="no-print";tabRow.style.cssText="display:flex;gap:6px;margin:10px 0 4px";
  [["Interactions",interactionCount],["Quotes",quoteCount]].forEach(function(pair){
    var tabName=pair[0],tabCount=pair[1];
    var tb=document.createElement("button");
    tb.textContent=tabName+" ("+tabCount+")";
    tb.style.cssText="padding:6px 14px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid "+(detLogTab===tabName?"var(--navy)":"var(--border)")+";background:"+(detLogTab===tabName?"var(--navy)":"var(--surface)")+";color:"+(detLogTab===tabName?"#fff":"var(--muted)");
    tb.addEventListener("click",function(){detLogTab=tabName;renderDet();});
    tabRow.appendChild(tb);
  });
  logSec.appendChild(tabRow);
  var srcCount=(sourcing||[]).filter(function(s){return s.clientId===c.id;}).length;
  var srcBtn=document.createElement("button");srcBtn.className="no-print";srcBtn.style.cssText="margin:8px 0 4px;padding:6px 14px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid #e67e22;"+(srcCount?"background:#fff4e8;color:#a5590f":"background:#e67e22;color:#fff");
  srcBtn.textContent=srcCount?("\uD83C\uDFED Special order enquiries ("+srcCount+")"):"\uD83C\uDFED + New special order enquiry";
  srcBtn.addEventListener("click",function(){srcCount?showSourcing(c.id):showSourcingForm(null,c.id);});
  logSec.appendChild(srcBtn);

  if(showLF){logSec.appendChild(buildLogForm(c.id));}
  else{
    var btnRow=document.createElement("div");btnRow.style.cssText="display:flex;gap:7px;margin-top:6px";
    var alb=document.createElement("button");alb.className="log-trigger";alb.style.flex="1";
    alb.textContent="+ Log an interaction";alb.addEventListener("click",function(){showLF=true;renderDet();});
    var slb=document.createElement("button");slb.className="log-trigger";slb.style.cssText="flex:1;border-color:var(--gtxt);color:var(--gtxt)";
    slb.textContent="\u00a3 Log a sale";slb.addEventListener("click",function(){showSaleForm(c.id,c.name);});
    btnRow.appendChild(alb);btnRow.appendChild(slb);logSec.appendChild(btnRow);
  }
  (c.log||[]).forEach(function(l,idx){
    var isQuoteEntry = !!l.quote;
    var hideForTab = (detLogTab==="Interactions" && isQuoteEntry) || (detLogTab==="Quotes" && !isQuoteEntry);
    var entry=document.createElement("div");entry.className="log-entry"+(hideForTab?" tab-hidden":"");
    if(hideForTab) entry.style.display="none";
    var meta=document.createElement("div");meta.className="log-meta";
    var ltype=document.createElement("span");ltype.className="ltype";ltype.textContent=l.type;
    var ldate=document.createElement("span");ldate.className="ldate";ldate.textContent=l.date;
    var delB=document.createElement("button");delB.className="log-del";delB.textContent="\u00d7";
    delB.addEventListener("click",(function(i){return function(){delLog(c.id,i);};})(idx));
    meta.appendChild(ltype);meta.appendChild(ldate);
    if(l.quote){var qp=document.createElement("span");qp.className="qpill q-"+(l.quote.status||"quote").toLowerCase().replace(" ","-");qp.textContent=l.quote.status;meta.appendChild(qp);}
    meta.appendChild(delB);
    var note=document.createElement("div");note.className="lnote";note.textContent=l.note;
    entry.appendChild(meta);entry.appendChild(note);
    if(l.quote){
      var qbox=document.createElement("div");qbox.className="qbox";
      var qhdr=document.createElement("div");qhdr.style.cssText="display:flex;align-items:center;justify-content:space-between;margin-bottom:9px";
      var qttl=document.createElement("div");qttl.style.cssText="font-size:11px;font-weight:700;color:var(--navy);display:flex;align-items:center;gap:7px";qttl.textContent="Quote details";
      if((l.quote.ref||"").indexOf("SALE-")===0){
        var saleTag2=document.createElement("span");saleTag2.style.cssText="font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:2px 7px;border-radius:20px;background:#1a5c1a;color:#fff";saleTag2.textContent="\uD83D\uDED2 Counter Sale";
        qttl.appendChild(saleTag2);
      }
      var qhdrRight=document.createElement("div");qhdrRight.style.cssText="display:flex;align-items:center;gap:8px";
      var qvb=document.createElement("div");qvb.style.cssText="font-size:17px;font-weight:700;color:var(--gtxt)";qvb.textContent=money(l.quote.value);
      var qEditBtn=document.createElement("button");qEditBtn.style.cssText="padding:3px 9px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:10px;font-weight:700;cursor:pointer";qEditBtn.textContent="\u270E Edit";
      qEditBtn.addEventListener("click",(function(cid,i){return function(){showQuoteEditForm(cid,i);};})(c.id,idx));
      qhdrRight.appendChild(qvb);qhdrRight.appendChild(qEditBtn);
      qhdr.appendChild(qttl);qhdr.appendChild(qhdrRight);qbox.appendChild(qhdr);
      var qg=document.createElement("div");qg.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:9px";
      function qf2(lbl2,val2,wide2){var f=document.createElement("div");if(wide2)f.style.gridColumn="1/-1";var fl=document.createElement("div");fl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px";fl.textContent=lbl2;var fv=document.createElement("div");fv.style.cssText="font-size:11px;color:var(--text)"+(wide2?";font-weight:700":"");fv.textContent=val2||"\u2014";f.appendChild(fl);f.appendChild(fv);return f;}
      qg.appendChild(qf2("Ref",l.quote.ref));qg.appendChild(qf2("Value",money(l.quote.value)));qg.appendChild(qf2("Product",l.quote.products,true));qbox.appendChild(qg);
      if(l.quote.lostReason){var lrDiv=document.createElement("div");lrDiv.style.cssText="font-size:11px;color:var(--rtxt);background:var(--rbg);border-radius:var(--rs);padding:6px 9px;margin-top:7px";lrDiv.innerHTML="<strong>Lost reason:</strong> "+l.quote.lostReason;qbox.appendChild(lrDiv);}
      if(l.quote.paidDate){var pdDiv=document.createElement("div");pdDiv.style.cssText="font-size:11px;color:#1a5c1a;background:#d0f0d0;border-radius:var(--rs);padding:6px 9px;margin-top:7px";pdDiv.innerHTML="<strong>Paid:</strong> "+l.quote.paidDate;qbox.appendChild(pdDiv);}
      if(l.quote.collectedDate){var cdDiv=document.createElement("div");cdDiv.style.cssText="font-size:11px;color:#0a4a7a;background:#d0e8f5;border-radius:var(--rs);padding:6px 9px;margin-top:7px";cdDiv.innerHTML="<strong>Collected:</strong> "+l.quote.collectedDate;qbox.appendChild(cdDiv);}
      if(l.quote.expiry){
        var expDateObj=new Date(l.quote.expiry);
        var isExpired=!isNaN(expDateObj.getTime())&&new Date()>expDateObj;
        var expDisplay=!isNaN(expDateObj.getTime())?String(expDateObj.getDate()).padStart(2,"0")+"/"+String(expDateObj.getMonth()+1).padStart(2,"0")+"/"+expDateObj.getFullYear():l.quote.expiry;
        var exDiv=document.createElement("div");
        exDiv.style.cssText="font-size:11px;border-radius:var(--rs);padding:6px 9px;margin-top:7px;"+(isExpired?"color:var(--rtxt);background:var(--rbg)":"color:#8a5a00;background:#fff4e0");
        exDiv.innerHTML="<strong>Expires:</strong> "+expDisplay+(isExpired?" \u26A0 EXPIRED":"");
        qbox.appendChild(exDiv);
      }
      var qsr=document.createElement("div");qsr.style.cssText="display:flex;align-items:center;gap:8px;padding-top:7px;border-top:1px solid #b8caf5";
      var qsl=document.createElement("div");qsl.style.cssText="font-size:9px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px";qsl.textContent="Update status:";
      var qsel=document.createElement("select");qsel.style.cssText="padding:4px 9px;border:2px solid var(--border);border-radius:20px;font-size:10px;font-weight:700;background:#fff;cursor:pointer;outline:none;flex:1";
      ["Quote","Confirmed","Invoiced","Paid","Collected","Lost","Expired"].forEach(function(s2){var opt=document.createElement("option");opt.value=s2;opt.textContent=s2;if(l.quote.status===s2)opt.selected=true;qsel.appendChild(opt);});
      qsel.addEventListener("change",(function(i){return function(e){updateQStatus(c.id,i,e.target.value);};})(idx));
      qsr.appendChild(qsl);qsr.appendChild(qsel);qbox.appendChild(qsr);entry.appendChild(qbox);
    }
    logSec.appendChild(entry);
  });
  var visibleLogCount=(c.log||[]).filter(function(l){return detLogTab==="Quotes" ? !!l.quote : !l.quote;}).length;
  if(!visibleLogCount){var nl=document.createElement("p");nl.style.cssText="font-size:11px;color:var(--muted);margin-bottom:7px";nl.textContent=detLogTab==="Quotes"?"No quotes logged yet.":"No interactions logged yet.";logSec.appendChild(nl);}grid.appendChild(logSec);
  var prodMap={},qtrMap={Q1:0,Q2:0,Q3:0,Q4:0};
  (c.log||[]).forEach(function(l){if(l.quote&&l.quote.status==="Collected"){var v=(parseFloat(String(l.quote.value||"0").replace(/[^0-9.]/g,""))||0);var prod=l.quote.category||l.quote.products||"Other";prodMap[prod]=(prodMap[prod]||0)+v;var useDate=l.quote.collectedDate||l.date;if(useDate){var dp=useDate.split("/");if(dp.length===3){var m=parseInt(dp[1]);var q=m<=3?"Q1":m<=6?"Q2":m<=9?"Q3":"Q4";qtrMap[q]=(qtrMap[q]||0)+v;}}}}); 
  var hasProd=Object.keys(prodMap).length>0,hasQtr=Object.values(qtrMap).some(function(v){return v>0;});
  if(hasProd||hasQtr){
    var cs=document.createElement("div");cs.className="sec full";var ct=document.createElement("span");ct.className="stag t-ch";ct.textContent="Sales intelligence";cs.appendChild(ct);
    var cg=document.createElement("div");cg.style.cssText="display:grid;grid-template-columns:1fr 1fr;gap:14px";
    if(hasProd){var pd=document.createElement("div");var pl=document.createElement("div");pl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);margin-bottom:7px";pl.textContent="Product mix";var pw=document.createElement("div");pw.className="chart-wrap";var pc=document.createElement("canvas");pc.id="pieCh";pw.appendChild(pc);pd.appendChild(pl);pd.appendChild(pw);cg.appendChild(pd);}
    if(hasQtr){var bd=document.createElement("div");var bl=document.createElement("div");bl.style.cssText="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);margin-bottom:7px";bl.textContent="Quarterly spend";var bw=document.createElement("div");bw.className="chart-wrap";var bc=document.createElement("canvas");bc.id="barCh";bw.appendChild(bc);bd.appendChild(bl);bd.appendChild(bw);cg.appendChild(bd);}
    cs.appendChild(cg);grid.appendChild(cs);
  }
  dv.appendChild(grid);
  // Birthday on client record
  var clientBday = birthdays.find(function(b){ return b.linkedType==="client" && b.name===c.name; });
  if (clientBday) {
    var bdSec = document.createElement("div"); bdSec.className = "sec full not-in-overview";
    var bdTag = document.createElement("span"); bdTag.className = "stag"; bdTag.style.cssText = "display:inline-block;font-size:9px;font-weight:700;padding:2px 9px;border-radius:20px;margin-bottom:11px;letter-spacing:.5px;text-transform:uppercase;background:#fff3e0;color:#854f0b"; bdTag.textContent = "Birthday";
    bdSec.appendChild(bdTag);
    var bdRow = document.createElement("div"); bdRow.style.cssText = "display:flex;align-items:center;gap:12px;padding:9px 12px;background:#fff8f0;border:2px solid #ffd699;border-radius:var(--rs)";
    var bdAv = document.createElement("div"); bdAv.style.cssText = "font-size:22px"; bdAv.textContent = "\uD83C\uDF82";
    var bdInfo = document.createElement("div"); bdInfo.style.flex = "1";
    var bdNm = document.createElement("div"); bdNm.style.cssText = "font-weight:700;font-size:13px"; bdNm.textContent = fmtBday(clientBday.date);
    var bdDays = daysUntilBday(clientBday.date);
    var bdSub = document.createElement("div"); bdSub.style.cssText = "font-size:11px;color:var(--muted);margin-top:2px"; bdSub.textContent = bdDays===0?"TODAY! \uD83C\uDF82":bdDays===1?"Tomorrow":bdDays+"d away";
    bdInfo.appendChild(bdNm); bdInfo.appendChild(bdSub);
    bdRow.appendChild(bdAv); bdRow.appendChild(bdInfo);
    bdSec.appendChild(bdRow);
    grid.appendChild(bdSec);
  }

  // Samples given to this client
  var clientSamples = samples.filter(function(s){ return s.clientName === c.name; });
  if (clientSamples.length) {
    var sSec = document.createElement("div"); sSec.className = "sec full not-in-overview";
    var sTag = document.createElement("span"); sTag.className = "stag t-lg"; sTag.textContent = "Samples ("+ clientSamples.length +")";
    sSec.appendChild(sTag);
    var sTbl = document.createElement("div"); sTbl.style.cssText = "display:flex;flex-direction:column;gap:6px";
    var statusCols2 = {
      "Sent - Awaiting Return":"background:var(--abg);color:var(--atxt)",
      "Sent - No Response":"background:var(--rbg);color:var(--rtxt)",
      "Returned":"background:var(--gbg);color:var(--gtxt)",
      "Order Placed":"background:#d0f0d0;color:#1a5c1a",
      "Not Interested":"background:var(--grbg);color:var(--grtxt)",
      "Left with client":"background:var(--lbg);color:var(--ltxt)"
    };
    clientSamples.slice().sort(function(a,b){
      // Leave behinds first, then by date newest first
      var aLB = a.sampleType==="Leave Behind"?0:1;
      var bLB = b.sampleType==="Leave Behind"?0:1;
      return aLB-bLB;
    }).forEach(function(s){
      var row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:10px;padding:7px 10px;background:var(--alt);border-radius:var(--rs);flex-wrap:wrap";
      var icon = document.createElement("span"); icon.style.cssText = "font-size:16px;flex-shrink:0";
      icon.textContent = s.sampleType==="Leave Behind" ? "\uD83D\uDCE6" : "\uD83D\uDD04";
      var info = document.createElement("div"); info.style.flex = "1";
      var pnm = document.createElement("div"); pnm.style.cssText = "font-weight:700;font-size:11px"; pnm.textContent = (s.product||"")+(s.detail?" — "+s.detail:"");
      var meta2 = document.createElement("div"); meta2.style.cssText = "font-size:10px;color:var(--muted)";
      meta2.textContent = (s.sampleType||"Loan")+" · "+s.dateSent+(s.repName?" · from "+s.repName:"");
      info.appendChild(pnm); info.appendChild(meta2);
      var pill2 = document.createElement("span");
      pill2.style.cssText = "font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;flex-shrink:0;"+(statusCols2[s.status]||"background:var(--lbg);color:var(--ltxt)");
      pill2.textContent = s.status;
      row.appendChild(icon); row.appendChild(info); row.appendChild(pill2);
      sTbl.appendChild(row);
    });
    sSec.appendChild(sTbl);
    grid.appendChild(sSec);
  }

  // Diary events for this client
  var cDE=diaryEvents.filter(function(e){return !e.completed&&e.withType==="client"&&e.withName===c.name;}).sort(function(a,b){return new Date(a.year,a.month,a.day)-new Date(b.year,b.month,b.day);});
  var cDEpast=diaryEvents.filter(function(e){return e.completed&&e.withType==="client"&&e.withName===c.name;}).slice(0,3);
  if(cDE.length||cDEpast.length){
    var dSec=document.createElement("div");dSec.className="sec full not-in-overview";
    var dTag=document.createElement("span");dTag.className="stag";dTag.style.cssText="display:inline-block;font-size:9px;font-weight:700;padding:2px 9px;border-radius:20px;margin-bottom:11px;letter-spacing:.5px;text-transform:uppercase;background:#fff3e0;color:#854f0b";dTag.textContent="Diary events";dSec.appendChild(dTag);
    var tC3={"Meeting":"#305CDE","Site Visit":"#2ecc71","Call":"#f39c12","Rep Visit":"#9b59b6","Delivery":"#e67e22","Family Event":"#e91e8c","Birthday":"#e8a020","Anniversary":"#c0392b","Holiday":"#16a085","Other":"#7f8c8d"};
    cDE.forEach(function(e){
      var er=document.createElement("div");er.style.cssText="display:flex;align-items:center;gap:8px;padding:7px 10px;background:#fff8f0;border:2px solid #ffd699;border-radius:var(--rs);margin-bottom:6px;cursor:pointer";
      er.addEventListener("click",function(){showDiary();});
      var dot4=document.createElement("div");dot4.style.cssText="width:8px;height:8px;border-radius:50%;background:"+(tC3[e.type]||"#305CDE")+";flex-shrink:0";
      var inf3=document.createElement("div");inf3.style.flex="1";
      var t3=document.createElement("div");t3.style.cssText="font-size:12px;font-weight:700";t3.textContent=(e.allDay?"All day":String(e.hour).padStart(2,"0")+":"+String(e.minute).padStart(2,"0"))+" "+e.title;
      var m3=document.createElement("div");m3.style.cssText="font-size:10px;color:var(--muted)";m3.textContent=e.type+" · "+["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][e.month]+" "+e.day+", "+e.year;
      inf3.appendChild(t3);inf3.appendChild(m3);
      var evD3=new Date(e.year,e.month,e.day);var tn=new Date();tn.setHours(0,0,0,0);
      var df3=Math.ceil((evD3-tn)/86400000);
      var b3=document.createElement("span");b3.style.cssText="font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;flex-shrink:0;"+(df3<0?"background:var(--rbg);color:var(--rtxt)":df3===0?"background:var(--abg);color:var(--atxt)":"background:var(--lbg);color:var(--ltxt)");b3.textContent=df3<0?df3+"d":df3===0?"Today":"+"+df3+"d";
      var dB3=document.createElement("button");dB3.style.cssText="padding:3px 8px;background:var(--gbg);border:1px solid var(--gtxt);border-radius:20px;font-size:10px;color:var(--gtxt);cursor:pointer;font-weight:700;flex-shrink:0";dB3.textContent="✓ Done";
      dB3.addEventListener("click",(function(eid){return function(ev2){ev2.stopPropagation();markDiaryDone(eid);renderDet();};})(e.id));
      var eB3=document.createElement("button");eB3.style.cssText="padding:3px 8px;background:none;border:2px solid var(--border);border-radius:20px;font-size:10px;color:var(--muted);cursor:pointer;flex-shrink:0";eB3.textContent="✎";
      eB3.addEventListener("click",(function(eid){return function(ev2){ev2.stopPropagation();editDiaryEvent(eid);};})(e.id));
      er.appendChild(dot4);er.appendChild(inf3);er.appendChild(b3);er.appendChild(eB3);er.appendChild(dB3);dSec.appendChild(er);
    });
    if(cDEpast.length){
      var pL=document.createElement("div");pL.style.cssText="font-size:10px;color:var(--muted);margin-top:6px;margin-bottom:4px";pL.textContent="Recently completed:";dSec.appendChild(pL);
      cDEpast.forEach(function(e){var pr=document.createElement("div");pr.style.cssText="font-size:11px;color:var(--muted);padding:4px 0;border-bottom:1px solid var(--border)";pr.textContent="✓ "+e.type+" — "+e.title+" ("+["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][e.month]+" "+e.day+")";dSec.appendChild(pr);});
    }
    var oDBtn=document.createElement("button");oDBtn.style.cssText="font-size:11px;color:var(--navy);cursor:pointer;background:none;border:none;padding:6px 0;text-decoration:underline";oDBtn.textContent="Open diary →";oDBtn.addEventListener("click",showDiary);dSec.appendChild(oDBtn);
    grid.appendChild(dSec);
  }
  dv.appendChild(grid);
  
  var bk=document.createElement("button");bk.className="bkl no-print";bk.textContent="\u2190 Back to dashboard";bk.addEventListener("click",showDash);dv.appendChild(bk);
  if(hasProd){setTimeout(function(){mkPieChart("pieCh",Object.keys(prodMap),Object.values(prodMap));},100);}
  if(hasQtr){setTimeout(function(){mkBarChart("barCh",[qtrMap.Q1,qtrMap.Q2,qtrMap.Q3,qtrMap.Q4]);},100);}
}

function buildLogForm(cid){
  var today=new Date().toISOString().split("T")[0];
  var form=document.createElement("div");form.className="lf";
  var h5=document.createElement("h5");h5.textContent="Log interaction";form.appendChild(h5);
  var row1=document.createElement("div");row1.className="lf-row";
  var typesel=document.createElement("select");typesel.id="ltyp";
  ["","Phone","Text","Email","Store Visit"].forEach(function(s){var opt=document.createElement("option");opt.value=s;opt.textContent=s||"Type...";typesel.appendChild(opt);});
  var datein=document.createElement("input");datein.type="date";datein.id="ldat";datein.value=today;
  row1.appendChild(typesel);row1.appendChild(datein);form.appendChild(row1);
  var ta=document.createElement("textarea");ta.className="lf-ta";ta.id="lnot";ta.placeholder="What was discussed, what they need, job details...";form.appendChild(ta);
  var fuRow=document.createElement("div");fuRow.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap";
  var fuChk=document.createElement("input");fuChk.type="checkbox";fuChk.id="setFU";
  var fuLbl=document.createElement("label");fuLbl.setAttribute("for","setFU");fuLbl.style.fontSize="11px";fuLbl.textContent="Set follow-up date:";
  var fuDate=document.createElement("input");fuDate.type="date";fuDate.id="fuDate";fuDate.style.cssText="display:none;padding:5px 7px;border:2px solid #f0c060;border-radius:var(--rs);font-size:11px;background:#fff;font-family:inherit";
  fuChk.addEventListener("change",function(){fuDate.style.display=this.checked?"inline-block":"none";});
  fuRow.appendChild(fuChk);fuRow.appendChild(fuLbl);fuRow.appendChild(fuDate);form.appendChild(fuRow);
  var chkWrap=document.createElement("div");chkWrap.className="lf-check";
  var chk=document.createElement("input");chk.type="checkbox";chk.id="hasQ";
  var chkLbl=document.createElement("label");chkLbl.setAttribute("for","hasQ");chkLbl.textContent="Attach a quote to this interaction";
  chk.addEventListener("change",function(){document.getElementById("qfields").className="qfields"+(this.checked?" show":"");});
  chkWrap.appendChild(chk);chkWrap.appendChild(chkLbl);form.appendChild(chkWrap);
  var smpChkWrap=document.createElement("div");smpChkWrap.className="lf-check";
  var smpChk=document.createElement("input");smpChk.type="checkbox";smpChk.id="hasSmp";
  var smpChkLbl=document.createElement("label");smpChkLbl.setAttribute("for","hasSmp");smpChkLbl.textContent="Log a sample request";
  smpChk.addEventListener("change",function(){document.getElementById("smpfields").className="qfields"+(this.checked?" show":"");});
  smpChkWrap.appendChild(smpChk);smpChkWrap.appendChild(smpChkLbl);form.appendChild(smpChkWrap);
  var smpF=document.createElement("div");smpF.className="qfields";smpF.id="smpfields";
  var prodOpts2=PRODUCTS.map(function(p){return'<option value="'+p+'">'+p+'</option>';}).join("");
  smpF.innerHTML='<div class="qfgrid"><div class="qf"><label>Product / sample</label><select id="smpProd"><option value="">-- Select --</option>'+prodOpts2+'</select></div><div class="qf"><label>Sample type</label><select id="smpType"><option value="Loan">Loan (want it back)</option><option value="Leave Behind">Leave behind (keep)</option></select></div><div class="qf s2"><label>Detail (colour, range, size)</label><input id="smpDetail" placeholder="e.g. Karndean Korlok Grey Oak 1.5m x 1m"></div></div>';
  form.appendChild(smpF);
  var qf=document.createElement("div");qf.className="qfields";qf.id="qfields";
  var prodOpts=PRODUCTS.map(function(p){return'<option value="'+p+'">'+p+'</option>';}).join("");
  qf.innerHTML='<div class="qfgrid"><div class="qf"><label>Quote ref</label><input id="qref" placeholder="e.g. QT-001"></div><div class="qf"><label>Value (&#163;)</label><input id="qval" placeholder="e.g. 2500" type="number"></div><div class="qf s2"><label>Product category</label><select id="qprod"><option value="">-- Select product --</option>'+prodOpts+'</select></div><div class="qf"><label>Qty / detail</label><input id="qqty" placeholder="e.g. 50m&#178;"></div><div class="qf s2" id="qother_wrap" style="display:none"><label>Specify product</label><input id="qother" placeholder="e.g. Stair rods, Door bars..."></div><div class="qf s2" id="qsubcat_wrap" style="display:none"><label id="qsubcat_lbl">Sub-category</label><select id="qsubcat"></select></div><div class="qf s2" id="qrange_wrap" style="display:none"><label>Range</label><select id="qrange"></select></div><div class="qf"><label>Status</label><select id="qstat"><option>Quote</option><option>Confirmed</option><option>Invoiced</option><option>Paid</option><option>Lost</option><option>Expired</option></select></div><div class="qf"><label>Expires</label><div style="display:flex;gap:5px"><input id="qexpiry" type="date" style="flex:1"><button type="button" id="qexpiry4wk" style="padding:0 10px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap">+4wk</button></div></div></div>';
  form.appendChild(qf);
  setTimeout(function(){
    var qpEl2=document.getElementById('qprod');
    if(qpEl2){qpEl2.addEventListener('change',function(){
      var ow=document.getElementById('qother_wrap');if(ow)ow.style.display=this.value==='Other'?'':'none';
      var sw=document.getElementById('qsubcat_wrap');var sSel=document.getElementById('qsubcat');var sLbl=document.getElementById('qsubcat_lbl');
      var rw=document.getElementById('qrange_wrap');var rSel=document.getElementById('qrange');
      var list=PRODUCT_SUBCATS[this.value];
      if(list&&sw&&sSel){
        sSel.innerHTML='<option value="">-- Select '+this.value+' category --</option>';
        list.forEach(function(item){var o=document.createElement('option');o.value=item.name;o.textContent=item.note?(item.name+' ('+item.note+')'):item.name;sSel.appendChild(o);});
        if(sLbl)sLbl.textContent=this.value+' category *';
        sw.style.display='';
      } else if(sw){
        sw.style.display='none';
        if(sSel)sSel.innerHTML='';
      }
      if(rw){rw.style.display='none';if(rSel)rSel.innerHTML='';}
    });}
    var qsEl=document.getElementById('qsubcat');
    if(qsEl){qsEl.addEventListener('change',function(){
      var rw=document.getElementById('qrange_wrap');var rSel=document.getElementById('qrange');
      var prodVal=document.getElementById('qprod').value;
      var list=PRODUCT_SUBCATS[prodVal]||[];
      var chosen=list.filter(function(item){return item.name===qsEl.value;})[0];
      var ranges=(chosen&&chosen.ranges)?chosen.ranges:[];
      if(ranges.length&&rw&&rSel){
        rSel.innerHTML='<option value="">-- Select range --</option>';
        ranges.forEach(function(rg){var ro=document.createElement('option');ro.value=rg;ro.textContent=rg;rSel.appendChild(ro);});
        rw.style.display='';
      } else if(rw){
        rw.style.display='none';
        if(rSel)rSel.innerHTML='';
      }
    });}
    var qexp4wkBtn=document.getElementById('qexpiry4wk');
    if(qexp4wkBtn){qexp4wkBtn.addEventListener('click',function(){
      var d=new Date(); d.setDate(d.getDate()+28);
      var qexpEl=document.getElementById('qexpiry');
      if(qexpEl) qexpEl.value=d.toISOString().split("T")[0];
    });}
  },0);
  var btns=document.createElement("div");btns.className="lf-btns";btns.style.marginTop="8px";
  var saveB=document.createElement("button");saveB.className="lf-save";saveB.textContent="Save";saveB.addEventListener("click",function(){saveLog(cid);});
  var cancelB=document.createElement("button");cancelB.className="lf-cancel";cancelB.textContent="Cancel";cancelB.addEventListener("click",function(){showLF=false;renderDet();});
  btns.appendChild(saveB);btns.appendChild(cancelB);form.appendChild(btns);return form;
}

function showQuoteEditForm(clientId, logIdx) {
  var c = null; for (var i = 0; i < clients.length; i++) { if (clients[i].id === clientId) { c = clients[i]; break; } }
  if (!c || !c.log[logIdx] || !c.log[logIdx].quote) return;
  var q = c.log[logIdx].quote;

  // Split the stored "category (qty)" string back apart for editing
  var category = q.category || "";
  var qtyDetail = "";
  if (q.products && category) {
    var match = q.products.match(/^(.*?)\s*\(([^)]*)\)\s*$/);
    if (match) { qtyDetail = match[2]; }
  }
  var otherDetail = "";
  if (category && category.indexOf("Other") === 0) {
    var otherMatch = category.match(/^Other:\s*(.*)$/);
    if (otherMatch) { otherDetail = otherMatch[1]; category = "Other"; }
  }
  // Split sub-category strings like "Tools: Blades" back into product + sub-category
  var subDetail = "";
  var rangeDetail = "";
  Object.keys(PRODUCT_SUBCATS).forEach(function(prodName) {
    if (category.indexOf(prodName + ": ") === 0) {
      subDetail = category.substring((prodName + ": ").length);
      category = prodName;
    }
  });
  // Further split "Cloud 9 - Cumulus" into subDetail="Cloud 9", rangeDetail="Cumulus"
  if (subDetail.indexOf(" - ") > -1) {
    var rangeSplit = subDetail.split(" - ");
    rangeDetail = rangeSplit.pop();
    subDetail = rangeSplit.join(" - ");
  }

  var overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:200;display:flex;align-items:center;justify-content:center;padding:16px";
  var box = document.createElement("div");
  box.style.cssText = "background:var(--surface);border-radius:var(--r);width:100%;max-width:440px;max-height:90vh;overflow-y:auto";

  var bh = document.createElement("div"); bh.style.cssText = "background:var(--navy);padding:14px 18px;display:flex;align-items:center;justify-content:space-between";
  var bht = document.createElement("h2"); bht.style.cssText = "font-size:15px;font-weight:700;color:#fff"; bht.textContent = "\u270E Edit quote";
  var qeCx = document.createElement("button"); qeCx.style.cssText = "background:rgba(255,255,255,.1);border:none;border-radius:4px;width:26px;height:26px;color:#fff;font-size:17px;cursor:pointer;line-height:1"; qeCx.textContent = "\u00d7";
  qeCx.addEventListener("click", function(){ document.body.removeChild(overlay); });
  bh.appendChild(bht); bh.appendChild(qeCx); box.appendChild(bh);

  var bd = document.createElement("div"); bd.style.cssText = "padding:18px;display:flex;flex-direction:column;gap:12px";

  function mkFd(lbl, inp) { var w=document.createElement("div"); var l=document.createElement("label"); l.style.cssText="display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; l.textContent=lbl; w.appendChild(l); w.appendChild(inp); return w; }

  var refInp = document.createElement("input"); refInp.id="qe_ref"; refInp.value=q.ref||""; refInp.placeholder="e.g. QT-001"; refInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("Quote ref", refInp));

  var valInp = document.createElement("input"); valInp.id="qe_val"; valInp.type="number"; valInp.value=q.value||""; valInp.placeholder="e.g. 2500"; valInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("Value (\u00a3)", valInp));

  var prodSel = document.createElement("select"); prodSel.id="qe_prod"; prodSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  var blankOpt = document.createElement("option"); blankOpt.value=""; blankOpt.textContent="-- Select product --"; prodSel.appendChild(blankOpt);
  PRODUCTS.forEach(function(p){ var o=document.createElement("option"); o.value=p; o.textContent=p; if(p===category) o.selected=true; prodSel.appendChild(o); });
  bd.appendChild(mkFd("Product category", prodSel));

  var otherWrap = document.createElement("div"); otherWrap.style.display = category==="Other" ? "block" : "none";
  var otherInp = document.createElement("input"); otherInp.id="qe_other"; otherInp.value=otherDetail; otherInp.placeholder="e.g. Stair rods, Door bars..."; otherInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  otherWrap.appendChild(mkFd("Specify product", otherInp));
  bd.appendChild(otherWrap);

  var subcatWrap = document.createElement("div"); subcatWrap.style.display = PRODUCT_SUBCATS[category] ? "block" : "none";
  var subcatSel = document.createElement("select"); subcatSel.id="qe_subcat"; subcatSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  function populateSubcat(prodName, preselect) {
    subcatSel.innerHTML = "";
    var blankO = document.createElement("option"); blankO.value=""; blankO.textContent="-- Select "+prodName+" category --"; subcatSel.appendChild(blankO);
    var list = PRODUCT_SUBCATS[prodName] || [];
    list.forEach(function(item){ var o=document.createElement("option"); o.value=item.name; o.textContent=item.note?(item.name+" ("+item.note+")"):item.name; if(item.name===preselect)o.selected=true; subcatSel.appendChild(o); });
  }
  if (PRODUCT_SUBCATS[category]) populateSubcat(category, subDetail);
  var subcatLbl = mkFd("Sub-category *", subcatSel);
  subcatWrap.appendChild(subcatLbl);
  bd.appendChild(subcatWrap);

  var rangeWrap = document.createElement("div"); rangeWrap.style.display = "none";
  var rangeSel = document.createElement("select"); rangeSel.id="qe_range"; rangeSel.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  function populateRange(prodName, subName, preselect) {
    var list = PRODUCT_SUBCATS[prodName] || [];
    var item = list.filter(function(it){ return it.name === subName; })[0];
    var ranges = (item && item.ranges) ? item.ranges : [];
    if (!ranges.length) { rangeWrap.style.display = "none"; rangeSel.innerHTML = ""; return; }
    rangeSel.innerHTML = "";
    var rBlank = document.createElement("option"); rBlank.value=""; rBlank.textContent="-- Select range --"; rangeSel.appendChild(rBlank);
    ranges.forEach(function(rg){ var ro=document.createElement("option"); ro.value=rg; ro.textContent=rg; if(rg===preselect)ro.selected=true; rangeSel.appendChild(ro); });
    rangeWrap.style.display = "block";
  }
  if (PRODUCT_SUBCATS[category] && subDetail) populateRange(category, subDetail, rangeDetail);
  rangeWrap.appendChild(mkFd("Range *", rangeSel));
  bd.appendChild(rangeWrap);

  prodSel.addEventListener("change", function(){
    otherWrap.style.display = this.value==="Other" ? "block" : "none";
    if (PRODUCT_SUBCATS[this.value]) {
      populateSubcat(this.value, "");
      subcatWrap.style.display = "block";
    } else {
      subcatWrap.style.display = "none";
    }
    rangeWrap.style.display = "none"; rangeSel.innerHTML = "";
  });

  subcatSel.addEventListener("change", function(){
    populateRange(prodSel.value, subcatSel.value, "");
  });

  var qtyInp = document.createElement("input"); qtyInp.id="qe_qty"; qtyInp.value=qtyDetail; qtyInp.placeholder="e.g. 50m\u00b2"; qtyInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  bd.appendChild(mkFd("Qty / detail", qtyInp));

  var expInp2 = document.createElement("input"); expInp2.id="qe_expiry"; expInp2.type="date"; expInp2.value=q.expiry||""; expInp2.style.cssText="flex:1;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
  var exp4wkBtn = document.createElement("button"); exp4wkBtn.type="button"; exp4wkBtn.textContent="+4 weeks"; exp4wkBtn.style.cssText="padding:7px 12px;background:var(--surface);border:1px solid var(--navy);border-radius:var(--rs);color:var(--navy);font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap";
  exp4wkBtn.addEventListener("click", function(){
    var d = new Date();
    d.setDate(d.getDate() + 28);
    expInp2.value = d.toISOString().split("T")[0];
  });
  var expRow2 = document.createElement("div"); expRow2.style.cssText = "display:flex;gap:6px";
  expRow2.appendChild(expInp2); expRow2.appendChild(exp4wkBtn);
  bd.appendChild(mkFd("Expiry date", expRow2));

  if (q.status === "Lost") {
    var lostReasonInp = document.createElement("input"); lostReasonInp.id="qe_lostreason"; lostReasonInp.value=q.lostReason||""; lostReasonInp.placeholder="e.g. Price too high - went with competitor"; lostReasonInp.style.cssText="width:100%;padding:7px 9px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;font-family:inherit;outline:none";
    bd.appendChild(mkFd("Lost reason", lostReasonInp));
  }

  var relatedSourcing = q.ref ? (sourcing||[]).filter(function(s){ return s.clientId===c.id && s.quoteRef && s.quoteRef.trim().toLowerCase()===q.ref.trim().toLowerCase(); }) : [];
  if (relatedSourcing.length) {
    var srcDiv = document.createElement("div"); srcDiv.style.cssText = "background:#fff4e8;border:2px solid #e6a15c;border-radius:var(--rs);padding:10px 12px";
    var srcTitle = document.createElement("div"); srcTitle.style.cssText="font-size:10px;font-weight:700;text-transform:uppercase;color:#a5590f;letter-spacing:.4px;margin-bottom:6px"; srcTitle.textContent="\uD83C\uDFED Linked special order "+(relatedSourcing.length>1?"enquiries ("+relatedSourcing.length+")":"enquiry");
    srcDiv.appendChild(srcTitle);
    relatedSourcing.forEach(function(s){
      var line = document.createElement("div"); line.style.cssText="font-size:12px;color:var(--text);margin-bottom:6px";
      line.textContent = (s.company||"Supplier")+(s.asmRep?" \u2014 "+s.asmRep:"")+" \u00b7 "+(s.status||"Chasing Price");
      var viewBtn = document.createElement("button"); viewBtn.type="button"; viewBtn.style.cssText="padding:4px 10px;background:#e67e22;border:none;border-radius:var(--rs);color:#fff;font-size:10px;font-weight:700;cursor:pointer";
      viewBtn.textContent="View enquiry details";
      viewBtn.addEventListener("click",(function(sid){return function(){ document.body.removeChild(overlay); showSourcingForm(sid); };})(s.id));
      srcDiv.appendChild(line); srcDiv.appendChild(viewBtn);
    });
    bd.appendChild(srcDiv);
  }

  box.appendChild(bd);
  var foot = document.createElement("div"); foot.style.cssText = "padding:12px 18px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:7px";
  var cancelB = document.createElement("button"); cancelB.style.cssText = "padding:7px 12px;background:none;border:2px solid var(--border);border-radius:var(--rs);color:var(--muted);font-size:12px;cursor:pointer"; cancelB.textContent = "Cancel";
  cancelB.addEventListener("click", function(){ document.body.removeChild(overlay); });
  var saveB = document.createElement("button"); saveB.style.cssText = "padding:7px 16px;background:var(--navy);border:none;border-radius:var(--rs);color:#fff;font-size:12px;font-weight:700;cursor:pointer"; saveB.textContent = "Save changes";
  saveB.addEventListener("click", function(){
    var newVal = valInp.value.trim();
    if (!newVal) { toast("Please enter a value"); return; }
    var newCat = prodSel.value;
    var newOther = otherInp.value.trim();
    var finalCat = (newCat==="Other" && newOther) ? "Other: "+newOther : newCat;
    if (PRODUCT_SUBCATS[newCat]) {
      var newSub = subcatSel.value;
      if (!newSub) { toast("Please select a "+newCat+" category"); return; }
      var newSubItem = (PRODUCT_SUBCATS[newCat]||[]).filter(function(it){return it.name===newSub;})[0];
      if (newSubItem && newSubItem.ranges && newSubItem.ranges.length && rangeWrap.style.display !== "none") {
        var newRange = rangeSel.value;
        if (!newRange) { toast("Please select a range"); return; }
        finalCat = newCat + ": " + newSub + " - " + newRange;
      } else {
        finalCat = newCat + ": " + newSub;
      }
    }
    var newQty = qtyInp.value.trim();
    q.ref = refInp.value.trim();
    q.value = newVal;
    q.category = finalCat;
    q.products = finalCat + (newQty ? " ("+newQty+")" : "");
    q.expiry = expInp2.value;
    var lostReasonEl = document.getElementById("qe_lostreason");
    if (lostReasonEl) q.lostReason = lostReasonEl.value.trim();
    saveC();
    document.body.removeChild(overlay);
    renderDet();
    toast("Quote updated \u2713");
  });
  foot.appendChild(cancelB); foot.appendChild(saveB);
  box.appendChild(foot); overlay.appendChild(box); document.body.appendChild(overlay);
  setTimeout(function(){ refInp.focus(); }, 100);
}

function saveLog(id){
  var type=document.getElementById("ltyp").value;
  var note=document.getElementById("lnot").value.trim();
  var date=document.getElementById("ldat").value;
  if(!type||!note){toast("Please fill in type and notes");return;}
  var c=null;for(var i=0;i<clients.length;i++){if(clients[i].id===id){c=clients[i];break;}}
  if(!c)return;
  if(!c.log)c.log=[];
  var entry={date:fd(date),type:type,note:note};
  var hasQ=document.getElementById("hasQ").checked;
  if(hasQ){
    var qpv=document.getElementById("qprod").value;
    var qother=(document.getElementById("qother")||{}).value||"";
    if(qpv==="Other"&&qother)qpv="Other: "+qother;
    if(PRODUCT_SUBCATS[qpv]){
      var qSubVal=(document.getElementById("qsubcat")||{}).value||"";
      if(!qSubVal){toast("Please select a "+qpv+" category");return;}
      var qSubItem=PRODUCT_SUBCATS[qpv].filter(function(it){return it.name===qSubVal;})[0];
      var qRangeEl=document.getElementById("qrange_wrap");
      if(qSubItem&&qSubItem.ranges&&qSubItem.ranges.length&&qRangeEl&&qRangeEl.style.display!=="none"){
        var qRangeVal=(document.getElementById("qrange")||{}).value||"";
        if(!qRangeVal){toast("Please select a range");return;}
        qpv=qpv+": "+qSubVal+" - "+qRangeVal;
      } else {
        qpv=qpv+": "+qSubVal;
      }
    }
    var qqty=(document.getElementById("qqty")||{}).value||"";
    var qexp=(document.getElementById("qexpiry")||{}).value||"";
    entry.quote={ref:document.getElementById("qref").value.trim(),value:document.getElementById("qval").value.trim(),products:qpv+(qqty?" ("+qqty+")":""),category:qpv,status:document.getElementById("qstat").value,expiry:qexp};
  }
  var fuChkEl=document.getElementById("setFU");var fuDateEl=document.getElementById("fuDate");
  if(fuChkEl&&fuChkEl.checked&&fuDateEl&&fuDateEl.value){c.followup=fd(fuDateEl.value);}
  c.log.unshift(entry);c.interactionType=type;c.lastContact=fd(date);if(note)c.notes=note;
  var hasSmpEl=document.getElementById("hasSmp");
  if(hasSmpEl&&hasSmpEl.checked){
    var smpProd=(document.getElementById("smpProd")||{}).value||"Other";
    var smpType=(document.getElementById("smpType")||{}).value||"Loan";
    var smpDetail=(document.getElementById("smpDetail")||{}).value||"";
    samples.push({id:"SMP-"+Date.now(),clientName:c.name,sampleType:smpType,
      product:smpProd,detail:smpDetail,dateSent:fd(date),
      status:smpType==="Leave Behind"?"Left with client":"Sent - Awaiting Return",
      notes:"Logged from interaction: "+note.substring(0,80)});
    saveSamples();toast("Interaction + sample logged \u2713");
  } else {
    toast("Interaction logged \u2713");
  }
  saveC();showLF=false;renderDet();renderList();
}

function delLog(id,idx){var c=null;for(var i=0;i<clients.length;i++){if(clients[i].id===id){c=clients[i];break;}}if(c&&c.log){c.log.splice(idx,1);saveC();renderDet();toast("Entry removed");}}

function updateQStatus(id,idx,status){
  var c=null;for(var i=0;i<clients.length;i++){if(clients[i].id===id){c=clients[i];break;}}
  if(!c||!c.log[idx]||!c.log[idx].quote)return;
  if(status==="Lost"){
    // Show lost reason modal
    var overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;background:rgba(10,15,25,.6);z-index:500;display:flex;align-items:center;justify-content:center;padding:16px";
    var box=document.createElement("div");box.style.cssText="background:var(--surface);border-radius:var(--r);width:100%;max-width:400px;border-top:3px solid var(--rtxt);padding:20px";
    var title=document.createElement("div");title.style.cssText="font-size:14px;font-weight:700;margin-bottom:14px;color:var(--rtxt)";title.textContent="Why was this quote lost?";
    var sel=document.createElement("select");sel.style.cssText="width:100%;padding:8px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;margin-bottom:10px;font-family:inherit";
    ["Price too high","Went with competitor","No response","Job cancelled","Timing/not ready","Budget cut","Went direct to supplier","Other"].forEach(function(r){var o=document.createElement("option");o.value=r;o.textContent=r;sel.appendChild(o);});
    var notes=document.createElement("input");notes.placeholder="Additional notes (optional)";notes.style.cssText="width:100%;padding:8px;border:2px solid var(--border);border-radius:var(--rs);font-size:13px;margin-bottom:14px;font-family:inherit";
    var btns=document.createElement("div");btns.style.cssText="display:flex;gap:8px;justify-content:flex-end";
    var cancel=document.createElement("button");cancel.textContent="Cancel";cancel.style.cssText="padding:7px 16px;border:2px solid var(--border);border-radius:var(--rs);background:none;cursor:pointer;font-size:12px";
    var confirm=document.createElement("button");confirm.textContent="Mark Lost";confirm.style.cssText="padding:7px 16px;background:var(--rtxt);border:none;border-radius:var(--rs);color:#fff;cursor:pointer;font-size:12px;font-weight:700";
    cancel.addEventListener("click",function(){document.body.removeChild(overlay);});
    confirm.addEventListener("click",function(){
      c.log[idx].quote.lostReason=sel.value+(notes.value?" - "+notes.value:"");
      c.log[idx].quote.status="Lost";
      c.log[idx].quote.paidDate="";
      c.log[idx].quote.collectedDate="";
      saveC();toast("Quote marked lost");
      if(id===activeId)renderDet();
      document.body.removeChild(overlay);
    });
    btns.appendChild(cancel);btns.appendChild(confirm);
    box.appendChild(title);box.appendChild(sel);box.appendChild(notes);box.appendChild(btns);
    overlay.appendChild(box);document.body.appendChild(overlay);
    return;
  }
  if(status==="Paid"&&c.log[idx].quote.status!=="Paid"){
    var today10=new Date();
    var defaultPaid2=String(today10.getDate()).padStart(2,"0")+"/"+String(today10.getMonth()+1).padStart(2,"0")+"/"+today10.getFullYear();
    var enteredDate2=prompt("Date paid (DD/MM/YYYY):",defaultPaid2);
    if(enteredDate2===null){if(id===activeId)renderDet();return;}
    c.log[idx].quote.paidDate=enteredDate2.trim()||defaultPaid2;
  }
  if(status==="Collected"&&c.log[idx].quote.status!=="Collected"){
    var today11=new Date();
    var defaultCollected=String(today11.getDate()).padStart(2,"0")+"/"+String(today11.getMonth()+1).padStart(2,"0")+"/"+today11.getFullYear();
    var enteredCollected=prompt("Date collected (DD/MM/YYYY):",defaultCollected);
    if(enteredCollected===null){if(id===activeId)renderDet();return;}
    c.log[idx].quote.collectedDate=enteredCollected.trim()||defaultCollected;
  }
  c.log[idx].quote.status=status;saveC();toast("Quote updated");
  if(id===activeId)renderDet();
}

function showForm(id){
  editId=id;showView("form");
  var c=null;if(id){for(var i=0;i<clients.length;i++){if(clients[i].id===id){c=clients[i];break;}}}
  var fv=document.getElementById("formView");fv.innerHTML="";
  var fhdr=document.createElement("div");fhdr.className="fhdr";
  var fh2=document.createElement("h2");fh2.textContent=id?"Edit client":"Add new client";
  var bk=document.createElement("button");bk.className="bkbtn";bk.textContent="\u2190 Back";bk.addEventListener("click",cancelForm);
  fhdr.appendChild(fh2);fhdr.appendChild(bk);fv.appendChild(fhdr);

  function mkSec(title2){var s=document.createElement("div");s.className="fsec";var t=document.createElement("div");t.className="fstitle";t.textContent=title2;s.appendChild(t);var g=document.createElement("div");g.className="fgrid";s.appendChild(g);fv.appendChild(s);return g;}
  function mkF(grid,lbl,inp2,wide){var d=document.createElement("div");d.className="ff"+(wide?" s2":"");var l=document.createElement("label");l.textContent=lbl;d.appendChild(l);d.appendChild(inp2);grid.appendChild(d);}
  function mkI(id2,val,ph,type2){var i=document.createElement("input");i.id=id2;i.value=val||"";i.placeholder=ph||"";i.type=type2||"text";return i;}
  function mkTa(id2,val,ph){var t=document.createElement("textarea");t.id=id2;t.value=val||"";t.placeholder=ph||"";return t;}
  function mkS(id2,opts,val){var s=document.createElement("select");s.id=id2;opts.forEach(function(o){var op=document.createElement("option");op.value=o;op.textContent=o;if(o===val)op.selected=true;s.appendChild(op);});return s;}

  var g1=mkSec("Identity");
  mkF(g1,"Binder ref",mkI("e_binder",c?c.binder:nextId(),""));
  mkF(g1,"Account manager",mkI("e_mgr",c?(c.manager||"FSG"):"",""));
  mkF(g1,"Account name *",mkI("e_name",c?c.name:"","Company or client name"),true);
  var dupWarnWrap = document.createElement("div"); dupWarnWrap.className = "ff s2"; dupWarnWrap.style.display = "none";
  var dupWarnBox = document.createElement("div"); dupWarnBox.style.cssText = "background:#fff4e0;border:2px solid #f0c060;border-radius:var(--rs);padding:9px 11px;font-size:11px;color:#8a5a00";
  dupWarnWrap.appendChild(dupWarnBox);
  g1.appendChild(dupWarnWrap);
  mkF(g1,"Primary contact name",mkI("e_contact",c?c.contact:"","Primary contact person"));
  var e_mob=mkI("e_mob",c?c.mobile:"","07700 000000","tel"); e_mob.maxLength=14;
  mkF(g1,"Primary contact number",e_mob);
  mkF(g1,"Secondary contact name",mkI("e_contact2",c?c.contact2:"","Secondary contact person (optional)"));
  var e_mob2=mkI("e_mob2",c?c.mobile2:"","07700 000000","tel"); e_mob2.maxLength=14;
  mkF(g1,"Secondary contact number",e_mob2);
  var srcSel=document.createElement("select");srcSel.id="e_source";srcSel.style.cssText="width:100%;padding:6px 8px;border:2px solid var(--border);border-radius:var(--rs);font-size:11px;font-family:inherit;color:var(--text);outline:none";
  [""].concat(CLIENT_CATS).forEach(function(s2){var opt=document.createElement("option");opt.value=s2;opt.textContent=s2||"-- Select source --";if(c&&c.source===s2)opt.selected=true;srcSel.appendChild(opt);});
  mkF(g1,"Customer source",srcSel,true);
  mkF(g1,"Area",mkI("e_addr",c?c.address:"","e.g. Leeds, Sheffield"));

  var g3=mkSec("Intelligence");
  mkF(g3,"Product interest",mkI("e_prod",c?c.product:"","e.g. LVT, SPC, Safety Vinyl"),true);
  mkF(g3,"Est. annual spend",mkI("e_spend",c?c.spend:"","e.g. 8000"));
  var spendNote=document.createElement("div");spendNote.style.cssText="font-size:9px;color:var(--muted);margin-top:-4px;grid-column:1/-1";spendNote.textContent="Auto-calculated from paid orders (last 12mo) once available \u2014 this manual figure is only shown until then.";
  g3.appendChild(spendNote);
  var priWrap = document.createElement("div"); priWrap.className = "ff";
  var priLbl = document.createElement("label"); priLbl.style.cssText = "display:block;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--muted);letter-spacing:.4px;margin-bottom:2px"; priLbl.textContent = "Priority rating";
  var priSel = mkS("e_pri",["","\u2605","\u2605\u2605","\u2605\u2605\u2605","\u2605\u2605\u2605\u2605","\u2605\u2605\u2605\u2605\u2605"],c?c.priority:"");
  var autoVal = c ? calcAutoPriority(c) : "";
  var priNote = document.createElement("div"); priNote.style.cssText = "font-size:9px;color:var(--muted);margin-top:3px"; priNote.textContent = autoVal ? "Auto-calculated: "+autoVal+" (override above to set manually)" : "No auto-rating yet (needs interactions/sales)";
  var manChk = document.createElement("div"); manChk.style.cssText = "display:flex;align-items:center;gap:5px;margin-top:4px";
  var manInp = document.createElement("input"); manInp.type="checkbox"; manInp.id="e_manual_pri"; manInp.checked=!!(c&&c.manualPriority);
  var manLbl2 = document.createElement("label"); manLbl2.setAttribute("for","e_manual_pri"); manLbl2.style.cssText="font-size:10px;color:var(--muted)"; manLbl2.textContent="Lock this rating (stop auto-updates)";
  manChk.appendChild(manInp); manChk.appendChild(manLbl2);
  priWrap.appendChild(priLbl); priWrap.appendChild(priSel); priWrap.appendChild(priNote); priWrap.appendChild(manChk);
  g3.appendChild(priWrap);
  mkF(g3,"Wont buy / not interested in",mkTa("e_wont",c?c.wontBuy:"","Products or ranges they are not interested in"),true);
  mkF(g3,"Competitor notes",mkTa("e_comp",c?c.competitorNotes:"","Who else they buy from"),true);

  var g4=mkSec("Tracking");
  mkF(g4,"Status",mkS("e_stat",["Active","Prospect","On Hold","Lost","Closed"],c?c.status:"Prospect"));
  mkF(g4,"Interaction type",mkS("e_itype",["","Phone","Text","Email","Store Visit"],c?c.interactionType:""));
  mkF(g4,"Last contacted",mkI("e_lc",c?ti(c.lastContact):"","","date"));
  mkF(g4,"Follow-up date",mkI("e_fu",c?ti(c.followup):"","","date"));
  mkF(g4,"Account opened",mkI("e_opened",c?ti(c.dateOpened||""):"","","date"));
  mkF(g4,"Key dates",mkI("e_keyDates",c?c.keyDates:"","e.g. Contract renewal 01/09/2026"),true);
  mkF(g4,"Last interaction notes",mkTa("e_notes",c?c.notes:"","Notes from last conversation"),true);

  var foot=document.createElement("div");foot.className="ffoot";
  var cancelB=document.createElement("button");cancelB.className="fcancel";cancelB.textContent="Cancel";cancelB.addEventListener("click",cancelForm);
  var saveB=document.createElement("button");saveB.className="fsave";saveB.textContent="Save client";saveB.addEventListener("click",submitForm);
  foot.appendChild(cancelB);foot.appendChild(saveB);fv.appendChild(foot);

  // Live duplicate-name check, catches exact matches and close misspellings
  function levenshtein(a, b) {
    var m = a.length, n = b.length;
    var dp = []; for (var x = 0; x <= m; x++) { dp.push([x]); }
    for (var y = 0; y <= n; y++) { dp[0][y] = y; }
    for (var i2 = 1; i2 <= m; i2++) {
      for (var j2 = 1; j2 <= n; j2++) {
        dp[i2][j2] = a[i2-1] === b[j2-1] ? dp[i2-1][j2-1] : 1 + Math.min(dp[i2-1][j2], dp[i2][j2-1], dp[i2-1][j2-1]);
      }
    }
    return dp[m][n];
  }
  var nameInpEl = document.getElementById("e_name");
  if (nameInpEl) {
    nameInpEl.addEventListener("input", function(){
      var typed = nameInpEl.value.trim();
      if (typed.length < 3) { dupWarnWrap.style.display = "none"; return; }
      var typedLower = typed.toLowerCase();
      var matches = clients.filter(function(cl){
        if (id && cl.id === id) return false; // skip self when editing
        var clName = (cl.name||"").toLowerCase();
        if (!clName) return false;
        if (clName === typedLower) return true;
        if (clName.indexOf(typedLower) === 0) return true; // typed text is the start of an existing name
        // Compare against the start of the existing name too, so a short typed snippet
        // (e.g. "alph") still catches a typo against the equivalent prefix of "aplha flooring"
        var prefixLen = Math.min(clName.length, typedLower.length);
        var clPrefix = clName.slice(0, prefixLen);
        var prefixDist = levenshtein(clPrefix, typedLower);
        // A single transposed pair of letters (e.g. "alph" vs "aplh") costs 2 edits even on
        // very short strings, so allow up to 2 edits flat on anything 4+ characters long.
        if (prefixLen >= 4 && prefixDist <= 2) return true;
        if (prefixLen > 0 && (prefixDist / prefixLen) <= 0.3 && prefixDist <= 2) return true;
        // Fuzzy: small edit distance relative to full name length catches typos like Alpha/Aplha
        var dist = levenshtein(clName, typedLower);
        var maxLen = Math.max(clName.length, typedLower.length);
        return maxLen > 0 && (dist / maxLen) <= 0.25 && dist <= 3;
      });
      if (matches.length) {
        dupWarnBox.innerHTML = "\u26A0\uFE0F Possible duplicate \u2014 you already have: <strong>" + matches.map(function(m){ return m.name; }).join(", ") + "</strong>. Check before saving a new client.";
        dupWarnWrap.style.display = "block";
      } else {
        dupWarnWrap.style.display = "none";
      }
    });
  }
}

function cancelForm(){if(activeId){showView("det");renderDet();}else{showDash();}}

function submitForm(){
  var name=document.getElementById("e_name").value.trim();
  if(!name){toast("Account name is required");return;}
  var binder=document.getElementById("e_binder").value.trim();
  var data={
    id:editId||binder,binder:binder,name:name,
    contact:document.getElementById("e_contact").value.trim(),
    manager:document.getElementById("e_mgr").value.trim(),
    mobile:document.getElementById("e_mob").value.trim(),
    contact2:document.getElementById("e_contact2").value.trim(),
    mobile2:document.getElementById("e_mob2").value.trim(),
    address:document.getElementById("e_addr").value.trim(),
    product:document.getElementById("e_prod").value.trim(),
    spend:document.getElementById("e_spend").value.trim(),
    priority:document.getElementById("e_pri").value,
    manualPriority:document.getElementById("e_manual_pri")?document.getElementById("e_manual_pri").checked:false,
    source:document.getElementById("e_source")?document.getElementById("e_source").value:"",
    wontBuy:document.getElementById("e_wont").value.trim(),
    competitorNotes:document.getElementById("e_comp").value.trim(),
    status:document.getElementById("e_stat").value,
    interactionType:document.getElementById("e_itype").value,
    lastContact:fd(document.getElementById("e_lc").value),
    followup:fd(document.getElementById("e_fu").value),
    dateOpened:fd(document.getElementById("e_opened").value),
    keyDates:document.getElementById("e_keyDates").value.trim(),
    notes:document.getElementById("e_notes").value.trim(),
    log:editId?(function(){for(var i=0;i<clients.length;i++){if(clients[i].id===editId)return clients[i].log||[];}return[];})():[]
  };
  if(!data.dateOpened&&(data.source==="Existing Customer"||data.source==="Existing Customer (Dormant 12m+)")){data.dateOpened="01/01/2000";}
  if(editId){for(var i=0;i<clients.length;i++){if(clients[i].id===editId){clients[i]=data;break;}}}
  else{clients.push(data);activeId=data.id;}
  saveC();renderList();
  var wasEdit=editId;editId=null;
  toast((wasEdit?"Client updated":"Client added")+" \u2713");
  activeId=data.id;showView("det");renderDet();
}

function askDel(id,name){pendingDel=id;document.getElementById("confMsg").textContent="This will permanently remove "+name+" and all their history.";document.getElementById("confTypeInput").value="";document.getElementById("confDelBtn").disabled=true;document.getElementById("confOverlay").classList.remove("hidden");}

function closeConf(){document.getElementById("confOverlay").classList.add("hidden");document.getElementById("confTypeInput").value="";document.getElementById("confDelBtn").disabled=true;pendingDel=null;}

function doDelete(){var delId=pendingDel;clients=clients.filter(function(c){return c.id!==delId;});saveC();sbDelete("clients",delId);closeConf();activeId=null;renderList();showDash();toast("Client deleted");}

function toggleMobSidebar() {
  var sb = document.getElementById("sidebar");
  var btn = document.getElementById("mobMenuBtn");
  var bd = document.getElementById("sbBackdrop");
  if (sb.classList.contains("mob-open")) {
    sb.classList.remove("mob-open");
    bd.classList.remove("show");
    btn.textContent = "\u2261 Clients";
  } else {
    var hdrH = document.querySelector(".hdr").offsetHeight + document.getElementById("mobBar").offsetHeight;
    sb.style.top = hdrH + "px";
    sb.classList.add("mob-open");
    bd.classList.add("show");
    btn.textContent = "\u2715 Close";
    sb.scrollTop = 0;
  }
}

function mobSearch(val) {
  document.getElementById("sq").value = val;
  renderList();
  if (val.length > 0) {
    var sb = document.getElementById("sidebar");
    if (!sb.classList.contains("mob-open")) toggleMobSidebar();
  }
}

// Stable module namespace for future code; legacy global functions remain available.
window.CRM = window.CRM || {};
window.CRM.Clients = {
  show: showClients,
  open: openC,
  renderList: renderList,
  renderDirectory: renderClientsView,
  renderDetail: renderDet,
  showForm: showForm,
  saveForm: submitForm,
  deleteClient: doDelete,
  setFilter: setF,
  mobileSearch: mobSearch
};
