# CRM 2.1 Owner's Manual — Plain-English Guide

## What this version is

CRM 2.1 is the first genuinely modular version of the CRM. The **Clients** code has been moved out of the large legacy JavaScript file and into its own file:

`js/modules/clients.js`

The screens and workflow are intentionally unchanged. This stage is about making the code safer to maintain, not redesigning your daily routine.

## How to preview it

1. Keep the folder structure exactly as supplied.
2. Open `index.html` through GitHub Pages or another simple web server.
3. Do not move `clients.js`, `app.js`, or `app.css` out of their folders.
4. Sign in and test the checklist below.

Opening `index.html` directly from a downloaded folder may work, but GitHub Pages is the most reliable preview because it behaves like the live website.

## Important safety warning

This version still points at the same Supabase project as the current CRM. Saving, editing, importing, archiving, or deleting data changes the live database. Use ordinary test records only if you need to test a destructive action.

## What moved into the Clients module

- Client directory and sidebar list
- Search and status filters
- Opening a client record
- Client detail screen
- Adding and editing clients
- Interaction and quote-log controls used inside a client
- Client deletion confirmation
- Mobile client sidebar and search

## Simple test checklist

Tick these off after deploying the preview:

- [ ] Dashboard opens
- [ ] Clients button opens the client directory
- [ ] Client sidebar/list appears
- [ ] Search finds a known client
- [ ] Active, Prospect, On Hold, and Lost filters work
- [ ] Opening a client shows the correct details
- [ ] Edit form opens and can be cancelled without saving
- [ ] Mobile client menu opens and closes
- [ ] Other modules still open normally
- [ ] Browser console contains no red errors

For save testing, make one harmless change to a test record, confirm it appears on another device, then undo it.

## Files you are most likely to touch

- `index.html` — page shell and script-loading order
- `css/app.css` — all appearance and layout
- `js/modules/clients.js` — Clients feature
- `js/app.js` — remaining legacy features awaiting extraction
- `legacy-original.html` — untouched safety reference

## What not to do

- Do not publish Supabase service-role keys. The current publishable key is meant for browser use, but database security still depends on Supabase policies.
- Do not rename functions in `clients.js` yet; the existing HTML uses their names in button actions.
- Do not flatten the folders when uploading to GitHub.
- Do not delete `legacy-original.html` until CRM 2.0 reaches full feature parity.

## What changed technically

The old application relied on global functions. CRM 2.1 keeps those functions available so nothing breaks, while also introducing this stable namespace for new work:

```javascript
CRM.Clients.show()
CRM.Clients.open(clientId)
CRM.Clients.renderList()
CRM.Clients.showForm(clientId)
```

Future modules will follow the same pattern. Once all modules are separated and tested, the remaining global code can be reduced safely.

## Recovery

If CRM 2.1 has a problem, continue using the existing live CRM. Nothing in this package replaces it automatically. You can also open `legacy-original.html` as the preserved reference copy.
