# CRM 2.1 — Clients Module Milestone

This build preserves the current CRM interface while extracting the Clients feature into `js/modules/clients.js`.

## Included

- Working application shell
- Existing Supabase integration
- Extracted Clients module
- Compatibility namespace: `CRM.Clients`
- Plain-English owner's manual
- Original legacy HTML reference

## Preview

Deploy the complete folder to GitHub Pages. Keep all folders and relative paths unchanged.

## Safety

The Supabase connection is still the live connection. Data-changing actions affect the same database as the original CRM.
