# CRM Module Map

## Extracted

### Clients (`js/modules/clients.js`)
Owns directory rendering, sidebar filtering/search, client detail rendering, client form lifecycle, client interaction/quote log controls, deletion confirmation, and mobile client navigation.

Dependencies currently supplied by `app.js` include shared state (`clients`, `activeId`, filters), generic UI helpers, local/Supabase persistence, data-format helpers, and cross-module navigation. These dependencies remain global temporarily to preserve behaviour.

## Remaining in `js/app.js`

Dashboard, sales, quotes, samples, diary, tasks, reps, complaints, enquiries, sourcing, reports, footfall, websites, documents, notes search, tools, admin, themes, authentication, shared UI helpers, and Supabase persistence.

## Extraction rule

Each milestone must:

1. Preserve current screen behaviour.
2. Keep the prior working version available.
3. Add a namespace under `window.CRM`.
4. Pass JavaScript syntax checks.
5. Include a practical owner test checklist.
